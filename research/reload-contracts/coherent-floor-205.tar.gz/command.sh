#!/usr/bin/env bash
set -euo pipefail
root=/home/user/tmp/product-online-20261014/round2/coherent-floor-205-ready
export BL_PROBE_ROOT="$root" BL_DIAGNOSTIC="$root/probe.exs" BL_BOOTSTRAP_OUTPUT="$root" BL_BOOTSTRAP_INSTALL=1 TMPDIR="$root/tmp" BEAM_LISP_AOT_CACHE_DIR="$root/aot-cache"
unset BEAM_LISP_EBIN BEAM_LISP_PATH BL_ROOT BL_EBIN BL_BIN BL_BUILD_ID BL_BOOT_REEXECED BL_CONSTRUCTOR_METADATA_ROOT BL_KERNEL_SOURCE_UNDER_TEST
cd /home/user/code/undefine/beam-lisp
"$root/source-bootstrap-wrapper"
