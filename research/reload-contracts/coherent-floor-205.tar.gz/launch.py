from pathlib import Path
import subprocess,json,time,datetime,hashlib
r=Path(__file__).parent;log=r.parent/'coherent-floor-205.log'
assert not log.exists()
args=['systemd-run','--user','--collect','--wait','--unit=bl-coherent-floor-205','--working-directory=/home/user/code/undefine/beam-lisp','--property=MemoryMax=6G','--property=MemorySwapMax=0','--property=RuntimeMaxSec=2400s','--property=StandardOutput=append:'+str(log),'--property=StandardError=inherit','/bin/bash','-c','TIMEFORMAT="COHERENT205 wall=%R user=%U sys=%S"; time '+str(r/'command.sh')]
start=time.monotonic();at=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (r/'systemd-run-control.log').open('w') as out:result=subprocess.run(args,stdout=out,stderr=subprocess.STDOUT)
x={'unit':'bl-coherent-floor-205.service','command':args,'startedUTC':at,'finishedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':result.returncode,'wallSecondsParent':time.monotonic()-start,'controlLogSha256':hashlib.sha256((r/'systemd-run-control.log').read_bytes()).hexdigest()}
(r/'parent-result.json').write_text(json.dumps(x,indent=2)+'\n');print(json.dumps(x),flush=True)
raise SystemExit(result.returncode)
