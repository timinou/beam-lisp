#!/usr/bin/env python3
"""Root only after final source groups land. No VM, no manifest fabrication."""
import hashlib,json,subprocess,shutil,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
MAIN=Path('/home/user/code/undefine/beam-lisp')
R2=HERE.parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert not (HERE/'inputs.json').exists(),'Preserve the existing frozen attempt'
for directory in ['ebin','tmp','aot-cache']:(HERE/directory).mkdir(exist_ok=True)
assert len(sys.argv)==2 and len(sys.argv[1])==64,'Usage: prepare.py REVIEWED_FINAL_ENV_SHA256'
assert sha(MAIN/'priv/host/env.bl')==sys.argv[1]
assert sha(MAIN/'priv/host/aot.bl')=='477a29e0a1ab285853ca4213e23054a13baa0b7ff834bc1b5947dbdc9ac806d1'
assert sha(MAIN/'priv/boot/core.bl')=='db4aa3096cb37d0b1b89bec79653063909a27026b9825f5aa109943994274d28'
assert sha(MAIN/'scripts/regenerate-seed.bl')=='99040f36913f6e3953f9b849bf8042d1baabf171364a3540f97b751901fe302c'
substrate=json.loads((HERE/'substrate-inputs.json').read_text())
assert substrate['substrateCommit']=='08324189e82d51275bdfbb39a76076ee9879dcb4'
assert sha(HERE/'substrate/priv/bootstrap/seed/manifest.term')==substrate['expectedManifestSha256']
for row in substrate['assets']:
 assert sha(HERE/'substrate'/row['path'])==row['sha256']
 assert sha(MAIN/row['path'])==row['sha256']
# Exact193 boot cache bytes are only optional candidates. Normal official
# build/run must accept/rebuild each against actual current source/key/closure.
cache=[]
for p in sorted((R2/'coherent-floor-198-ready/ebin').iterdir()):
 if p.is_file():
  q=HERE/'ebin'/p.name;shutil.copyfile(p,q)
  cache.append({'path':str(q.relative_to(HERE)),'sha256':sha(q),'source':str(p)})
# Reproduce exact AOTCache source-key algorithm independently, as accepted193.
hashparts=lambda ps:hashlib.sha256(b'\0'.join(ps)).hexdigest()
leaves=['aot','atom_guard','compiler_data','source_graph','ns_interface','build_plan','record','emit','optimize','link','tiers']
names=['AOT','AtomGuard','CompilerData','SourceGraph','NamespaceInterface','BuildPlan','Record','Emit','Optimize','Link','Tiers']
parts=[b'codegen']
for leaf,name in zip(leaves,names):parts.extend([(MAIN/'priv/host'/f'{leaf}.bl').read_bytes(),('Elixir.BeamLisp.'+name).encode()])
codegen=hashparts(parts)
tier=sorted(list((MAIN/'priv/boot').rglob('*.bl'))+list((MAIN/'priv/self').rglob('*.bl')))
key=hashparts([b'elixir:1.20.4',b'otp:29',b'aot_backend:core',('codegen-source:'+codegen).encode()]+[p.read_bytes() for p in tier])
tracked=subprocess.check_output(['git','ls-files','-z'],cwd=MAIN).decode().split('\0')
# Freeze all tracked BL source, including queued SDK/body/protocol changes and
# regression files; plus native Rust/build inputs. Generated seed outputs are
# deliberately excluded: official manifest-last publication will replace them.
paths=sorted(p for p in tracked if p and (p.endswith(('.bl','.rs')) or Path(p).name in ('Cargo.toml','Cargo.lock','build.rs')) and not p.startswith('priv/bootstrap/seed/'))
paths=sorted(set(paths)|{'scripts/regenerate-seed.bl','scripts/install-seed.bl','env.bl'})
subpaths=sorted(str(p.relative_to(HERE/'substrate')) for base in ['priv/host','priv/boot','priv/self','priv/build'] for p in (HERE/'substrate'/base).rglob('*.bl'))
subpaths+=['priv/bootstrap/seed/manifest.term']+[r['path'] for r in substrate['assets']]
allowed=['command.sh','probe.exs','source-bootstrap-wrapper','prepare.py','project.direct.bl','substrate-inputs.json']
x={'scope':'Root-only current coherent floor205 recovery; no ordinary/owner acceptance','source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=MAIN,text=True).strip(),'substrate_commit':substrate['substrateCommit'],'runtime':{'elixir':'1.20.4','otp':'29','backend':'core'},'expected_compiler_key':key,'codegen_digest':codegen,'sources':[{'path':p,'sha256':sha(MAIN/p)} for p in paths],'substrate_sources':[{'path':p,'sha256':sha(HERE/'substrate'/p)} for p in subpaths],'native_assets':substrate['assets'],'files':{p:sha(HERE/p) for p in allowed},'boot_cache':cache,'project_assertions':15,'host_policy':'16 compile all before15load; LazyMemo emit-only; all4 Env private tables native-created/empty in recovery; fresh acceptanceVM creates its own','publication':'official seed/run + complete83 source check + manifest-last install, never relabel'}
(HERE/'inputs.json').write_text(json.dumps(x,indent=2)+'\n')
print(json.dumps({'ready':str(HERE),'sources':len(x['sources']),'nativeAssets':len(x['native_assets']),'substrateSources':len(x['substrate_sources']),'bootCacheFiles':len(cache),'compilerKey':key,'sourceCommit':x['source_commit']}))
