from pathlib import Path
root=Path('/home/user/code/undefine/beam-lisp')
here=Path(__file__).parent
s=(root/'priv/host/aot.bl').read_text()
# Structurally split top-level forms without changing names or quoted syntax.
ns={'__file__':'/home/user/tmp/product-online-20261014/owner-drafts/pure-planner/extract.py'}
exec(Path(ns['__file__']).read_text().split('base={};new={}')[0],ns)
forms=ns['forms'](s) if 'forms' in ns else None
# Exact named top-level replacement uses balanced parentheses, skipping strings/comments.
def span(name):
    start=s.index('(defn- '+name+' ')
    i=start; depth=0; string=False; escape=False; comment=False
    while i<len(s):
        c=s[i]
        if comment:
            if c=='\n': comment=False
        elif string:
            if escape: escape=False
            elif c=='\\': escape=True
            elif c=='"': string=False
        elif c==';': comment=True
        elif c=='"': string=True
        elif c=='(': depth+=1
        elif c==')':
            depth-=1
            if depth==0:return start,i+1
        i+=1
    raise ValueError(name)
def replace(name,new):
    global s
    a,b=span(name);s=s[:a]+new+s[b:]
fragment=(here/'stream-fragment.bl').read_text()
fragment='''(defn- constructor_stream_mapv! [f values]
 (BeamLisp.Vector/new (Enum/map (if (vector? values) (BeamLisp.Vector/to_list values) values) f)))

'''+fragment.replace('(mapv ', '(constructor_stream_mapv! ').replace('(some nil? pulled)', '(Enum/any? (BeamLisp.Vector/to_list pulled) (fn [v] (nil? v)))')
s=s.replace('(defn- constructor_finite_fold!',fragment+'\n\n(defn- constructor_finite_fold!',1)
replace('constructor_finite_fold!', '''(defn- constructor_finite_fold! [callback init collection policy state]
 (constructor_stream_fold! callback init collection policy state))''')
replace('constructor_recipe_sequence!', '''(defn- constructor_recipe_sequence! [recipe state]
 (constructor_stream_all! recipe :fold state))''')
# Deferred recipe-producing adapters replace eager implementations.
a=s.index('     "concat" (let [items ');b=s.index('     "take"',a)
s=s[:a]+'''     "concat" (constructor_stream_new! :concat nil args state)
'''+s[b:]
a=s.index('     "mapcat" (let [f ');b=s.index('     "run!"',a)
s=s[:a]+'''     "mapcat" (let [mapped (constructor_stream_new! :map (first args) (rest args) state)
                      values (constructor_stream_all! mapped :fold state)]
                 (constructor_stream_new! :concat nil values state))
     "map" (constructor_stream_new! :map (first args) (rest args) state)
     "mapv" (BeamLisp.Vector/new
               (constructor_stream_all! (constructor_stream_new! :map (first args) (rest args) state) :fold state))
     "filter" (constructor_stream_new! :filter (first args) (list (second args)) state)
     "remove" (constructor_stream_new! :remove (first args) (list (second args)) state)
'''+s[b:]
s=s.replace('''     "some" (Enum/find_value (constructor_sequence! (second args) state) #(constructor_invoke (first args) (list %) state))
     "every?" (Enum/all? (constructor_sequence! (second args) state) #(constructor_truthy? (constructor_invoke (first args) (list %) state)))''', '''     "some" (constructor_stream_short! (first args) (second args) false state)
     "every?" (constructor_stream_short! (first args) (second args) true state)''')
# Existing full eager primitives are safe for raw data, but must use demand-aware
# cell consumers when the collection is an authenticated deferred stream.
s=s.replace('(constructor_recipe_sequence! (first args) state) (first args)))\n     "second"', '(constructor_stream_head! (first args) state) (first args)))\n     "second"',1)
# Fix first explicitly rather than wrapping a scalar in native first.
a=s.index('     "first" (BeamLisp.Ns.Rt/first');b=s.index('     "count"',a)
s=s[:a]+'''     "first" (if (constructor_recipe? (first args) state)
                 (constructor_stream_head! (first args) state) (BeamLisp.Ns.Rt/first (first args)))
     "second" (if (constructor_recipe? (first args) state)
                  (constructor_stream_nth! (first args) 1 nil state) (BeamLisp.Ns.Rt/nth (first args) 1))
     "rest" (if (constructor_recipe? (first args) state)
                (constructor_stream_rest! (first args) false state) (BeamLisp.Ns.Rt/rest (first args)))
     "next" (if (constructor_recipe? (first args) state)
                (constructor_stream_rest! (first args) true state) (BeamLisp.Ns.Rt/next (first args)))
     "last" (if (constructor_recipe? (first args) state)
                (constructor_eager_last (constructor_stream_all! (first args) :cell state))
                (constructor_eager_last (first args)))
     "nth" (if (constructor_recipe? (first args) state)
               (constructor_stream_nth! (first args) (second args) (nth args 2 nil) state)
               (if (= 2 (count args)) (BeamLisp.Ns.Rt/nth (first args) (second args))
                (BeamLisp.Ns.Rt/nth (first args) (second args) (nth args 2))))
'''+s[b:]
s=s.replace('"empty?" (BeamLisp.Ns.Rt/empty? (if (constructor_recipe? (first args) state)\n                                        (constructor_recipe_sequence! (first args) state) (first args)))', '"empty?" (if (constructor_recipe? (first args) state)\n                   (nil? (constructor_stream_pull! (constructor_stream_cursor! (first args) state) :cell state))\n                   (BeamLisp.Ns.Rt/empty? (first args)))')
s=s.replace('''     "seq" (if (constructor_recipe? (first args) state)
              (when (seq (constructor_recipe_sequence! (first args) state)) (first args))''','''     "seq" (if (constructor_recipe? (first args) state)
              (constructor_stream_seq! (first args) state)''')
s=s.replace('''    (and (constructor_recipe? (first args) state)
         (= :thunk (:kind (constructor_recipe_row! (first args) state))))''','''    (and (constructor_recipe? (first args) state)
         (let [row (constructor_recipe_row! (first args) state)]
          (or (contains? #{:thunk :derived} (:kind row))
              (and (= :view (:kind row)) (:native-lazy? row)))))''')
# Interpreted callable proof includes only actual AST lambdas and exact closed
# primitive wrappers minted privately by the machine itself.
s=s.replace('''               (fn [& arguments]
                (constructor_primitive :Elixir.BeamLisp.Ns.Core (erlang/binary_to_atom (:name n))
                           (to-list arguments) state))''','''               (constructor_register_callable!
                (fn [& arguments]
                 (constructor_primitive :Elixir.BeamLisp.Ns.Core (erlang/binary_to_atom (:name n))
                            (to-list arguments) state)) state)''')
# Root-derived frames may escape neither directly nor nested; existing final
# capsule gate covers them and PDict finally erases every retained callback.
(here/'aot.bl').write_text(s)
# Extend only machine-created, authenticated capabilities for Reduced. Foreign
# Reduced structs and native handles remain rejected by the raw-data boundary.
s=s.replace('"k-to-list" "vector?" "set?" "apply_variadic"', '"k-to-list" "vector?" "set?" "reduced?" "reduced" "deref" "apply_variadic"')
s=s.replace('''     "reduced?" (BeamLisp.Ns.Rt/reduced? (first args))''','''     "reduced?" (if (constructor_recipe? (first args) state)
                   (constructor_stream_halt? (first args) state)
                   (BeamLisp.Ns.Rt/reduced? (first args)))
     "reduced" (constructor_stream_halt! (first args) state)
     "deref" (constructor_stream_unwrap! (first args) state)''')
s=s.replace('''   (= target [:Elixir.BeamLisp.Ns.Rt :k-to-list 1])''','''   (= target [:Elixir.BeamLisp.Ns.Rt :reduced 1])
    (constructor_stream_halt! (first args) state)
   (= target [:Elixir.BeamLisp.Refs :deref 1])
    (constructor_stream_unwrap! (first args) state)
   (= target [:Elixir.BeamLisp.Ns.Rt :k-to-list 1])''')
s=s.replace('''                   (and (= :Elixir.BeamLisp.LazySeq module)''','''                   (and (= target [:Elixir.BeamLisp.Refs :deref 1])
                        (constructor_stream_halt? (first args) state))
                   (and (= :Elixir.BeamLisp.LazySeq module)''',1)
s=s.replace('"sorted?" "reduced?" "gensym"', '"sorted?" "reduced?" "reduced" "deref" "gensym"')
s=s.replace('"reduced?" #{1} "gensym"', '"reduced?" #{1} "reduced" #{1} "deref" #{1} "gensym"')
(here/'aot.bl').write_text(s)

s=s.replace('"k-to-list" "vector?" "set?" "reduced?"', '"k-to-list" "vector?" "set?" "take" "drop" "cons" "reduced?"')
s=s.replace('     "take" (BeamLisp.Ns.Rt/take (first args) (second args))', '     "take" (if (constructor_recipe? (second args) state) (constructor_stream_take! (first args) (second args) state) (BeamLisp.Ns.Rt/take (first args) (second args)))')
s=s.replace('     "drop" (BeamLisp.Ns.Rt/drop_clj (first args) (second args))', '     "drop" (if (constructor_recipe? (second args) state) (constructor_stream_drop! (first args) (second args) state) (BeamLisp.Ns.Rt/drop_clj (first args) (second args)))')
s=s.replace('     "cons" (cons (first args) (constructor_sequence! (second args) state))', '     "cons" (if (constructor_recipe? (second args) state) (constructor_stream_cons! (first args) (second args) state) (cons (first args) (constructor_sequence! (second args) state)))')
s=s.replace('''           (when (constructor_recipe? tail state)
            (constructor_refuse :opaque-finite-recipe-observation))
           (constructor_allocation! 2 0 state)
           (cons head (constructor_sequence! tail state)))''','''           (constructor_allocation! 2 0 state)
           (if (constructor_recipe? tail state) (constructor_stream_cons! head tail state)
            (cons head (constructor_sequence! tail state))))''')
(here/'aot.bl').write_text(s)

s=s.replace('#{:thunk :chain :input}\n                             (:kind', '#{:thunk :chain :input :derived :view :cons :halt :transient}\n                             (:kind')
s=s.replace(':eqv :not_ :assoc :conj :contains? :map :set :vector?', ':eqv :not_ :assoc :conj :contains? :map :filter :set :vector?')
needle='   (= target [:Elixir.BeamLisp.Ns.Rt :reduced 1])'
s=s.replace(needle,'''   (contains? #{[:Elixir.BeamLisp.Ns.Rt :map_multi 3] [:Elixir.BeamLisp.Ns.Rt :map-multi 3]} target)
    (do
     (when-not (erlang/is_list (nth args 2)) (constructor_refuse :map-multi-rest-list))
     (constructor_stream_new! :map (first args) (cons (second args) (nth args 2)) state))
   (= target [:Elixir.BeamLisp.Ns.Rt :concat 1])
    (constructor_stream_new! :concat nil (constructor_sequence! (first args) state) state)
'''+needle,1)
(here/'aot.bl').write_text(s)
s=s.replace('"first" "nth" "count" "empty?" "seq" "to-list" "vec"', '"first" "second" "rest" "next" "last" "nth" "count" "empty?" "seq" "to-list" "vec"',1)
s=s.replace('''     "run!" (do (Enum/each (constructor_sequence! (second args) state) #(constructor_invoke (first args) (list %) state)) nil)''','''     "run!" (do
               (constructor_stream_fold!
                (fn [_ item] (constructor_invoke (first args) (list item) state) nil)
                nil (second args) :kernel state) nil)''')
s=s.replace('''     "into" (case (count args) 0 [] 1 (first args)
                2 (Enum/reduce (constructor_sequence! (second args) state) (first args) (fn [item acc] (conj acc item))))''','''     "into" (case (count args) 0 [] 1 (first args)
                2 (constructor_stream_fold! (fn [acc item] (BeamLisp.Ns.Rt/conj acc item))
                    (first args) (second args) :kernel state))''')
(here/'aot.bl').write_text(s)

# A canonical cpp seed wrapper is machine-created authority, like the reviewed
# Core adapter wrapper. Register it exactly at its authenticated creation site.
a,b=span('constructor_kernel_alias!')
alias=s[a:b]
alias=alias.replace('''    (fn [& arguments]
''','''    (constructor_register_callable! (fn [& arguments]
''',1)
assert alias.endswith('state)))))))')
alias=alias[:-len('state)))))))')]+'state))) state)))))'
s=s[:a]+alias+s[b:]
(here/'aot.bl').write_text(s)
