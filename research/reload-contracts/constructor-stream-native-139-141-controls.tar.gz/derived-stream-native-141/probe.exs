Application.load(:beam_lisp)
{:ok, deps} = :application.get_key(:beam_lisp, :applications)
Enum.each(deps, fn dep -> {:ok, _} = Application.ensure_all_started(dep) end)
:ok = BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
BeamLisp.AOT.boot()
root = System.fetch_env!("BL_PROBE_ROOT")
# Reuse the exact Compiler artifacts produced and hashed by native106.
# This is a diagnostic overlay, never a coherent-floor acceptance.
for module <- [BeamLisp.Ns.Compiler, BeamLisp.Ns.Body.Compiler, BeamLisp.Ns.Init.Compiler] do
 artifact = "/home/user/tmp/product-online-20261014/round2/compiler-metadata-native-127/compiler-beams/" <> Atom.to_string(module) <> ".beam"
 {:module, ^module} = :code.load_binary(module, String.to_charlist(artifact), File.read!(artifact))
 IO.inspect({module, Base.encode16(:crypto.hash(:sha256, File.read!(artifact)), case: :lower)}, label: "REUSED_NATIVE_COMPILER")
end
for module <- [BeamLisp.SourceGraph, BeamLisp.NamespaceInterface] do
 artifact = "/home/user/tmp/product-online-20261014/round2/constructor-context-117/host/" <> Atom.to_string(module) <> ".beam"
 {:module, ^module} = :code.load_binary(module, String.to_charlist(artifact), File.read!(artifact))
end
for {module, directory} <- [{BeamLisp.BuildPlan, "constructor-context-119/host"}, {BeamLisp.AOT, "constructor-reader-native-123/host"}, {:"Elixir.BeamLisp.Ns.Reader-node", "constructor-reader-native-123/reader-beams"}, {:"Elixir.BeamLisp.Ns.Body.Reader-node", "constructor-reader-native-123/reader-beams"}, {BeamLisp.Ns.Reader, "constructor-reader-native-123/reader-beams"}, {BeamLisp.Ns.Body.Reader, "constructor-reader-native-123/reader-beams"}, {BeamLisp.Ns.Init.Reader, "constructor-reader-native-123/reader-beams"}] do
 artifact = "/home/user/tmp/product-online-20261014/round2/" <> directory <> "/" <> Atom.to_string(module) <> ".beam"
 {:module, ^module} = :code.load_binary(module, String.to_charlist(artifact), File.read!(artifact))
 IO.inspect({module, Base.encode16(:crypto.hash(:sha256, File.read!(artifact)), case: :lower)}, label: "EXACT_NATIVE_ARTIFACT")
end
saved = BeamLisp.Env.capture()
try do
 IO.inspect(BeamLisp.AOT.compile_host_file(root <> "/aot.bl", module: BeamLisp.AOT, output_dir: root <> "/host", load?: true), label: "FRESH_NATIVE_AOT")
after
 BeamLisp.Env.bind(saved)
end
fixtures = [{"stream", "aot-derived-stream-test", ["construction-defers-all-interpreted-producers", "derived-nodes-have-canonical-lazy-identity-and-no-public-capability-shape", "admitted-finite-values-match-the-canonical-lazy-runtime", "first-and-nth-force-the-native-chunk-and-no-unused-next-chunk", "sparse-filter-scans-past-empty-chunks-without-truncating", "completed-cells-and-full-folds-memoize-the-producer", "short-fold-and-concat-boundary-do-not-run-unused-producers", "closed-opaque-input-gates-survive-deferred-construction", "reviewed-core-callbacks-are-authorized-at-creation", "exact-seeded-cpp-wrapper-registers-only-machine-created-authority", "mapcat-eagerly-maps-outer-input-but-defers-each-returned-sequence"], 65}]
ok = Enum.reduce(fixtures, true, fn {label, namespace, names, expected}, previous ->
 file = root <> "/" <> label <> ".direct.bl"
 try do
  if label == "machine" do
   :ok = BeamLisp.Env.push_load_path(root <> "/beam")
   BeamLisp.Loader.ensure_loaded("data.first-order")
   BeamLisp.Loader.ensure_loaded("proc.tick")
   for selected <- ["proc.server", "proc.tick"] do
    definitions = BeamLisp.Env.ns_defs(selected)
    bytes = :erlang.term_to_binary(definitions)
    true = byte_size(bytes) <= 8 * 1024 * 1024
    File.write!(root <> "/" <> selected <> ".env-anf.term", bytes)
   end
  end
  BeamLisp.Compiler.eval_string(File.read!(file), BeamLisp.Compiler.new_env(namespace), file)
  crashes = Enum.flat_map(names, fn name ->
   try do
    IO.inspect({label, name}, label: "NATIVE_CASE_START")
    BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(namespace, name), [])
    progress = BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(namespace, "direct-report"), [])
    IO.inspect({label, name, Map.take(progress, [:pass, :assertions])}, label: "NATIVE_CASE_PROGRESS")
    []
   rescue error ->
    IO.inspect({label, name, error, BeamLisp.ExInfo.ex_data(error), __STACKTRACE__}, label: "CASE_CRASH", limit: 40)
    [name]
   end
  end)
  report = BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(namespace, "direct-report"), [])
  IO.inspect({label, report, crashes}, label: "NATIVE_ASSERTIONS", limit: :infinity)
  previous and crashes == [] and report[:assertions] == expected and report[:assertions] == report[:pass]
 rescue error ->
  IO.inspect({label, error, BeamLisp.ExInfo.ex_data(error), __STACKTRACE__}, label: "FILE_CRASH", limit: 40)
  false
 end
end)
System.halt(if ok, do: 0, else: 1)
