#!/usr/bin/env python3
"""No VM: verify the frozen attempt and complete tracked Main inputs."""
import argparse,hashlib,json,os,subprocess
from pathlib import Path
HERE=Path(__file__).resolve().parent
MAIN=Path('/home/user/code/undefine/beam-lisp')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
p=argparse.ArgumentParser();p.add_argument('--post-publication',action='store_true');args=p.parse_args()
x=json.loads((HERE/'inputs.json').read_text())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=MAIN,text=True).strip()==x['source_commit'],'Main HEAD changed'
tracked=sorted(n for n in subprocess.check_output(['git','ls-files','-z'],cwd=MAIN).decode().split('\0') if n and not n.startswith('priv/bootstrap/seed/'))
assert tracked==[r['path'] for r in x['tracked_inputs']],'Tracked Main path inventory changed'
for r in x['tracked_inputs']:
 f=MAIN/r['path']
 assert sha(f)==r['sha256'] and f.lstat().st_mode&0o777==r['mode'],f'Main input drift: {r["path"]}'
 assert ('linkTarget' in r)==f.is_symlink(),f'Main input type drift: {r["path"]}'
 if f.is_symlink():assert os.readlink(f)==r['linkTarget']
status=subprocess.check_output(['git','status','--porcelain','-z'],cwd=MAIN).decode().split('\0')
assert all(not s or (args.post_publication and s[3:].startswith('priv/bootstrap/seed/')) for s in status),'Unexpected tracked/untracked Main mutation'
for name,digest in x['files'].items():assert sha(HERE/name)==digest,f'Attempt control drift: {name}'
for r in x['native_assets']:assert sha(MAIN/r['path'])==r['sha256'],f'Native/launcher drift: {r["path"]}'
for r in x['substrate_sources']:assert sha(Path(x['substrate_directory'])/r['path'])==r['sha256'],f'Recovery substrate drift: {r["path"]}'
dep=x['substrate_dependency']
assert sha(dep['attemptInputs'])==dep['attemptInputsSha256'] and sha(dep['inventoryFile'])==dep['inventorySha256']
parent=x['accepted_parent'];old=Path(parent['directory'])
for r in x['accepted_seed']:assert sha(old/'seed'/r['path'])==r['sha256'],'Accepted218 seed snapshot drift'
if not args.post_publication:
 seed=MAIN/'priv/bootstrap/seed'
 assert sorted(str(f.relative_to(seed)) for f in seed.rglob('*') if f.is_file())==[r['path'] for r in x['accepted_seed']]
 for r in x['accepted_seed']:assert sha(seed/r['path'])==r['sha256'],'Installed accepted218 seed drift'
else:
 assert sum(f.is_file() for f in (MAIN/'priv/bootstrap/seed').rglob('*'))==104,'Official publication must install exactly104 seed files'
for k in ['inputs','parent','script','log']:assert sha(old/parent[k]['path'])==parent[k]['sha256'],f'Accepted parent drift: {k}'
r=json.loads((old/parent['parent']['path']).read_text())
assert r['exitCode']==0 and r['scriptSha256']==parent['script']['sha256'] and r['logSha256']==parent['log']['sha256']
print(json.dumps({'frozenControls':True,'trackedInputs':len(tracked),'sourceCommit':x['source_commit'],'compilerKey':x['expected_compiler_key'],'postPublication':args.post_publication}))
