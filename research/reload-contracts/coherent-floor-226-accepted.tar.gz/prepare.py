#!/usr/bin/env python3
"""Root-only freeze after reviewed Source commits. No VM, Main mutation or lease."""
import argparse,hashlib,json,os,shutil,subprocess
from pathlib import Path
HERE=Path(__file__).resolve().parent
MAIN=Path('/home/user/code/undefine/beam-lisp')
DEPENDENCY=json.loads((HERE/'substrate-dependency.json').read_text())
SUBSTRATE=Path(DEPENDENCY['directory'])
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=MAIN)
def row(p,base):
 r={'path':str(p.relative_to(base)),'sha256':sha(p),'mode':p.lstat().st_mode&0o777}
 if p.is_symlink():r['linkTarget']=os.readlink(p)
 return r
def tree(base):
 rows=[dict(row(p,base),kind='symlink' if p.is_symlink() else 'file',bytes=p.stat().st_size) for p in sorted(base.rglob('*')) if (p.is_file() or p.is_symlink()) and p.relative_to(base).parts[0] not in ['build','.bl']]
 for r in rows:
  if 'linkTarget' in r:r['target']=r.pop('linkTarget')
 return rows
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--reviewed-source',required=True,type=Path)
a=p.parse_args()
assert not (HERE/'inputs.json').exists(),'Preserve existing frozen attempt'
assert not git('status','--porcelain'),'Commit reviewed Source before freezing'
review=json.loads(a.reviewed_source.read_text())['sha256']
required={'priv/host/aot.bl','priv/host/env.bl','priv/boot/core.bl','priv/boot/compiler.bl','priv/boot/rt.bl','scripts/regenerate-seed.bl','scripts/install-seed.bl','env.bl','bin/bl','bin/bl-stage-hosts'}
assert set(review)==required,'Exact complete reviewed compiler/build/launcher hash set required'
assert all(len(d)==64 and sha(MAIN/n)==d for n,d in review.items()),'Actual Source differs from reviewed Source'
parent=json.loads((HERE/'accepted-parent.json').read_text());old=Path(parent['directory'])
for name in ['inputs','parent','script','log']:
 assert sha(old/parent[name]['path'])==parent[name]['sha256'],f'Accepted218 {name} drift'
receipt=json.loads((old/parent['parent']['path']).read_text())
assert receipt['exitCode']==0 and receipt['scriptSha256']==parent['script']['sha256'] and receipt['logSha256']==parent['log']['sha256']
assert b'FINAL_COHERENT_FLOOR_BUILD_CHECK_INSTALL_FINISHED' in (old/parent['log']['path']).read_bytes()
prior=json.loads((old/'inputs.json').read_text())
seed_root=old/'seed'
seed_paths=sorted(f for f in seed_root.rglob('*') if f.is_file())
assert len(seed_paths)==104,'Accepted218 seed must contain exactly104 files'
accepted_seed=[{'path':str(f.relative_to(seed_root)),'sha256':sha(f)} for f in seed_paths]
main_seed=MAIN/'priv/bootstrap/seed'
assert sorted(str(f.relative_to(main_seed)) for f in main_seed.rglob('*') if f.is_file())==[r['path'] for r in accepted_seed]
assert all(sha(main_seed/r['path'])==r['sha256'] for r in accepted_seed),'Installed seed differs from accepted218'
assert review['priv/host/env.bl']==next(r['sha256'] for r in prior['sources'] if r['path']=='priv/host/env.bl'),'225 retains four-table Env contract; changed Env requires review/new probe'
sub=json.loads((HERE/'substrate-inputs.json').read_text())
assert sub['substrateCommit']=='08324189e82d51275bdfbb39a76076ee9879dcb4'
assert sha(SUBSTRATE/'priv/bootstrap/seed/manifest.term')==sub['expectedManifestSha256']
assert sha(DEPENDENCY['attemptInputs'])==DEPENDENCY['attemptInputsSha256']
assert sha(DEPENDENCY['inventoryFile'])==DEPENDENCY['inventorySha256']
frozen_tree=json.loads((HERE/'substrate-tree.json').read_text())
actual_tree=tree(SUBSTRATE)
# The input inventory is complete, including genuine193 seed and Source. No runtime build yet.
assert [{k:r[k] for k in r if k!='bytes'} for r in actual_tree]==[{k:r[k] for k in r if k!='bytes'} for r in frozen_tree],'Copied193 recovery tree changed'
for r in sub['assets']:
 assert sha(SUBSTRATE/r['path'])==sha(MAIN/r['path'])==r['sha256']
assets=sub['assets']+[{'path':n,'sha256':sha(MAIN/n)} for n in ['bin/bl','bin/bl-stage-hosts']]
# The actual launcher seam may change only recovery ROOT and final diagnostic entry.
launcher=(MAIN/'bin/bl').read_text()
a_root='ROOT=$(CDPATH=\'\' cd "$(dirname "$0")/.." && pwd -P)'
a_exec='exec elixir $PA -e \'BeamLisp.Launcher.main()\' -- "$@"'
assert launcher.count(a_root)==launcher.count(a_exec)==1
expected=launcher.replace(a_root,'ROOT='+str(SUBSTRATE)).replace(a_exec,'exec elixir $PA -e \'Code.eval_file(System.fetch_env!("BL_DIAGNOSTIC"))\' -- "$@"')
assert (HERE/'source-bootstrap-wrapper').read_text()==expected,'Launcher diagnostic seam differs'
for name in ['ebin','tmp','aot-cache']:
 q=HERE/name
 assert not q.exists() or not list(q.iterdir()),f'Attempt output already populated: {name}'
 q.mkdir(exist_ok=True)
cache=[]
for f in sorted(Path(parent['bootCandidates']).iterdir()):
 if f.is_file() and not f.is_symlink():
  dest=HERE/'ebin'/f.name;shutil.copy2(f,dest)
  cache.append({'path':str(dest.relative_to(HERE)),'sha256':sha(dest),'source':str(f),'scope':'Optional boot candidate; official current-key/Source build revalidates or rebuilds'})
hashparts=lambda ps:hashlib.sha256(b'\0'.join(ps)).hexdigest()
leaves=['aot','atom_guard','compiler_data','source_graph','ns_interface','build_plan','record','emit','optimize','link','tiers']
names=['AOT','AtomGuard','CompilerData','SourceGraph','NamespaceInterface','BuildPlan','Record','Emit','Optimize','Link','Tiers']
parts=[b'codegen']
for leaf,name in zip(leaves,names):parts.extend([(MAIN/'priv/host'/f'{leaf}.bl').read_bytes(),('Elixir.BeamLisp.'+name).encode()])
codegen=hashparts(parts)
tier=sorted(list((MAIN/'priv/boot').rglob('*.bl'))+list((MAIN/'priv/self').rglob('*.bl')))
key=hashparts([b'elixir:1.20.4',b'otp:29',b'aot_backend:core',('codegen-source:'+codegen).encode()]+[f.read_bytes() for f in tier])
tracked=[n for n in git('ls-files','-z').decode().split('\0') if n and not n.startswith('priv/bootstrap/seed/')]
paths=sorted({n for n in tracked if n.endswith(('.bl','.bl.md','.bl.org','.clj','.cljc','.rs')) or Path(n).name in ('Cargo.toml','Cargo.lock','build.rs')}|{'scripts/regenerate-seed.bl','scripts/install-seed.bl','env.bl'})
subpaths=sorted(str(f.relative_to(SUBSTRATE)) for base in ['priv/host','priv/boot','priv/self','priv/build'] for f in (SUBSTRATE/base).rglob('*.bl'))
subpaths+=['priv/bootstrap/seed/manifest.term']+[r['path'] for r in sub['assets']]
controls=['command.sh','probe.exs','source-bootstrap-wrapper','prepare.py','preflight.py','project.direct.bl','substrate-inputs.json','substrate-tree.json','accepted-parent.json','substrate-dependency.json','reviewed-source.json','PLAN.org']
shutil.copyfile(a.reviewed_source,HERE/'reviewed-source.json') if a.reviewed_source.resolve()!=HERE/'reviewed-source.json' else None
x={'scope':'Root-only coherent floor226: scoped bootstrap manifest snapshot, Symbol author metadata and checked stable SDK callable materialization with nil compatibility and6 unconditional read-only native preflight checks; no SDK/ordinary/owner acceptance','source_commit':git('rev-parse','HEAD').decode().strip(),'accepted_parent':parent,'accepted_seed':accepted_seed,'substrate_directory':str(SUBSTRATE),'substrate_dependency':DEPENDENCY,'substrate_commit':sub['substrateCommit'],'runtime':{'elixir':'1.20.4','otp':'29','backend':'core'},'expected_compiler_key':key,'codegen_digest':codegen,'reviewed_source':review,'sources':[row(MAIN/n,MAIN) for n in paths],'tracked_inputs':[row(MAIN/n,MAIN) for n in sorted(tracked)],'substrate_sources':[{'path':n,'sha256':sha(SUBSTRATE/n)} for n in subpaths],'native_assets':assets,'files':{n:sha(HERE/n) for n in controls},'boot_cache':cache,'project_assertions':15,'bootstrap_callable_preflight':{'nativeChecks':6,'factoryExecutions':0,'placement':'Official actual script after16hostemissions/15loads before13bootunits'},'launch_budget':{'memoryMax':'6G','memorySwapMax':0,'runtimeMaxSec':2700},'host_policy':'16 compile all before15load; LazyMemo emit-only; all4 unchanged Env private tables native-created/empty in recovery; acceptanceVM creates its own','publication':'Official seed/run + complete83 Source check +104 manifest-last installed files; never relabel','unit_tests_expected_only':{'metadata':{'cases':7,'assertions':42},'snapshot':{'cases':3,'assertions':18},'materializer':{'cases':6,'assertions':62}},'subsequent_gates':'Metadata42/snapshot18/materializer62 unit assertions are NOT executed by this build floor; current SDK/native custody, normal CLI and product are independent UNRUN acceptance gates'}
(HERE/'inputs.json').write_text(json.dumps(x,indent=2)+'\n')
print(json.dumps({'ready':str(HERE),'sources':len(x['sources']),'trackedInputs':len(x['tracked_inputs']),'nativeAssets':len(assets),'substrateSources':len(subpaths),'bootCacheFiles':len(cache),'compilerKey':key,'sourceCommit':x['source_commit'],'inputsSha256':sha(HERE/'inputs.json')}))
