# Fixed SDK analysis only. This minimal bootstrap is not ordinary application
# startup acceptance and runs no application initializer/listener/store/provider.
Application.load(:beam_lisp)
{:ok, dependencies} = :application.get_key(:beam_lisp, :applications)
Enum.each(dependencies, fn dep -> {:ok, _} = Application.ensure_all_started(dep) end)
IO.inspect(BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN")), label: "VERIFIED_FLOOR")
BeamLisp.AOT.boot()
BeamLisp.Loader.ensure_loaded("proc.tick")
for namespace <- ["proc.server", "proc.tick", "proc.reg"] do
  module = BeamLisp.Emit.module_for(namespace)
  if :code.is_loaded(module) != false and function_exported?(module, :__bl_ns_defs__, 0) do
    metadata = apply(module, :__bl_ns_defs__, [])
    bytes = :erlang.term_to_binary(metadata)
    true = byte_size(bytes) <= 8 * 1024 * 1024
    destination = System.fetch_env!("BL_DIAGNOSTIC_OUTPUT") <> "/" <> namespace <> ".anf.term"
    File.write!(destination, bytes)
    File.write!(destination <> ".txt", inspect(metadata, pretty: true, limit: :infinity, printable_limit: :infinity))
    IO.inspect({namespace, byte_size(bytes)}, label: "FIXED_SDK_LITERAL_ANF_DUMP")
  end
end
