Code.ensure_loaded!(BeamLisp.AOT)
Code.ensure_loaded!(BeamLisp.Loader)
tracer = spawn(fn ->
  loop = fn loop ->
    receive do
      {:trace, pid, :call, {BeamLisp.AOT, :compile_source, [source, _opts]}} ->
        IO.inspect({pid, BeamLisp.Loader.declared_ns(source)}, label: "SDK_COMPILE_NAMESPACE")
        loop.(loop)
      {:trace, pid, :call, {BeamLisp.Loader, :maybe_load_macro, arguments}} ->
        IO.inspect({pid, arguments}, label: "SDK_PROC_SERVER_MACRO_PROBE")
        loop.(loop)
      {:flush, caller, ticket} -> send(caller, {:flushed, ticket}); loop.(loop)
      _ -> loop.(loop)
    end
  end
  loop.(loop)
end)
:erlang.trace_pattern({BeamLisp.AOT, :compile_source, 2}, [{:_, [], []}], [:local])
:erlang.trace_pattern({BeamLisp.Loader, :maybe_load_macro, 2}, [{["proc.server", :_], [], []}], [:local])
:erlang.trace(:all, true, [:call, :set_on_spawn, {:tracer, tracer}])
try do
  BeamLisp.Launcher.main()
rescue
  error ->
    IO.inspect(error, label: "STARTUP_EXCEPTION", limit: 60)
    IO.inspect(BeamLisp.ExInfo.ex_data(error), label: "STARTUP_REFUSAL_DATA", limit: 60)
    IO.inspect(__STACKTRACE__, label: "STARTUP_REFUSAL_STACK", limit: 100)
    # Read only compiler-emitted literal ANF metadata, never runtime variables
    # or a source callback. Failed startup may already have stopped Env.
    for namespace <- ["proc.server", "proc.tick", "proc.reg"] do
      module = BeamLisp.Emit.module_for(namespace)
      if :code.is_loaded(module) != false and function_exported?(module, :__bl_ns_defs__, 0) do
        metadata = apply(module, :__bl_ns_defs__, [])
        bytes = :erlang.term_to_binary(metadata)
        if byte_size(bytes) <= 8 * 1024 * 1024 do
          File.write!(System.fetch_env!("BL_DIAGNOSTIC_OUTPUT") <> "/" <> namespace <> ".anf.term", bytes)
          IO.inspect({namespace, byte_size(bytes)}, label: "SDK_LITERAL_ANF_DUMP")
        end
      end
    end
    ticket = make_ref()
    send(tracer, {:flush, self(), ticket})
    receive do {:flushed, ^ticket} -> :ok after 1000 -> :ok end
    System.halt(1)
end
