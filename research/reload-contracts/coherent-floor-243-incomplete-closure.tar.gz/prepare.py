#!/usr/bin/env python3
"""Root-only freeze of a NEW final floor attempt. No VM or Main/Source mutation."""
from pathlib import Path
import argparse,json,os,shutil,subprocess
import controls as c
HERE=Path(__file__).resolve().parent
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--check-prerequisites',action='store_true');p.add_argument('--write-review-example',type=Path);p.add_argument('--reviewed-source',type=Path);p.add_argument('--native-transition',type=Path,default=c.NATIVE_TRANSITION);p.add_argument('--boot-candidates',type=Path);p.add_argument('--output',type=Path);a=p.parse_args()
if a.write_review_example:
 x={'scope':'Observed current Source; Root must review after all pending semantic changes before freeze','sourceCommit':c.git('rev-parse','HEAD').decode().strip(),'sha256':{n:c.sha(c.MAIN/n) for n in c.review_paths()}}
 assert not a.write_review_example.exists();a.write_review_example.write_text(json.dumps(x,indent=2)+'\n');print(json.dumps({'reviewObservationOnly':str(a.write_review_example),'files':len(x['sha256'])}));raise SystemExit
accepted=c.accepted226();env=c.historical_env235();recovery=c.recovery();native=c.native_transition(a.native_transition);official=c.official_contract()
if a.check_prerequisites:
 print(json.dumps({'state':'UNFROZEN; no VM','acceptedInputSeedFiles':104,'historicalEnvChecks':128,'recoveryFiles':len(recovery['physicalTree']),'nativeTransition':native['proof']['newSha256'],'official':official,'pendingRootSourceReview':True}));raise SystemExit
assert a.output and a.reviewed_source,'Require NEW --output and Root --reviewed-source'
assert not c.git('status','--porcelain'),'Root must finish/commit all semantic Source and evidence before freezing'
output=a.output.resolve();assert output.is_relative_to(c.R2) and not output.exists() and output!=HERE,'Preserve every prior frozen attempt/template'
review=json.loads(a.reviewed_source.read_text());assert review['sourceCommit']==c.git('rev-parse','HEAD').decode().strip()
assert sorted(review['sha256'])==c.review_paths(),'Complete official Host+boot+self+build+scripts/launcher Source review required'
assert all(c.sha(c.MAIN/n)==digest for n,digest in review['sha256'].items())
compiler,build,codegen=c.keys();output.mkdir(mode=0o700)
for name in ['controls.py','prepare.py','preflight.py','probe.exs','command.sh','project.direct.bl','PLAN.org']:
 shutil.copyfile(HERE/name,output/name)
for name in ['prepare.py','preflight.py','command.sh']:(output/name).chmod(0o700)
shutil.copyfile(a.reviewed_source,output/'reviewed-source.json')
launcher=(c.MAIN/'bin/bl').read_text();root_seam='ROOT=$(CDPATH=\'\' cd "$(dirname "$0")/.." && pwd -P)';exec_seam='exec elixir $PA -e \'BeamLisp.Launcher.main()\' -- "$@"'
assert launcher.count(root_seam)==launcher.count(exec_seam)==1
wrapper=launcher.replace(root_seam,'ROOT='+str(c.SUBSTRATE)).replace(exec_seam,'exec elixir $PA -e \'Code.eval_file(System.fetch_env!("BL_DIAGNOSTIC"))\' -- "$@"')
(output/'source-bootstrap-wrapper').write_text(wrapper);(output/'source-bootstrap-wrapper').chmod(0o700)
for name in ['ebin','tmp','aot-cache']:(output/name).mkdir()
cache=[]
if a.boot_candidates:
 assert a.boot_candidates.resolve()==(c.FLOOR/'ebin').resolve(),'Only observed226 output candidates permitted, never SDK authority'
 for f in sorted(a.boot_candidates.iterdir()):
  assert f.is_file() and not f.is_symlink()
  assert f.suffix=='.beam' or f.name=='beam_lisp.app'
  dest=output/'ebin'/f.name;shutil.copyfile(f,dest)
  cache.append({'path':'ebin/'+f.name,'sha256':c.sha(dest),'source':str(f),'scope':'UNTRUSTED optional226 boot bytes; official fresh Source/key check must rebuild or validate'})
tracked=c.tracked_paths();sources=c.physical_source_paths();assets=c.native_paths()
control_names=['controls.py','prepare.py','preflight.py','probe.exs','command.sh','project.direct.bl','PLAN.org','reviewed-source.json','source-bootstrap-wrapper']
x={'scope':'Root-only final coherent Source floor via genuine193 recovery; actual226 input seed; new native table/Source/command ABI and current official preflights. No SDK/ordinary/product authority claimed','source_commit':review['sourceCommit'],'runtime':{'elixir':'1.20.4','otp':'29','backend':'core'},'expected_compiler_key':compiler,'expected_build_key':build,'codegen_digest':codegen,'accepted_parent':accepted,'accepted_seed':accepted['seed'],'historical_env235':env,'substrate_directory':str(c.SUBSTRATE),'substrate_commit':recovery['commit'],'recovery':recovery,'native_transition':native,'official_contract':official,'reviewed_source':review,'tracked_inputs':[c.record(c.MAIN/n,c.MAIN) for n in tracked],'sources':[c.record(c.MAIN/n,c.MAIN) for n in sources],'native_assets':[c.record(c.MAIN/n,c.MAIN) for n in assets],'files':{n:c.sha(output/n) for n in control_names},'boot_cache':cache,'project_assertions':15,'launch_budget':{'memoryMax':'6G','memorySwapMax':0,'runtimeMaxSec':2700},'inputSeedCount':104,'outputSeedCount':'DYNAMIC exact official validated manifest; current companion additions expected but UNRUN','subsequent_gates':'Current SDK/lifetime/command/Source privacy, normal CLI, large data and product are separate UNRUN gates'}
(output/'inputs.json').write_text(json.dumps(x,indent=2)+'\n')
print(json.dumps({'ready':str(output),'inputsSha256':c.sha(output/'inputs.json'),'SourceCommit':x['source_commit'],'compilerKey':compiler,'buildKey':build,'trackedInputs':len(tracked),'physicalSources':len(sources),'nativeAssets':len(assets),'outputSeedCount':'dynamic','native':'UNRUN'}))
