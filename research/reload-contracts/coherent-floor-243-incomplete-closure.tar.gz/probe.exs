# Root-only compiler recovery from genuine committed coherent193.
# This VM never claims current ordinary startup or old admitted-owner custody.
root=System.fetch_env!("BL_PROBE_ROOT")
{_,0}=System.cmd("python3",[root<>"/preflight.py"])
main="/home/user/code/undefine/beam-lisp"
^main=File.cwd!()
sha=fn p->Base.encode16(:crypto.hash(:sha256,File.read!(p)),case: :lower) end
inputs=:json.decode(File.read!(root<>"/inputs.json"))
Enum.each(inputs["sources"]++inputs["native_assets"],fn row->true=sha.(main<>"/"<>row["path"])==row["sha256"] end)
Enum.each(inputs["files"],fn {p,d}->true=sha.(root<>"/"<>p)==d end)
substrate=inputs["substrate_directory"]
Enum.each(inputs["recovery"]["physicalTree"],fn row->true=sha.(substrate<>"/"<>row["path"])==row["sha256"] end)
Application.load(:beam_lisp)
{:ok,deps}=:application.get_key(:beam_lisp,:applications)
Enum.each(deps,fn d->{:ok,_}=Application.ensure_all_started(d) end)
:ok=BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
BeamLisp.AOT.boot()
false=:ets.member(:beam_lisp_vars,:bl_sdk_runtime_lease)
true=:ets.info(:beam_lisp_owner_index,:size)==0
# The historical four tables exist through ACTUAL193 Env.start_link;
# the official current script initializes the full17 through that actual owner.
# No external table creation, invented admitted owner, or SDK lease is allowed.
private_tables=[:beam_lisp_server_starts,:beam_lisp_owner_transitions,:beam_lisp_owner_transition_heads,:beam_lisp_server_initializers]
Enum.each(private_tables,fn table->
 :private=:ets.info(table,:protection)
 true=:ets.info(table,:owner)==Process.whereis(BeamLisp.Env)
 0=:ets.info(table,:size)
end)
IO.inspect(%{substrateCommit: inputs["substrate_commit"],sdkLease: false,ownerRows: 0,nativeCreatedPrivateTables: 4},label: "GENUINE_RECOVERY_193_NO_ADMITTED_OWNERS")
System.put_env("BL_ROOT",main)
true=Code.prepend_path(main<>"/.bl/lib/beam_lisp-0.1.0/ebin")
BeamLisp.Env.add_search_path(main<>"/priv/build")
BeamLisp.AOTCache.reset_keys()
true=System.version()==inputs["runtime"]["elixir"]
true=List.to_string(:erlang.system_info(:otp_release))==inputs["runtime"]["otp"]
true=BeamLisp.AOTCache.compiler_key()==inputs["expected_compiler_key"]
true=BeamLisp.AOTCache.current_compiler_key()==inputs["expected_compiler_key"]
true=BeamLisp.AOTCache.current_build_key()==inputs["expected_build_key"]
IO.inspect(%{literalExpected: inputs["expected_compiler_key"],actual: BeamLisp.AOTCache.compiler_key()},label: "FINAL_SOURCE_COMPILER_KEY_VERIFIED")
Enum.each(inputs["boot_cache"],fn row->true=sha.(root<>"/"<>row["path"])==row["sha256"] end)
file=root<>"/project.direct.bl"
namespace="regenerate-seed-project-test"
BeamLisp.Compiler.eval_string(File.read!(file),BeamLisp.Compiler.new_env(namespace),file)
Enum.each(["physical-project-preflight-ignores-missing-or-foreign-cli-cache","invalid-physical-project-refuses-before-any-host-or-build-output"],fn name->
 BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(namespace,name),[])
end)
report=BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(namespace,"direct-report"),[])
IO.inspect(report,label: "FINAL_PROJECT_PREFLIGHT_15_ASSERTIONS")
true=report[:pass]==15 and report[:assertions]==15
false=:ets.member(:beam_lisp_vars,:bl_sdk_runtime_lease)
IO.inspect(%{expectedOutputSeedCount: :dynamic, inputAccepted226SeedFiles: 104},label: "CURRENT_OFFICIAL_MANIFEST_OUTPUT_REQUIRED")
script=main<>"/scripts/regenerate-seed.bl"
BeamLisp.Compiler.eval_string(File.read!(script),BeamLisp.Compiler.new_env("tooling.regenerate-seed"),script)
Enum.each(inputs["sources"]++inputs["native_assets"],fn row->true=sha.(main<>"/"<>row["path"])==row["sha256"] end)
false=:ets.member(:beam_lisp_vars,:bl_sdk_runtime_lease)
true=:ets.info(:beam_lisp_owner_index,:size)==0
Enum.each(inputs["official_contract"]["tables"],fn table->
 name=String.to_existing_atom(table["name"])
 true=:ets.info(name,:owner)==Process.whereis(BeamLisp.Env)
 true=Atom.to_string(:ets.info(name,:protection))==table["protection"]
 true=Atom.to_string(:ets.info(name,:type))==table["type"]
end)
Enum.each(inputs["official_contract"]["currentSourceEnvExports"]++inputs["official_contract"]["currentNativeCommandExports"],fn [name,arity]->
 true=function_exported?(BeamLisp.Env,String.to_existing_atom(name),arity)
end)
false=BeamLisp.Env.native_command_critical_active?()
IO.inspect(%{actualNativeOwnedTables: 17, private: 11, protected: 2, public: 4, sdkLease: false, ownerRows: 0},label: "CURRENT_COUPLED_ENV_TABLE_CUSTODY_VERIFIED")
{_,0}=System.cmd("python3",[root<>"/preflight.py","--post-publication"])
IO.puts("FINAL_COHERENT_FLOOR_BUILD_CHECK_INSTALL_FINISHED")
System.halt(0)
