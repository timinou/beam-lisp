#!/usr/bin/env python3
"""Read-only pre/post Source/native/recovery controls. Output proof writes HOME only."""
from pathlib import Path
import argparse,json
import controls as c
HERE=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--post-publication',action='store_true');a=p.parse_args();x=json.loads((HERE/'inputs.json').read_text())
assert c.git('rev-parse','HEAD').decode().strip()==x['source_commit'],'Main HEAD drift'
assert c.tracked_paths()==[r['path'] for r in x['tracked_inputs']]
c.verify_rows(c.MAIN,x['tracked_inputs']);c.verify_rows(c.MAIN,x['sources']);c.verify_rows(c.MAIN,x['native_assets'])
assert c.physical_source_paths()==[r['path'] for r in x['sources']],'Physical Source path addition/removal'
assert c.native_paths()==[r['path'] for r in x['native_assets']],'Native path addition/removal'
status=c.git('status','--porcelain','-z').decode().split('\0')
assert all(not s or (a.post_publication and s[3:].startswith('priv/bootstrap/seed/')) for s in status),'Unexpected Main mutation'
for name,digest in x['files'].items():assert c.sha(HERE/name)==digest,'Control drift: '+name
assert c.keys()==(x['expected_compiler_key'],x['expected_build_key'],x['codegen_digest'])
c.verify_rows(c.SUBSTRATE,x['recovery']['physicalTree'])
for d in x['recovery']['dependencies']:c.verify_dependency(d)
assert c.accepted226(require_installed=not a.post_publication)==x['accepted_parent']
assert c.historical_env235()==x['historical_env235']
assert c.native_transition(x['native_transition']['receipt']['path'])==x['native_transition']
assert json.loads(json.dumps(c.official_contract()))==x['official_contract']
if a.post_publication:
 output=c.output_seed(HERE/'seed');installed=c.output_seed(c.MAIN/'priv/bootstrap/seed')
 assert output==installed,'Installed output is not exact official generated floor'
 assert output['keys']=={'compiler_key':x['expected_compiler_key'],'build_key':x['expected_build_key']}
 receipt={'scope':'Actual official output inventory/bytes after Native source/key checks; parent service acceptance still required','inputSeedCount':104,'outputSeed':output,'inputsSha256':c.sha(HERE/'inputs.json'),'sourceCommit':x['source_commit'],'noSeedRestamping':True}
 path=HERE/'publication.json';encoded=json.dumps(receipt,indent=2)+'\n'
 if path.exists():assert path.read_text()==encoded
 else:path.write_text(encoded)
print(json.dumps({'frozenControls':True,'sourceCommit':x['source_commit'],'compilerKey':x['expected_compiler_key'],'postPublication':a.post_publication,'outputSeedCount':output['count'] if a.post_publication else 'UNRUN'}))
