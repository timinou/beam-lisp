Application.load(:beam_lisp)
{:ok, deps} = :application.get_key(:beam_lisp, :applications)
Enum.each(deps, fn dep -> {:ok, _} = Application.ensure_all_started(dep) end)
:ok = BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
false = BeamLisp.LazyMemo.nif_loaded?()
module = BeamLisp.LazyMemo
artifact = "/home/user/tmp/product-online-20261014/round2/lazy-host-native-151/host/Elixir.BeamLisp.LazyMemo.beam"
{:module, ^module} = :code.load_binary(module, String.to_charlist(artifact), File.read!(artifact))
IO.inspect(Base.encode16(:crypto.hash(:sha256, File.read!(artifact)), case: :lower), label: "FRESH_PRE_NIF_HOST_SHA256")
BeamLisp.AOT.boot()
true = BeamLisp.LazyMemo.nif_loaded?()
IO.inspect({BeamLisp.Tiers.priv_root(), Base.encode16(:crypto.hash(:sha256, File.read!(BeamLisp.Tiers.priv_root() <> "/native/lazy_memo.so")), case: :lower), BeamLisp.LazyMemo.collector_status()}, label: "FRESH_NATIVE_COLLECTOR")
root = System.fetch_env!("BL_PROBE_ROOT")
# Reuse the exact Compiler artifacts produced and hashed by native106.
# This is a diagnostic overlay, never a coherent-floor acceptance.
for module <- [BeamLisp.Ns.Compiler, BeamLisp.Ns.Body.Compiler, BeamLisp.Ns.Init.Compiler] do
 artifact = "/home/user/tmp/product-online-20261014/round2/compiler-metadata-native-127/compiler-beams/" <> Atom.to_string(module) <> ".beam"
 {:module, ^module} = :code.load_binary(module, String.to_charlist(artifact), File.read!(artifact))
 IO.inspect({module, Base.encode16(:crypto.hash(:sha256, File.read!(artifact)), case: :lower)}, label: "REUSED_NATIVE_COMPILER")
end
for module <- [BeamLisp.SourceGraph, BeamLisp.NamespaceInterface] do
 artifact = "/home/user/tmp/product-online-20261014/round2/constructor-context-117/host/" <> Atom.to_string(module) <> ".beam"
 {:module, ^module} = :code.load_binary(module, String.to_charlist(artifact), File.read!(artifact))
end
for {module, directory} <- [{BeamLisp.BuildPlan, "constructor-context-119/host"}, {BeamLisp.AOT, "constructor-reader-native-123/host"}, {:"Elixir.BeamLisp.Ns.Reader-node", "constructor-reader-native-123/reader-beams"}, {:"Elixir.BeamLisp.Ns.Body.Reader-node", "constructor-reader-native-123/reader-beams"}, {BeamLisp.Ns.Reader, "constructor-reader-native-123/reader-beams"}, {BeamLisp.Ns.Body.Reader, "constructor-reader-native-123/reader-beams"}, {BeamLisp.Ns.Init.Reader, "constructor-reader-native-123/reader-beams"}] do
 artifact = "/home/user/tmp/product-online-20261014/round2/" <> directory <> "/" <> Atom.to_string(module) <> ".beam"
 {:module, ^module} = :code.load_binary(module, String.to_charlist(artifact), File.read!(artifact))
 IO.inspect({module, Base.encode16(:crypto.hash(:sha256, File.read!(artifact)), case: :lower)}, label: "EXACT_NATIVE_ARTIFACT")
end
for {module, folder} <- [{BeamLisp.CompilerData, "constructor-resource-free-native-147"}, {BeamLisp.AOT, "constructor-integrated-native-144"}] do
 artifact = "/home/user/tmp/product-online-20261014/round2/" <> folder <> "/host/" <> Atom.to_string(module) <> ".beam"
 {:module, ^module} = :code.load_binary(module, String.to_charlist(artifact), File.read!(artifact))
 IO.inspect({module, Base.encode16(:crypto.hash(:sha256, File.read!(artifact)), case: :lower)}, label: "REUSED_NATIVE_144_ARTIFACT")
end



saved = BeamLisp.Env.capture()
try do
 IO.inspect(BeamLisp.AOT.compile_host_file(root <> "/aot.bl", module: BeamLisp.AOT, output_dir: root <> "/host", load?: true), label: "FRESH_FINAL_NATIVE_AOT")
after
 BeamLisp.Env.bind(saved)
end
fixtures = [{"cache", "aot-constructor-cache-test", ["cached-and-uncached-source-routing-remain-owned-and-shadow-aware", "final-attestation-rechecks-cached-absence-and-present-path-selection", "final-attestation-rechecks-actual-source-bytes-and-current-tooling-key", "final-kernel-proof-cannot-succeed-when-authoritative-entry-is-absent"], 13}, {"generated", "aot-ordered-generated-owner-test", ["unnamed-ordered-actor-actions-keep-their-exact-embedded-owner", "malformed-executable-actor-scaffolds-refuse-before-emission", "quoted-scaffolds-remain-inert-data", "unnamed-generated-classes-use-canonical-class-identity"], 17}, {"staging", "aot-sdk-constructor-staging-test", ["ordinary-compilation-does-not-have-sdk-constructor-authority", "ordinary-macro-kind-inspection-never-invokes-the-expander", "source-declaration-fold-uses-native-element-then-accumulator-order", "an-sdk-filename-with-different-source-refuses-before-effects", "cold-sdk-actor-source-never-borrows-mutable-core-or-initializes-provider", "canonical-native-namespace-is-not-invented-as-a-source-unit"], 27}]
ok = Enum.reduce(fixtures, true, fn {label, namespace, names, expected}, previous ->
 file = root <> "/" <> label <> ".direct.bl"
 try do
  BeamLisp.Compiler.eval_string(File.read!(file), BeamLisp.Compiler.new_env(namespace), file)
  crashes = Enum.flat_map(names, fn name ->
   try do
    IO.inspect({label, name, System.monotonic_time(:millisecond), BeamLisp.LazyMemo.stats()}, label: "NATIVE_CASE_START")
    BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(namespace, name), [])
    IO.inspect({label, name, System.monotonic_time(:millisecond)}, label: "NATIVE_CASE_COMPLETED")
    []
   rescue error ->
    IO.inspect({label, name, error, BeamLisp.ExInfo.ex_data(error), __STACKTRACE__}, label: "CASE_CRASH", limit: 30)
    [name]
   end
  end)
  report = BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(namespace, "direct-report"), [])
  IO.inspect({label, report, crashes}, label: "NATIVE_ASSERTIONS", limit: :infinity)
  previous and crashes == [] and report[:assertions] > 0 and report[:assertions] == report[:pass] and (is_nil(expected) or report[:assertions] == expected)
 rescue error ->
  IO.inspect({label, error, BeamLisp.ExInfo.ex_data(error), __STACKTRACE__}, label: "FILE_CRASH", limit: 30)
  false
 end
end)
System.halt(if ok, do: 0, else: 1)
