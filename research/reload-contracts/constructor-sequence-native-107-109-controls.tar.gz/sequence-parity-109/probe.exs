# Exact new pure native host API controls; not a coherent floor or CLI startup.
Application.load(:beam_lisp)
{:ok, dependencies} = :application.get_key(:beam_lisp, :applications)
Enum.each(dependencies, fn dep -> {:ok, _} = Application.ensure_all_started(dep) end)
:ok = BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
BeamLisp.AOT.boot()
root = System.fetch_env!("BL_PROBE_ROOT")
for module <- [BeamLisp.Ns.Compiler, BeamLisp.Ns.Body.Compiler, BeamLisp.Ns.Init.Compiler] do
 artifact = "/home/user/tmp/product-online-20261014/round2/constructor-context-106/compiler-beams/" <> Atom.to_string(module) <> ".beam"
 {:module, ^module} = :code.load_binary(module, String.to_charlist(artifact), File.read!(artifact))
end
:ok = BeamLisp.Env.push_load_path(root <> "/beam")
expected = root <> "/beam/data/first-order.bl"
true = BeamLisp.Loader.source_path("data.first-order") == expected
BeamLisp.Loader.ensure_loaded("data.first-order")
BeamLisp.Loader.ensure_loaded("proc.tick")
for namespace <- ["proc.server", "proc.tick"] do
 defs = BeamLisp.Env.ns_defs(namespace)
 bytes = :erlang.term_to_binary(defs)
 true = byte_size(bytes) <= 8 * 1024 * 1024
 File.write!(root <> "/" <> namespace <> ".env-anf.term", bytes)
 IO.inspect({namespace, map_size(defs), byte_size(bytes)}, label: "ACTUAL_NATIVE_DECLARATIONS")
end
for binding <- ["concat", "filter"] do
 IO.inspect(BeamLisp.Env.lookup({"core", binding}), label: "CORE_ABI_" <> binding, limit: 30, printable_limit: 500)
end
artifact = "/home/user/tmp/product-online-20261014/round2/constructor-context-107/host/Elixir.BeamLisp.AOT.beam"
{:module, BeamLisp.AOT} = :code.load_binary(BeamLisp.AOT, String.to_charlist(artifact), File.read!(artifact))
file = "/home/user/tmp/product-online-20261014/round2/constructor-native-108/machine.direct.bl"
BeamLisp.Compiler.eval_string(File.read!(file), BeamLisp.Compiler.new_env("aot-constructor-machine-test"), file)
BeamLisp.Compiler.eval_string(~S"""
(defn labeled-sequence-diagnostic []
 (doseq [[label value] [[:nil nil] [:empty-list (list)] [:list (list 1 2)]
                       [:vector [1 2]] [:map {:a 1 :b 2}] [:set #{1 2}] [:text "é🙂"]]]
  (println {:input label :raw value})
  (doseq [function [:first :rest :next :seq :count :empty?]]
   (let [actual (sequence-result #(erlang/apply :Elixir.BeamLisp.Ns.Rt function (list value)))
         bounded (sequence-result #(machine-sequence-call :Elixir.BeamLisp.Ns.Rt function (list value)))]
    (when-not (erlang/=:= actual bounded)
     (println {:input label :operation function :actual actual :bounded bounded}))))
  (doseq [n [-2 0 1 4] function [:take :drop_clj :drop]]
   (let [args (if (= function :drop) (list value n) (list n value))
         actual (sequence-result #(erlang/apply :Elixir.BeamLisp.Ns.Rt function args))
         bounded (sequence-result #(machine-sequence-call :Elixir.BeamLisp.Ns.Rt function args))]
    (when-not (erlang/=:= actual bounded)
     (println {:input label :operation function :n n :actual actual :bounded bounded}))))))
""", BeamLisp.Compiler.new_env("aot-constructor-machine-test"), "labeled-sequence-diagnostic")
BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!("aot-constructor-machine-test", "labeled-sequence-diagnostic"), [])
