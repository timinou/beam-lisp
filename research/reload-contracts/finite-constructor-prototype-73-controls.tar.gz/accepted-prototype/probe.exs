# HOME-only exploratory native ANF/shape evidence; candidate functions never called.
Application.load(:beam_lisp)
{:ok, dependencies} = :application.get_key(:beam_lisp, :applications)
Enum.each(dependencies, fn dep -> {:ok, _} = Application.ensure_all_started(dep) end)
IO.inspect(BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN")), label: "verified_floor")
BeamLisp.AOT.boot()
root = System.fetch_env!("BL_PROBE_ROOT")
:ok = BeamLisp.Env.push_load_path(root <> "/beam/priv/std")
expected = root <> "/beam/priv/std/reload/finite-constructor.bl"
actual = BeamLisp.Loader.source_path("reload.finite-constructor")
if actual != expected, do: raise("HOME finite constructor shadowed: #{inspect({expected, actual})}")
IO.inspect({actual, Base.encode16(:crypto.hash(:sha256, File.read!(actual)), case: :lower)}, label: "FINITE_PRIVATE_SOURCE")
BeamLisp.Loader.ensure_loaded("reload.finite-constructor")
file = root <> "/anf-shape-probe.bl"
BeamLisp.Compiler.eval_string(File.read!(file), BeamLisp.Compiler.new_env("reload.finite-constructor-probe"), file)
IO.puts("FINITE_PROBE_SCOPE=diagnostic_only_not_acceptance; candidate_functions_never_called")
