# Read-only native observer. Never asks Env's Agent to execute a callback and
# never samples process dictionaries, messages, arguments, locals or Source data.
context=Process.get(:diagnostic_sampler_context)
root_owner=context.owner
phase_token=make_ref()
settings=context.settings
path=context.home<>"/"<>context.mode<>"-samples.jsonl"
allowed=MapSet.new(for {role,fixture}<-:json.decode(File.read!(context.home<>"/component-inputs.json"))["fixtures"],name<-fixture["functions"]++["assert-genuine-staged-queue-runtime!"],do: {role,name})
count=fn mfa->
 case :erlang.trace_info(mfa,:call_count) do
  {:call_count,n} when is_integer(n)->%{status: "observed",calls: n}
  _->%{status: "notInstrumented"}
 end
end
stack=fn pid->
 if is_pid(pid) do
  case Process.info(pid,:current_stacktrace) do
   {:current_stacktrace,frames}->
    Enum.take(frames,settings["stackFramesPerProcess"])
    |>Enum.flat_map(fn
     {module,function,arity,_locations} when is_atom(module) and is_atom(function) and is_integer(arity)->
      [%{module: Atom.to_string(module),function: Atom.to_string(function),arity: arity}]
     _->[]
    end)
   _->[]
  end
 else [] end
end
sampler=spawn(fn ->
 owner_monitor=Process.monitor(root_owner)
 started=System.monotonic_time(:millisecond)
 emit=fn sequence,phase,bytes,final->
  row=%{sequence: sequence,elapsedMs: System.monotonic_time(:millisecond)-started,mode: context.mode,phase: phase,final: final,
        constructor: count.(context.compileMfa),restore: count.(context.restoreMfa),
        rootStack: stack.(root_owner),envAgentStack: stack.(Process.whereis(BeamLisp.Env)),loaderServerStack: stack.(Process.whereis(BeamLisp.Loader.Server))}
  line=IO.iodata_to_binary(:json.encode(row))<>"\n"
  if sequence<settings["maximumRecords"] and bytes+byte_size(line)<=settings["maximumBytes"] do
   File.write!(path,line,[:append]);bytes+byte_size(line)
  else bytes end
 end
 Process.send_after(self(),:sample,0)
 loop=fn loop,sequence,phase,bytes->
  receive do
   {:phase,^phase_token,role,name}->
    if MapSet.member?(allowed,{role,name}),do: loop.(loop,sequence,%{role: role,caseName: name},bytes),else: loop.(loop,sequence,phase,bytes)
   :sample->
    size=emit.(sequence,phase,bytes,false)
    if sequence+1<settings["maximumRecords"],do: Process.send_after(self(),:sample,settings["periodMs"])
    loop.(loop,sequence+1,phase,size)
   {:stop,^phase_token,^root_owner}->
    emit.(sequence,phase,bytes,true);send(root_owner,:diagnostic_sampler_stopped)
   {:DOWN,^owner_monitor,:process,^root_owner,_}->:ok
   _->loop.(loop,sequence,phase,bytes)
  end
 end
 loop.(loop,0,%{role: "native-bootstrap",caseName: "fixture-setup"},0)
end)
Process.put(:diagnostic_sampler,sampler)
Process.put(:diagnostic_sampler_phase_token,phase_token)
