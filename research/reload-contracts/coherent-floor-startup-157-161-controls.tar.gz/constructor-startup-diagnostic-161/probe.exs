root = System.fetch_env!("BL_PROBE_ROOT")
# Fresh process: actual launcher host installation runs before the sole overlay.
# No AOT.boot, provider preload, application stub or seed relabel in this VM.
nil = Process.whereis(BeamLisp.Env)
argv = ["run", "/home/user/tmp/product-online-20261014/round2/ordinary-native-159/receipt.bl"]
install = fn ebin ->
  result = BeamLisp.Bootstrap.install_hosts!(ebin)
  artifact = root <> "/host/Elixir.BeamLisp.AOT.beam"
  {:module, BeamLisp.AOT} = :code.load_binary(BeamLisp.AOT, String.to_charlist(artifact), File.read!(artifact))
  IO.inspect(Base.encode16(:crypto.hash(:sha256, File.read!(artifact)), case: :lower), label: "DIAGNOSTIC_AOT_OVERLAY_SHA256")
  nil = Process.whereis(BeamLisp.Env)
  result
end
try do
  BeamLisp.Launcher.boot(argv, %{install_hosts: install})
rescue error ->
  data = BeamLisp.ExInfo.ex_data(error)
  IO.inspect(data, label: "DIAGNOSTIC_STARTUP_EXACT_REFUSAL", limit: :infinity, printable_limit: :infinity)
  IO.inspect(__STACKTRACE__, label: "DIAGNOSTIC_STARTUP_NATIVE_STACK", limit: 100)
  System.halt(if is_map(data) and data[:kind] == :"constructor-machine-refused", do: 0, else: 1)
end
