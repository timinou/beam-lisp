root = System.fetch_env!("BL_PROBE_ROOT")
Application.load(:beam_lisp)
{:ok, deps} = :application.get_key(:beam_lisp, :applications)
Enum.each(deps, fn dep -> {:ok, _} = Application.ensure_all_started(dep) end)
:ok = BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
BeamLisp.AOT.boot()
source = root <> "/aot-macrotrace.bl"
expected = "acdaab36d7bb14e63188e3e97a62c2ee1ee0c17044cd6bdc9afcf773008ddfaf"
^expected = Base.encode16(:crypto.hash(:sha256, File.read!(source)), case: :lower)
result = BeamLisp.AOT.compile_host_file(source, module: BeamLisp.AOT, output_dir: root <> "/host", source_hash: expected, load?: false)
IO.inspect(result, label: "DIAGNOSTIC_AOT_COMPILED_NOT_LOADED")
artifact = root <> "/host/Elixir.BeamLisp.AOT.beam"
IO.inspect({artifact, Base.encode16(:crypto.hash(:sha256, File.read!(artifact)), case: :lower)}, label: "DIAGNOSTIC_ARTIFACT_SHA256")
System.halt(0)
