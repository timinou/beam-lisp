root = System.fetch_env!("BL_PROBE_ROOT")
failed = try do
 BeamLisp.Launcher.main(["run", "/home/user/tmp/product-online-20261014/round2/ordinary-native-159/receipt.bl"])
 false
rescue error ->
 IO.inspect({error, BeamLisp.ExInfo.ex_data(error), __STACKTRACE__}, label: "ACTUAL_ORDINARY_STARTUP_FAILURE", limit: 100)
 true
end
file = root <> "/launcher.direct.bl"
BeamLisp.Compiler.eval_string(File.read!(file), BeamLisp.Compiler.new_env("host.launcher.test"), file)
for name <- ["launcher-child-rechecks-after-install-before-building", "launcher-child-builds-genuine-source-changes", "launcher-child-requires-complete-positive-evidence", "launcher-child-never-accepts-corrupt-installation"] do
 try do
  BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!("host.launcher.test", name), [])
 rescue error -> IO.inspect({name, error, __STACKTRACE__}, label: "LAUNCHER_CASE_CRASH", limit: 20)
 end
end
report = BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!("host.launcher.test", "direct-report"), [])
IO.inspect(report, label: "LAUNCHER_NEW_NATIVE_ASSERTIONS", limit: :infinity)
System.halt(if failed and report[:pass] == 23 and report[:assertions] == 23, do: 0, else: 1)
