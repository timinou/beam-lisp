"""Data-only complete tracked inventory and exact Source-delta checks."""
from pathlib import Path
import hashlib,json,subprocess
MAIN=Path('/home/user/code/undefine/beam-lisp')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def tracked():
 return sorted(p for p in subprocess.check_output(['git','ls-files','-z'],cwd=MAIN).decode().split('\0') if p)
def source_path(p):
 return (p.endswith(('.bl','.rs')) or Path(p).name in ('Cargo.toml','Cargo.lock','build.rs')) and not p.startswith('priv/bootstrap/seed/')
def inventory(paths):
 rows=[]
 for relative in sorted(paths):
  p=MAIN/relative
  if p.is_symlink():rows.append({'path':relative,'kind':'symlink','sha256':hashlib.sha256(p.readlink().as_posix().encode()).hexdigest()})
  else:
   assert p.is_file(),f'Tracked file absent/nonregular: {relative}'
   rows.append({'path':relative,'kind':'file','sha256':sha(p)})
 return rows
def observe_sources():
 paths={p for p in tracked() if source_path(p)}
 # No silently omitted newly created Source. Only the exact reviewed additions
 # can be admitted, whether root has committed them yet or not.
 extra=subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=MAIN).decode().split('\0')
 paths.update(p for p in extra if p and source_path(p))
 paths.update(['scripts/regenerate-seed.bl','scripts/install-seed.bl','env.bl'])
 return {p:sha(MAIN/p) for p in sorted(paths)}
def approved_observation(floor,reviewed):
 base={r['path']:r['sha256'] for r in floor['sources']}
 actual=observe_sources();allowed={}
 for row in reviewed['deltas']:
  p=row['path'];assert p not in allowed,f'Duplicate reviewed path: {p}'
  assert (p.startswith(('priv/std/proc/','test/bl/')) or p in {'priv/std/reload/declaration.bl','priv/lib/datom/conn.bl','priv/std/reload.bl','priv/std/reload/generation.bl','priv/std/reload/runtime.bl'}) and '..' not in Path(p).parts,f'Not permitted SDK/test-only delta: {p}'
  assert row['floorSha256']==base.get(p),f'Review baseline not actual198 source: {p}'
  assert len(row['reviewedSha256'])==64 and row['reviewedSha256']!=row['floorSha256']
  allowed[p]=row
 changes=[]
 for p in sorted(set(base)|set(actual)):
  before=base.get(p);after=actual.get(p)
  if before==after:continue
  assert p in allowed,f'Unreviewed Source addition/change/deletion: {p}'
  assert after==allowed[p]['reviewedSha256'],f'Actual Source differs from exact reviewed SHA: {p}'
  changes.append({'path':p,'floorSha256':before,'observedSha256':after,'reviewedSha256':allowed[p]['reviewedSha256']})
 assert {r['path'] for r in changes}==set(allowed),'Not all reviewed deltas are landed exactly'
 return actual,changes
