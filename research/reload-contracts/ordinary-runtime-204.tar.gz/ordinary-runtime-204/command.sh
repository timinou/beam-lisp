#!/usr/bin/env bash
set -euo pipefail
root=/home/user/tmp/product-online-20261014/round2/ordinary-current-204-ready
python3 "$root/verify.py" before
source "$root/expected.env"
export TMPDIR="$root/tmp" BEAM_LISP_AOT_CACHE_DIR="$root/aot-cache" BL_ORDINARY_RECEIPT="$root/receipt.term" BL_DAEMON=off BL_AUTOBUILD=off
export BL_COLLECTION_STAGE_FILE="$root/collection-stage-five.bl" BL_COLLECTION_STAGE_RECEIPT="$root/collection-stage-five.receipt"
export BL_COLLECTION_STAGE_FOLLOWUP=${BL_COLLECTION_STAGE_FOLLOWUP:-1}
unset BEAM_LISP_EBIN BEAM_LISP_PATH BL_ROOT BL_EBIN BL_BIN BL_BUILD_ID BL_BOOT_REEXECED BL_BOOTSTRAP_OUTPUT BL_BOOTSTRAP_INSTALL BL_DIAGNOSTIC KNOWLEDGER_PACKAGE KNOWLEDGER_ENV BEAM_LISP_DEV BL_CONSTRUCTOR_METADATA_ROOT BL_KERNEL_SOURCE_UNDER_TEST BL_REGENERATE_SCRIPT_UNDER_TEST
mkdir -p "$root/tmp"
cd /home/user/code/undefine/beam-lisp
./bin/bl run "$root/ordinary-receipt.bl"
python3 "$root/verify.py" after "$BL_COLLECTION_STAGE_FOLLOWUP"
