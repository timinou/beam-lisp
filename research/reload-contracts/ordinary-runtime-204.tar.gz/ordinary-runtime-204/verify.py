from pathlib import Path
import json,sys
from inventory import MAIN,sha,tracked,inventory,observe_sources
r=Path(__file__).resolve().parent;x=json.loads((r/'inputs.json').read_text())
for p,h in x['commandFiles'].items():assert sha(r/p)==h,p
assert inventory(tracked())==json.loads((r/'observed-tracked-inventory.json').read_text())['files'],'Complete observed tracked inventory changed'
assert observe_sources()=={v['path']:v['sha256'] for v in x['sources']},'Source set/bytes changed'
for row in x['native_assets']+x['installedSeedFiles']:assert sha(MAIN/row['path'])==row['sha256'],row['path']
assert sha(MAIN/'priv/bootstrap/seed/manifest.term')==x['manifestSha256']
p=MAIN/'priv/native/lazy_memo.so';s=p.stat();actual={'sha256':sha(p),'device':s.st_dev,'inode':s.st_ino,'bytes':s.st_size,'mtimeNs':s.st_mtime_ns};assert actual==x['nativeIdentity'],'Native identity changed across fresh VM boundary'
if len(sys.argv)>1 and sys.argv[1]=='after':
 assert (r/'receipt.term').is_file(),'Ordinary native receipt missing'
 if len(sys.argv)>2 and sys.argv[2]=='1':assert (r/'collection-stage-five.receipt').read_text()=='ACTUAL_PHYSICAL_COLLECTION_STAGE_5_PASS\n'
 (r/'verified-after.json').write_text(json.dumps({'scope':'External immutable inventory checks only; actual native/module/SDK-lease/CLI assertions in receipt.term','receiptSha256':sha(r/'receipt.term'),'sourceDeltaReceiptSha256':sha(r/'source-delta-receipt.json'),'manifestSha256':x['manifestSha256'],'nativeIdentityBeforeAndAfter':actual},indent=2)+'\n')
print('POST_198_ORDINARY_204_COMPLETE_OBSERVED_SOURCE_MANIFEST_NATIVE_CHECK_PASS')
