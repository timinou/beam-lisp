root = System.fetch_env!("BL_PROBE_ROOT")
manifest = BeamLisp.Bootstrap.manifest()
for module <- [BeamLisp.AOT, BeamLisp.ExInfo] do
 true = Code.ensure_loaded?(module)
 {^module, object, path} = :code.get_object_code(module)
 expected = manifest["modules"][Atom.to_string(module) <> ".beam"]
 ^expected = Base.encode16(:crypto.hash(:sha256, object), case: :lower)
 IO.inspect(%{module: module, path: path, sha256: expected}, label: "UNCHANGED_MANIFEST_REFUSAL_TRACE_TARGET")
end
nil = Process.whereis(BeamLisp.Env)
kind = fn value ->
 cond do
  is_nil(value) -> :nil
  is_map(value) -> :map
  is_list(value) -> :list
  is_tuple(value) -> :tuple
  is_binary(value) -> :binary
  is_atom(value) -> :atom
  is_integer(value) -> :integer
  is_float(value) -> :float
  is_function(value) -> :function
  is_reference(value) -> :reference
  is_pid(value) -> :pid
  true -> :other
 end
end
# Closed raw projection: never Rt/Enumerable/Inspect on payloads or private values.
small_parts = fn value ->
 cond do
  is_tuple(value) and tuple_size(value) <= 4 -> Tuple.to_list(value)
  is_list(value) ->
   Enum.take(value, 5)
  is_map(value) and Map.get(value, :__struct__) == BeamLisp.Vector and is_tuple(Map.get(value, :items)) and tuple_size(Map.get(value, :items)) <= 4 ->
   Tuple.to_list(Map.get(value, :items))
  true -> nil
 end
end
leaf = fn value ->
 cond do
  is_nil(value) -> nil
  is_atom(value) -> value
  is_integer(value) and value >= 0 and value <= 65536 -> value
  is_binary(value) and byte_size(value) <= 256 -> value
  true -> %{kind: kind.(value)}
 end
end
summary = fn payload ->
 data = if is_map(payload), do: Map.get(payload, :data, payload), else: nil
 data = if is_map(data), do: data, else: %{}
 detail = Map.get(data, :detail)
 selected_detail = if is_map(detail) do
  Map.new(Enum.flat_map([:primitive, :remote, :global, :operation, :unsupported_primitive_arity, :"unsupported-primitive-arity"], fn key ->
   if Map.has_key?(detail, key) do
    value = Map.get(detail, key)
    parts = small_parts.(value)
    [{key, if(is_list(parts), do: Enum.map(parts, leaf), else: leaf.(value))}]
   else [] end
  end))
 else leaf.(detail) end
 operation = Map.get(data, :operation)
 parts = small_parts.(operation)
 %{kind: leaf.(Map.get(data, :kind)), detail_shape: kind.(detail), detail: selected_detail,
   operation: if(is_list(parts), do: Enum.map(parts, leaf), else: leaf.(operation)),
   namespace: leaf.(Map.get(data, :namespace)), data_keys: Enum.filter([:kind, :detail, :operation, :namespace, :"constructor-call-stack"], &Map.has_key?(data, &1))}
end
tracer = spawn(fn ->
 loop = fn loop, recent, refusals, events ->
  receive do
   {:trace, _pid, :call, {BeamLisp.ExInfo, :raise_payload, 1}, payload} ->
    row = %{refusal: summary.(payload), recent_source_names: recent}
    next = Enum.take([row | refusals], 8)
    if length(refusals) < 8 do
     IO.inspect(row, label: "ACTUAL_EARLY_CONSTRUCTOR_REFUSAL", limit: :infinity)
     File.write!(root <> "/bounded-refusals.term", :erlang.term_to_binary(Enum.reverse(next)))
    end
    loop.(loop, recent, next, events + 1)
   {:trace, _pid, :call, {BeamLisp.AOT, _, _}, names} ->
    loop.(loop, Enum.take([names | recent], 16), refusals, events + 1)
   {:snapshot, from, ref} ->
    send(from, {ref, %{recent_source_names: recent, refusals: Enum.reverse(refusals), events: events}})
    loop.(loop, recent, refusals, events)
   {:reset, from, ref} ->
    send(from, {ref, :reset})
    loop.(loop, [], [], 0)
   :stop -> :ok
   unknown ->
    if is_tuple(unknown) and tuple_size(unknown) > 0 and elem(unknown, 0) in [:trace, :trace_ts] do
     if events < 4, do: IO.inspect(%{tuple_arity: tuple_size(unknown), event: if(tuple_size(unknown) > 2 and is_atom(elem(unknown, 2)), do: elem(unknown, 2), else: :unknown)}, label: "UNRECOGNIZED_TRACE_SHAPE")
     loop.(loop, recent, refusals, events + 1)
    else loop.(loop, recent, refusals, events) end
  end
 end
 loop.(loop, [], [], 0)
end)
refusal_pattern = [
 {[:"$1"], [{:is_map, :"$1"}, {:is_map_key, :message, :"$1"}, {:"==", {:map_get, :message, :"$1"}, "Bounded constructor interpretation refused"}], [{:message, :"$1"}]},
 {[:"$1"], [{:is_map, :"$1"}, {:is_map_key, :data, :"$1"}, {:is_map, {:map_get, :data, :"$1"}}, {:is_map_key, :kind, {:map_get, :data, :"$1"}}, {:"==", {:map_get, :kind, {:map_get, :data, :"$1"}}, :"constructor-machine-refused"}], [{:message, :"$1"}]},
 {[:"$1"], [{:is_map, :"$1"}, {:is_map_key, :kind, :"$1"}, {:"==", {:map_get, :kind, :"$1"}, :"constructor-machine-refused"}], [{:message, :"$1"}]}
]
1 = :erlang.trace_pattern({BeamLisp.ExInfo, :raise_payload, 1}, refusal_pattern, [:local])
for {fun, arity, tag} <- [{:constructor_compile_binding!, 2, :physical_binding}, {:staged_macro_lookup, 2, :macro_lookup}, {:constructor_unit!, 1, :source_unit}] do
 head = if arity == 1, do: [:"$1"], else: [:"$1", :"$2"]
 guards = if arity == 1, do: [{:is_binary, :"$1"}, {:"=<", {:byte_size, :"$1"}, 256}], else: [{:is_binary, :"$1"}, {:"=<", {:byte_size, :"$1"}, 256}, {:is_binary, :"$2"}, {:"=<", {:byte_size, :"$2"}, 256}]
 message = if arity == 1, do: {{tag, :"$1"}}, else: {{tag, :"$1", :"$2"}}
 1 = :erlang.trace_pattern({BeamLisp.AOT, fun, arity}, [{head, guards, [{:message, message}]}], [:local])
end
pids = Process.list()
true = length(pids) <= 4096
for pid <- pids, pid != tracer do
 try do :erlang.trace(pid, true, [:call, :arity, :set_on_spawn, {:tracer, tracer}]) rescue ArgumentError -> :ok end
end
IO.inspect(length(pids), label: "BOUNDED_EXISTING_TRACE_PID_COUNT")
snapshot = fn ->
 delivery = :erlang.trace_delivered(:all)
 receive do {:trace_delivered, :all, ^delivery} -> :ok after 5000 -> raise "trace delivery timeout" end
 ref = make_ref(); send(tracer, {:snapshot, self(), ref})
 receive do {^ref, report} -> report after 5000 -> raise "trace snapshot timeout" end
end
control = BeamLisp.ExInfo.ex_info("Bounded constructor interpretation refused", %{kind: :"constructor-machine-refused", detail: %{remote: {:erlang, :is_atom, 1}}})
try do BeamLisp.ExInfo.raise_payload(control) rescue _ -> :ok end
report = snapshot.()
true = report.events > 0 and length(report.refusals) == 1
IO.inspect(report, label: "EARLY_REFUSAL_TRACE_CONTROL_PASS")
nil = Process.whereis(BeamLisp.Env)
File.rm(root <> "/bounded-refusals.term")
ref = make_ref(); send(tracer, {:reset, self(), ref})
receive do {^ref, :reset} -> :ok after 5000 -> raise "trace reset timeout" end
try do
 BeamLisp.Launcher.main()
rescue error ->
 IO.inspect(%{exception: error.__struct__, refusal: summary.(error)}, label: "UNCHANGED_ACTUAL_STARTUP_REFUSAL", limit: :infinity)
 IO.inspect(snapshot.(), label: "BOUNDED_EARLY_REFUSAL_TRACE", limit: :infinity)
 for mfa <- [{BeamLisp.ExInfo, :raise_payload, 1}, {BeamLisp.AOT, :constructor_compile_binding!, 2}, {BeamLisp.AOT, :staged_macro_lookup, 2}, {BeamLisp.AOT, :constructor_unit!, 1}], do: IO.inspect({mfa, :erlang.trace_info(mfa, :traced)}, label: "POST_STARTUP_TRACE_PATTERN_STATUS")
 System.halt(70)
end
