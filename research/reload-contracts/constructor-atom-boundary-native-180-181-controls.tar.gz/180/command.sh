#!/usr/bin/env bash
set -euo pipefail
root=/home/user/tmp/product-online-20261014/round2/constructor-refusal-trace-180
export BL_PROBE_ROOT="$root" TMPDIR="$root/tmp" BEAM_LISP_AOT_CACHE_DIR="$root/aot-cache" BL_DIAGNOSTIC="$root/probe.exs" BL_DAEMON=off BL_AUTOBUILD=off BL_ORDINARY_RECEIPT="$root/receipt.term"
unset BEAM_LISP_EBIN BEAM_LISP_PATH BL_ROOT BL_EBIN BL_BIN BL_BUILD_ID BL_BOOT_REEXECED BL_BOOTSTRAP_OUTPUT BL_BOOTSTRAP_INSTALL KNOWLEDGER_PACKAGE KNOWLEDGER_ENV BEAM_LISP_DEV
exec "$root/source-wrapper" run /home/user/tmp/product-online-20261014/round2/acceptance-sequence/ordinary-receipt.bl
