root = System.fetch_env!("BL_PROBE_ROOT")
sha = fn p -> Base.encode16(:crypto.hash(:sha256,File.read!(p)),case: :lower) end
inputs = :json.decode(File.read!(root <> "/inputs.json"))
for {path,digest} <- inputs["files"], do: true = sha.(root <> "/" <> path) == digest
for row <- inputs["substrateSources"], do: true = sha.(root <> "/substrate/" <> row["path"]) == row["sha256"]
Application.load(:beam_lisp)
{:ok,deps} = :application.get_key(:beam_lisp,:applications)
Enum.each(deps, fn d -> {:ok,_} = Application.ensure_all_started(d) end)
:ok = BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
BeamLisp.AOT.boot()
false = :ets.member(:beam_lisp_vars,:bl_sdk_runtime_lease)
# Explicit accepted recovery kernel. Current Main hashes are verified; the
# coherent177 physical SDK remains the real source/manifest attestation root.
Code.eval_file(root <> "/kernel-prelude.exs")
IO.inspect(%{physical_root: System.fetch_env!("BL_ROOT"), priv_root: BeamLisp.Tiers.priv_root(), compiler_key: BeamLisp.AOTCache.compiler_key()},label: "HONEST_181_COMPONENT_SUBSTRATE")
saved = BeamLisp.Env.capture()
try do
 {BeamLisp.AOT,path} = BeamLisp.AOT.compile_host_file(root <> "/aot.candidate.bl",module: BeamLisp.AOT,output_dir: root <> "/host",load?: false)
 bytes = File.read!(path)
 {:module,BeamLisp.AOT} = :code.load_binary(BeamLisp.AOT,String.to_charlist(path),bytes)
 {:ok,{BeamLisp.AOT,md5}} = :beam_lib.md5(bytes)
 ^md5 = apply(BeamLisp.AOT,:module_info,[:md5])
 IO.inspect(%{source: inputs["candidateSha256"], artifact: sha.(path), md5: Base.encode16(md5,case: :lower)},label: "ACTUAL_ATOM_CANDIDATE_NATIVE_ARTIFACT")
after BeamLisp.Env.bind(saved) end
file = root <> "/atom.direct.bl"
ns = "aot-constructor-atom-test"
BeamLisp.Compiler.eval_string(File.read!(file),BeamLisp.Compiler.new_env(ns),file)
crashes = Enum.flat_map(inputs["functions"], fn name ->
 before = System.monotonic_time(:microsecond)
 try do
  BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(ns,name),[])
  IO.inspect(%{name: name,microseconds: System.monotonic_time(:microsecond)-before},label: "ATOM_COMPONENT_CASE_COMPLETED"); []
 rescue e -> IO.inspect({name,e,BeamLisp.ExInfo.ex_data(e),__STACKTRACE__},label: "ATOM_COMPONENT_CASE_CRASH",limit: 35); [name]
 end
end)
report = BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(ns,"direct-report"),[])
IO.inspect(report,label: "ATOM_COMPONENT_84_ASSERTIONS",limit: :infinity)
false = :ets.member(:beam_lisp_vars,:bl_sdk_runtime_lease)
System.halt(if crashes==[] and report[:pass]==84 and report[:assertions]==84,do: 0,else: 1)
