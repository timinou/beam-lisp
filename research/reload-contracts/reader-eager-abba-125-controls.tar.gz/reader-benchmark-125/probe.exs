Application.load(:beam_lisp)
{:ok, dependencies} = :application.get_key(:beam_lisp, :applications)
Enum.each(dependencies, fn dep -> {:ok, _} = Application.ensure_all_started(dep) end)
:ok = BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
BeamLisp.AOT.boot()
root = System.fetch_env!("BL_PROBE_ROOT")
base = Path.dirname(root)
for module <- [BeamLisp.Ns.Compiler, BeamLisp.Ns.Body.Compiler, BeamLisp.Ns.Init.Compiler] do
 path = base <> "/constructor-context-106/compiler-beams/" <> Atom.to_string(module) <> ".beam"
 {:module, ^module} = :code.load_binary(module, String.to_charlist(path), File.read!(path))
end
for {module, directory} <- [{BeamLisp.SourceGraph, "constructor-context-117/host"}, {BeamLisp.NamespaceInterface, "constructor-context-117/host"}, {BeamLisp.BuildPlan, "constructor-context-119/host"}, {BeamLisp.AOT, "constructor-reader-native-123/host"}] do
 path = base <> "/" <> directory <> "/" <> Atom.to_string(module) <> ".beam"
 {:module, ^module} = :code.load_binary(module, String.to_charlist(path), File.read!(path))
end
modules = [BeamLisp.Ns.Reader, BeamLisp.Ns.Body.Reader, BeamLisp.Ns.Init.Reader, :"Elixir.BeamLisp.Ns.Reader-node", :"Elixir.BeamLisp.Ns.Body.Reader-node"]
corpus = root <> "/corpus/*" |> Path.wildcard() |> Enum.sort() |> Enum.map(fn path -> {Path.basename(path), File.read!(path)} end)
reference = Enum.reduce(Enum.with_index([:old, :new, :new, :old]), nil, fn {variant, round}, reference ->
 directory = if variant == :old, do: base <> "/ordinary-source-95/build", else: base <> "/constructor-reader-native-123/reader-beams"
 identities = Enum.map(modules, fn module ->
  # No managed application is running. Each previous call completed before this
  # benchmark-only module replacement; remove the now-unreferenced old version.
  :code.soft_purge(module)
  path = directory <> "/" <> Atom.to_string(module) <> ".beam"
  bytes = File.read!(path)
  {:module, ^module} = :code.load_binary(module, String.to_charlist(path), bytes)
  {module, Base.encode16(:crypto.hash(:sha256, bytes), case: :lower)}
 end)
 IO.inspect({variant, round, identities}, label: "EXACT_READER_ARTIFACTS", limit: :infinity)
 results = Enum.map(corpus, fn {name, source} ->
  :erlang.garbage_collect(self())
  {:reductions, before_r} = Process.info(self(), :reductions)
  {:garbage_collection, before_gc} = Process.info(self(), :garbage_collection)
  start = System.monotonic_time(:microsecond)
  output = BeamLisp.Ns.Reader.read_all(source)
  elapsed = System.monotonic_time(:microsecond) - start
  {:reductions, after_r} = Process.info(self(), :reductions)
  {:garbage_collection, after_gc} = Process.info(self(), :garbage_collection)
  digest = Base.encode16(:crypto.hash(:sha256, :erlang.term_to_binary(output)), case: :lower)
  row = %{variant: variant, round: round, file: name, bytes: byte_size(source), forms: length(output), microseconds: elapsed, reductions: after_r-before_r, minor_gcs: after_gc[:minor_gcs]-before_gc[:minor_gcs], output_sha256: digest}
  IO.puts("READER_MEASUREMENT " <> Jason.encode!(row))
  {name, digest}
 end)
 if reference != nil, do: true = reference == results
 namespace = "reader-meta-isolation-" <> Integer.to_string(round)
 source = File.read!(root <> "/reader-meta.direct.bl") |> String.replace("reader-meta.test", namespace)
 BeamLisp.Compiler.eval_string(source, BeamLisp.Compiler.new_env(namespace), root <> "/reader-meta.direct.bl")
 for name <- ["literal-key-survives", "expression-key-evaluates", "for-rows-are-keyed", "map-preserves-key", "meta-invisible-to-equality", "no-meta-is-nil", "only-vectors-carry-runtime-meta", "threading-still-works", "reader-offsets-are-not-author-metadata"] do
  BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(namespace, name), [])
 end
 report = BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(namespace, "direct-report"), [])
 IO.inspect({variant, round, report}, label: "METADATA_ISOLATION", limit: :infinity)
 reference || results
end)
IO.inspect(reference, label: "MATCHED_ALL_ABBA_OUTPUTS", limit: :infinity)
