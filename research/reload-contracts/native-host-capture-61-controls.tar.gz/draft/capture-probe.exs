# Parent-only minimal native diagnostic. No CLI, listener, business store or SDK
# lease admission. Capture the actual producer bytes before first NIF host load.
Application.load(:beam_lisp)
{:ok,dependencies}=:application.get_key(:beam_lisp,:applications)
Enum.each(dependencies,fn dependency -> {:ok,_}=Application.ensure_all_started(dependency) end)
IO.inspect(BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN")),label: "verified_floor")
target=BeamLisp.Native.Bl.JsonNative
IO.inspect(:code.is_loaded(target),label: "NATIVE_HOST_BEFORE_TRACE")
tracer=spawn(fn ->
 loop=fn loop,captured ->
  receive do
   {:trace,_,:call,{BeamLisp.Env,:publish_binaries!,args}} ->
    prepared=case args do [beams,_file] -> beams; [beams] -> Enum.map(beams,&elem(&1,0)); _ -> [] end
    matching=Enum.find(prepared,fn value -> is_tuple(value) and tuple_size(value)==2 and elem(value,0)==target and is_binary(elem(value,1)) end)
    next=if matching,do: elem(matching,1),else: captured
    loop.(loop,next)
   {:get,pid,ref} -> send(pid,{ref,captured}); loop.(loop,captured)
   :stop -> :ok
  after 60000 -> loop.(loop,captured)
  end
 end
 loop.(loop,nil)
end)
:erlang.trace_pattern({BeamLisp.Env,:publish_binaries!,2},true,[:local])
:erlang.trace_pattern({BeamLisp.Env,:publish_binaries!,1},true,[:local])
:erlang.trace(:all,true,[:call,{:tracer,tracer}])
try do
 BeamLisp.AOT.boot()
 BeamLisp.Loader.ensure_loaded("vm.native")
 BeamLisp.Loader.ensure_loaded("bl.json-native")
 delivery=:erlang.trace_delivered(:all)
 receive do {:trace_delivered,:all,^delivery} -> :ok after 5000 -> raise("trace delivery barrier timed out") end
 ticket=make_ref();send(tracer,{:get,self(),ticket})
 captured=receive do {^ticket,binary} when is_binary(binary) -> binary; {^ticket,nil} -> raise("actual native producer bytes not captured") after 5000 -> raise("native capture timed out") end
 output=System.fetch_env!("BL_PROBE_ROOT")
 File.mkdir_p!(output)
 File.write!(Path.join(output,"actual-json-native.beam"),captured)
 actual_md5=apply(target,:module_info,[:md5])
 {:ok,{^target,captured_md5}}=:beam_lib.md5(captured)
 unless actual_md5==captured_md5,do: raise("captured publication is not actual loaded native host")
 {:beam_file,^target,_exports,_attrs,_compile,functions}=:beam_disasm.file(captured)
 instructions=functions |> Enum.find(fn function -> elem(function,1)==:__load_nif__ and elem(function,2)==0 end) |> elem(4)
 File.write!(Path.join(output,"actual-native-load-instructions.term.txt"),inspect(instructions,limit: :infinity,printable_limit: :infinity))
 # Only the canonical load hook's literal path is inspected, and the WHOLE
 # descriptor/actual executable digest is checked below, not only this literal.
 paths=Enum.flat_map(instructions,fn instruction ->
  case instruction do
   {:move,{:literal,characters},_} when is_list(characters) ->
    if List.ascii_printable?(characters) and length(characters)>0 and hd(characters)==?/,do: [List.to_string(characters)],else: []
   _ -> []
  end
 end) |> Enum.uniq()
 IO.inspect(paths,label: "ACTUAL_NATIVE_LOAD_PATH_LITERALS")
 unless length(paths)==1,do: raise("native hook does not have exactly one canonical path literal")
 selected=hd(paths)
 native=fn name,args -> BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!("vm.native",name),args) end
 declaration=native.("declaration",["bl.json-native"])
 crate=Map.fetch!(declaration,:crate)
 sdk_lib=Path.join([BeamLisp.Tiers.priv_root(),"native",crate])
 physical=fn path -> apply(BeamLisp.AOT,:physical_sdk_path,[path<>".so"]) end
 IO.inspect({selected,sdk_lib,native.("lib-path",[crate]),physical.(selected),physical.(sdk_lib)},label: "EXACT_SELECTED_SDK_ARTIFACT")
 unless physical.(selected) != nil and physical.(selected)==physical.(sdk_lib),do: raise("selected native library is not exact physical SDK artifact")
 source=File.read!(Path.join(System.fetch_env!("BL_NATIVE_DRAFT"),"native.bl"))
 source=String.replace(source,"(ns vm.native","(ns research.native-producer",global: false)
 BeamLisp.Compiler.eval_string(source,BeamLisp.Compiler.new_env("research.native-producer"),"native-producer-probe.bl")
 descriptor=BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!("research.native-producer","host-descriptor"),["bl.json-native",crate,Map.fetch!(declaration,:sigs),selected])
 {^target,canonical}=BeamLisp.Emit.compile_descriptor(descriptor)
 {:ok,{^target,canonical_md5}}=:beam_lib.md5(canonical)
 IO.inspect({captured_md5,canonical_md5,captured_md5==canonical_md5},label: "CANONICAL_ACTUAL_SELECTED_PATH_IDENTITY")
 unless captured_md5==canonical_md5,do: raise("canonical producer differs beyond selected library path")
 # Separate wrong-path descriptor must differ even if the artifact name matches.
 bad=BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!("research.native-producer","host-descriptor"),["bl.json-native",crate,Map.fetch!(declaration,:sigs),Path.join(output,crate)])
 {^target,bad_binary}=BeamLisp.Emit.compile_descriptor(bad)
 {:ok,{^target,bad_md5}}=:beam_lib.md5(bad_binary)
 unless bad_md5 != captured_md5,do: raise("wrong project library path passed executable identity check")
 IO.puts("NATIVE_CAPTURE_CANONICAL_IDENTITY_PASS")
after
 :erlang.trace(:all,false,[:call])
 :erlang.trace_pattern({BeamLisp.Env,:publish_binaries!,2},false,[:local])
 :erlang.trace_pattern({BeamLisp.Env,:publish_binaries!,1},false,[:local])
 send(tracer,:stop)
end
