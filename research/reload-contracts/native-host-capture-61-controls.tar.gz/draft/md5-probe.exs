# Parent-only serial native slot, after Bootstrap.install! + AOT.boot. This proves
# descriptor equality only; it neither installs SDK authority nor admits a lease.
root=System.fetch_env!("BL_ROOT")
draft=System.fetch_env!("BL_NATIVE_DRAFT")
BeamLisp.Loader.ensure_loaded("vm.native")
BeamLisp.Loader.ensure_loaded("bl.json-native")
source=File.read!(Path.join(draft,"native.bl"))
source=String.replace(source,"(ns vm.native","(ns research.native-producer",global: false)
BeamLisp.Compiler.eval_string(source,BeamLisp.Compiler.new_env("research.native-producer"),Path.join(draft,"native.bl"))
call=fn name,args-> BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!("research.native-producer",name),args) end
ns="bl.json-native"
actual=call.("host-module",[ns])
declaration=BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!("vm.native","declaration"),[ns])
crate=Map.fetch!(declaration,:crate)
signatures=Map.fetch!(declaration,:sigs)
lib=Path.join([BeamLisp.Tiers.priv_root(),"native",crate])
descriptor=call.("host-descriptor",[ns,crate,signatures,lib])
{^actual,binary}=BeamLisp.Emit.compile_descriptor(descriptor)
{:ok,{^actual,expected}}=:beam_lib.md5(binary)
observed=apply(actual,:module_info,[:md5])
IO.inspect({actual,expected,observed,expected == observed},label: "CANONICAL_EXISTING_SDK_NATIVE_HOST")
unless expected == observed,do: raise("legacy host descriptor differs or consumer override selected")
# A consumer-selected different path cannot authenticate the current SDK host.
wrong=call.("host-descriptor",[ns,crate,signatures,Path.join(draft,crate)])
{^actual,wrong_binary}=BeamLisp.Emit.compile_descriptor(wrong)
{:ok,{^actual,wrong_md5}}=:beam_lib.md5(wrong_binary)
unless wrong_md5 != observed,do: raise("library path was not included in executable identity")
IO.puts("NATIVE_DESCRIPTOR_MD5_PROBE_PASS")
