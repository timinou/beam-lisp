#!/bin/bash
set -euo pipefail
unset BEAM_LISP_EBIN BEAM_LISP_PATH BL_ROOT BL_EBIN BL_BIN BL_BUILD_ID BL_BOOT_REEXECED BL_CONSTRUCTOR_METADATA_ROOT BL_KERNEL_SOURCE_UNDER_TEST BL_REGENERATE_SCRIPT_UNDER_TEST
export BL_CACHE_COMPONENT_ROOT=/home/user/tmp/product-online-20261014/round2/automatic-sdk-native-207-v2 BL_DIAGNOSTIC=/home/user/tmp/product-online-20261014/round2/automatic-sdk-native-207-v2/component.exs TMPDIR=/home/user/tmp/product-online-20261014/round2/automatic-sdk-native-207-v2/tmp BEAM_LISP_AOT_CACHE_DIR=/home/user/tmp/product-online-20261014/round2/automatic-sdk-native-207-v2/aot-cache BL_DAEMON=off BL_AUTOBUILD=off
export BL_CACHE_COMPONENT_MODE=fault
cd /home/user/code/undefine/beam-lisp
exec /home/user/tmp/product-online-20261014/round2/automatic-sdk-native-207-v2/source-wrapper
