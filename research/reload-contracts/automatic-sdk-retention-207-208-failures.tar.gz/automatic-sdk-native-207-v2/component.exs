# Root-only genuinely cold SDK preparation or separate destructive fault control.
# Assertion seam is mechanical; original fixture bytes/hash remain recorded.
home=System.fetch_env!("BL_CACHE_COMPONENT_ROOT");main=System.fetch_env!("BL_ROOT")
mode=System.fetch_env!("BL_CACHE_COMPONENT_MODE");inputs=:json.decode(File.read!(home<>"/component-inputs.json"))
sha=fn p->Base.encode16(:crypto.hash(:sha256,File.read!(p)),case: :lower) end
verify=fn ->
 true=Enum.all?(inputs["sources"],fn r->sha.(main<>"/"<>r["path"])==r["sha256"] end)
 true=Enum.all?(inputs["files"],fn {p,d}->sha.(home<>"/"<>p)==d end)
 true=Enum.all?(inputs["nativeAssets"],fn row->sha.(main<>"/"<>row["path"])==row["sha256"] end)
 true=sha.(main<>"/priv/bootstrap/seed/manifest.term")==inputs["manifestSha256"]
end
verify.()
Application.load(:beam_lisp)
{:ok,deps}=:application.get_key(:beam_lisp,:applications)
Enum.each(deps,fn dep->{:ok,_}=Application.ensure_all_started(dep) end)
:ok=BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
BeamLisp.AOT.boot()
true=BeamLisp.AOTCache.current_compiler_key()==inputs["compilerKey"]
{:ok,[seed]}=:file.consult(String.to_charlist(main<>"/priv/bootstrap/seed/manifest.term"))
seed_modules=Map.new(seed["modules"])
native=fn ->
 for module<-[BeamLisp.AOT,BeamLisp.AOTCache,BeamLisp.Env,BeamLisp.Emit,BeamLisp.CompilerData,BeamLisp.Ns.Compiler] do
  {:module,^module}=Code.ensure_loaded(module)
  {^module,bytes,_}=:code.get_object_code(module)
  true=Base.encode16(:crypto.hash(:sha256,bytes),case: :lower)==Map.fetch!(seed_modules,Atom.to_string(module)<>".beam")
  {:ok,{^module,md5}}=:beam_lib.md5(bytes)
  true=md5==apply(module,:module_info,[:md5])
 end
end
native.()
# Never delete or fabricate a lease to manufacture a cold start.
false=:ets.member(:beam_lisp_vars,:bl_sdk_runtime_lease)
fixture=Map.fetch!(inputs["fixtures"],mode)
original=File.read!(home<>"/"<>fixture["original"])
true=Base.encode16(:crypto.hash(:sha256,original),case: :lower)==fixture["sha256"]
# Direct source was generated mechanically from exactly the permanent fixture:
# deftest -> ordinary zero-argument defn; is -> counted single-evaluation check.
file=home<>"/"<>fixture["direct"]
started=System.monotonic_time(:microsecond)
BeamLisp.Compiler.eval_string(File.read!(file),BeamLisp.Compiler.new_env(fixture["namespace"]),file)
compile_elapsed=System.monotonic_time(:microsecond)-started
if mode=="cold",do: false=:ets.member(:beam_lisp_vars,:bl_sdk_runtime_lease)
crashes=Enum.flat_map(fixture["functions"],fn function->
 start=System.monotonic_time(:microsecond)
 try do
  BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(fixture["namespace"],function),[])
  IO.inspect(%{function: function,elapsedUs: System.monotonic_time(:microsecond)-start},label: "ACTUAL_AUTOMATIC_SDK_CASE")
  []
 rescue error->
  # No raw args, graphs, lease receipts, Env captures or private callbacks.
  code=case error do %ErlangError{original: value} when is_atom(value)->value;_->nil end
  stack=Enum.take(__STACKTRACE__,8)|>Enum.map(fn {m,f,a,_}->%{module: m,function: f,arity: if(is_integer(a),do: a,else: length(a))} end)
  IO.inspect(%{function: function,errorClass: error.__struct__,code: code,stack: stack},label: "ACTUAL_AUTOMATIC_SDK_CRASH")
  [function]
 catch kind,_reason->IO.inspect(%{function: function,kind: kind},label: "ACTUAL_AUTOMATIC_SDK_THROW");[function]
 end
end)
report=BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(fixture["namespace"],"direct-report"),[])
true=is_map(report)
accepted=crashes==[] and report[:assertions]==fixture["expectedAssertions"] and report[:passed]==fixture["expectedAssertions"] and report[:failed]==0
verify.();native.()
result=%{mode: mode,expectedAssertions: fixture["expectedAssertions"],actualAssertions: report[:assertions],passed: report[:passed],failed: report[:failed],crashes: crashes,sourceCompileElapsedUs: compile_elapsed,accepted: accepted,scope: "actual physical SDK and graph issuer; isolated original assertion fixtures, not ordinary CLI or product/browser acceptance"}
File.write!(home<>"/"<>mode<>"-result.json",:json.encode(result))
IO.inspect(result,label: "ACTUAL_AUTOMATIC_SDK_COMPONENT")
System.halt(if accepted,do: 0,else: 70)
