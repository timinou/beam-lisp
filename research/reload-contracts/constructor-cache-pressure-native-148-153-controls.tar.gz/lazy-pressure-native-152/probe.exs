Application.load(:beam_lisp)
{:ok, deps} = :application.get_key(:beam_lisp, :applications)
Enum.each(deps, fn dep -> {:ok, _} = Application.ensure_all_started(dep) end)
:ok = BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
false = BeamLisp.LazyMemo.nif_loaded?()
module = BeamLisp.LazyMemo
artifact = "/home/user/tmp/product-online-20261014/round2/lazy-host-native-151/host/Elixir.BeamLisp.LazyMemo.beam"
{:module, ^module} = :code.load_binary(module, String.to_charlist(artifact), File.read!(artifact))
IO.inspect(Base.encode16(:crypto.hash(:sha256, File.read!(artifact)), case: :lower), label: "FRESH_PRE_NIF_HOST_SHA256")
BeamLisp.AOT.boot()
true = BeamLisp.LazyMemo.nif_loaded?()
IO.inspect({BeamLisp.Tiers.priv_root(), Base.encode16(:crypto.hash(:sha256, File.read!(BeamLisp.Tiers.priv_root() <> "/native/lazy_memo.so")), case: :lower), BeamLisp.LazyMemo.collector_status()}, label: "FRESH_NATIVE_COLLECTOR")
root = System.fetch_env!("BL_PROBE_ROOT")
# Reuse the exact Compiler artifacts produced and hashed by native106.
# This is a diagnostic overlay, never a coherent-floor acceptance.
for module <- [BeamLisp.Ns.Compiler, BeamLisp.Ns.Body.Compiler, BeamLisp.Ns.Init.Compiler] do
 artifact = "/home/user/tmp/product-online-20261014/round2/compiler-metadata-native-127/compiler-beams/" <> Atom.to_string(module) <> ".beam"
 {:module, ^module} = :code.load_binary(module, String.to_charlist(artifact), File.read!(artifact))
 IO.inspect({module, Base.encode16(:crypto.hash(:sha256, File.read!(artifact)), case: :lower)}, label: "REUSED_NATIVE_COMPILER")
end
for module <- [BeamLisp.SourceGraph, BeamLisp.NamespaceInterface] do
 artifact = "/home/user/tmp/product-online-20261014/round2/constructor-context-117/host/" <> Atom.to_string(module) <> ".beam"
 {:module, ^module} = :code.load_binary(module, String.to_charlist(artifact), File.read!(artifact))
end
for {module, directory} <- [{BeamLisp.BuildPlan, "constructor-context-119/host"}, {BeamLisp.AOT, "constructor-reader-native-123/host"}, {:"Elixir.BeamLisp.Ns.Reader-node", "constructor-reader-native-123/reader-beams"}, {:"Elixir.BeamLisp.Ns.Body.Reader-node", "constructor-reader-native-123/reader-beams"}, {BeamLisp.Ns.Reader, "constructor-reader-native-123/reader-beams"}, {BeamLisp.Ns.Body.Reader, "constructor-reader-native-123/reader-beams"}, {BeamLisp.Ns.Init.Reader, "constructor-reader-native-123/reader-beams"}] do
 artifact = "/home/user/tmp/product-online-20261014/round2/" <> directory <> "/" <> Atom.to_string(module) <> ".beam"
 {:module, ^module} = :code.load_binary(module, String.to_charlist(artifact), File.read!(artifact))
 IO.inspect({module, Base.encode16(:crypto.hash(:sha256, File.read!(artifact)), case: :lower)}, label: "EXACT_NATIVE_ARTIFACT")
end
for {module, folder} <- [{BeamLisp.CompilerData, "constructor-resource-free-native-147"}, {BeamLisp.AOT, "constructor-integrated-native-144"}] do
 artifact = "/home/user/tmp/product-online-20261014/round2/" <> folder <> "/host/" <> Atom.to_string(module) <> ".beam"
 {:module, ^module} = :code.load_binary(module, String.to_charlist(artifact), File.read!(artifact))
 IO.inspect({module, Base.encode16(:crypto.hash(:sha256, File.read!(artifact)), case: :lower)}, label: "REUSED_NATIVE_144_ARTIFACT")
end



fixtures = [{"pressure", "lazy.pressure-cycles.test", ["admission-collects-dead-cycles-and-preserves-live-cycles", "publication-pressure-retries-the-value-without-replaying-producer", "live-only-pressure-refuses-before-producer-and-keeps-live-data"], 29}, {"budget", "lazy.budget.test", ["zero-budget-refuses-the-fold-and-the-force-alike", "the-fold-and-the-force-reach-the-same-verdict", "a-refused-completion-still-wakes-the-owner-and-every-waiter", "concurrent-publishers-cannot-jointly-exceed-the-ceiling", "a-publication-leaves-no-reservation-behind", "a-cached-failure-replays-with-a-stable-frame-list", "peek-is-constant-size-and-the-full-state-api-is-unchanged", "the-cheap-counter-agrees-with-the-stats-map", "dispatch-on-a-tag-takes-a-peek-not-a-read", "a-peek-version-that-moved-no-longer-yields-a-recipe", "a-refused-fold-publication-leaves-a-terminal-cell", "a-refused-fold-claim-never-runs-the-producer"], nil}, {"host", "host.lazy-memo.test", ["the-native-facade-emits-the-complete-stub-surface", "the-pinned-native-facade-is-reproducible", "the-pure-dependency-predicates-answer-without-the-nif"], nil}]
ok = Enum.reduce(fixtures, true, fn {label, namespace, names, expected}, previous ->
 file = root <> "/" <> label <> ".direct.bl"
 try do
  BeamLisp.Compiler.eval_string(File.read!(file), BeamLisp.Compiler.new_env(namespace), file)
  crashes = Enum.flat_map(names, fn name ->
   try do
    IO.inspect({label, name}, label: "NATIVE_CASE_START")
    BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(namespace, name), [])
    []
   rescue error ->
    IO.inspect({label, name, error, BeamLisp.ExInfo.ex_data(error), __STACKTRACE__}, label: "CASE_CRASH", limit: 30)
    [name]
   end
  end)
  report = BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(namespace, "direct-report"), [])
  IO.inspect({label, report, crashes}, label: "NATIVE_ASSERTIONS", limit: :infinity)
  previous and crashes == [] and report[:assertions] > 0 and report[:assertions] == report[:pass] and (is_nil(expected) or report[:assertions] == expected)
 rescue error ->
  IO.inspect({label, error, BeamLisp.ExInfo.ex_data(error), __STACKTRACE__}, label: "FILE_CRASH", limit: 30)
  false
 end
end)
System.halt(if ok, do: 0, else: 1)
