Application.load(:beam_lisp)
{:ok, deps} = :application.get_key(:beam_lisp, :applications)
Enum.each(deps, fn dep -> {:ok, _} = Application.ensure_all_started(dep) end)
:ok = BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
BeamLisp.AOT.boot()
root = System.fetch_env!("BL_PROBE_ROOT")
# Reuse the exact Compiler artifacts produced and hashed by native106.
# This is a diagnostic overlay, never a coherent-floor acceptance.
for module <- [BeamLisp.Ns.Compiler, BeamLisp.Ns.Body.Compiler, BeamLisp.Ns.Init.Compiler] do
 artifact = "/home/user/tmp/product-online-20261014/round2/compiler-metadata-native-127/compiler-beams/" <> Atom.to_string(module) <> ".beam"
 {:module, ^module} = :code.load_binary(module, String.to_charlist(artifact), File.read!(artifact))
 IO.inspect({module, Base.encode16(:crypto.hash(:sha256, File.read!(artifact)), case: :lower)}, label: "REUSED_NATIVE_COMPILER")
end
for module <- [BeamLisp.SourceGraph, BeamLisp.NamespaceInterface] do
 artifact = "/home/user/tmp/product-online-20261014/round2/constructor-context-117/host/" <> Atom.to_string(module) <> ".beam"
 {:module, ^module} = :code.load_binary(module, String.to_charlist(artifact), File.read!(artifact))
end
for {module, directory} <- [{BeamLisp.BuildPlan, "constructor-context-119/host"}, {BeamLisp.AOT, "constructor-reader-native-123/host"}, {:"Elixir.BeamLisp.Ns.Reader-node", "constructor-reader-native-123/reader-beams"}, {:"Elixir.BeamLisp.Ns.Body.Reader-node", "constructor-reader-native-123/reader-beams"}, {BeamLisp.Ns.Reader, "constructor-reader-native-123/reader-beams"}, {BeamLisp.Ns.Body.Reader, "constructor-reader-native-123/reader-beams"}, {BeamLisp.Ns.Init.Reader, "constructor-reader-native-123/reader-beams"}] do
 artifact = "/home/user/tmp/product-online-20261014/round2/" <> directory <> "/" <> Atom.to_string(module) <> ".beam"
 {:module, ^module} = :code.load_binary(module, String.to_charlist(artifact), File.read!(artifact))
 IO.inspect({module, Base.encode16(:crypto.hash(:sha256, File.read!(artifact)), case: :lower)}, label: "EXACT_NATIVE_ARTIFACT")
end
for {module, folder} <- [{BeamLisp.CompilerData, "constructor-resource-free-native-147"}, {BeamLisp.AOT, "constructor-integrated-native-144"}] do
 artifact = "/home/user/tmp/product-online-20261014/round2/" <> folder <> "/host/" <> Atom.to_string(module) <> ".beam"
 {:module, ^module} = :code.load_binary(module, String.to_charlist(artifact), File.read!(artifact))
 IO.inspect({module, Base.encode16(:crypto.hash(:sha256, File.read!(artifact)), case: :lower)}, label: "REUSED_NATIVE_144_ARTIFACT")
end


file = root <> "/cache.direct.bl"
BeamLisp.Compiler.eval_string(File.read!(file), BeamLisp.Compiler.new_env("aot-constructor-cache-test"), file)
benchmark = fn label ->
 value = BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!("aot-constructor-cache-test", "benchmark"), [])
 IO.inspect({label, value}, label: "CACHE_AB")
 value
end
before = benchmark.("baseline")
module = BeamLisp.AOT
artifact = "/home/user/tmp/product-online-20261014/round2/constructor-cache-native-148/host/Elixir.BeamLisp.AOT.beam"
{:module, ^module} = :code.load_binary(module, String.to_charlist(artifact), File.read!(artifact))
IO.inspect(Base.encode16(:crypto.hash(:sha256, File.read!(artifact)), case: :lower), label: "REUSED_CACHE_CANDIDATE")
after_result = benchmark.("candidate")
BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!("aot-constructor-cache-test", "cached-and-uncached-source-routing-remain-owned-and-shadow-aware"), [])
report = BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!("aot-constructor-cache-test", "direct-report"), [])
IO.inspect(report, label: "CACHE_NATIVE_ASSERTIONS", limit: :infinity)
ok = report[:assertions] == 8 and report[:pass] == 8 and before[:"cpp-calls"] == 32 and after_result[:"cpp-calls"] == 0 and before[:"metadata-calls"] == 100 and after_result[:"metadata-calls"] == 1
file = root <> "/staging.direct.bl"
namespace = "aot-sdk-constructor-staging-test"
BeamLisp.Compiler.eval_string(File.read!(file), BeamLisp.Compiler.new_env(namespace), file)
names = ["ordinary-compilation-does-not-have-sdk-constructor-authority", "ordinary-macro-kind-inspection-never-invokes-the-expander", "source-declaration-fold-uses-native-element-then-accumulator-order", "an-sdk-filename-with-different-source-refuses-before-effects", "cold-sdk-actor-source-never-borrows-mutable-core-or-initializes-provider", "canonical-native-namespace-is-not-invented-as-a-source-unit"]
crashes = Enum.flat_map(names, fn name ->
 try do
  IO.inspect({name, System.monotonic_time(:millisecond), BeamLisp.LazyMemo.stats()}, label: "NATIVE_CASE_START")
  BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(namespace, name), [])
  report = BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(namespace, "direct-report"), [])
  IO.inspect({name, Map.take(report, [:pass, :assertions]), System.monotonic_time(:millisecond), BeamLisp.LazyMemo.stats()}, label: "NATIVE_CASE_PROGRESS")
  []
 rescue error ->
  IO.inspect({name, error, BeamLisp.ExInfo.ex_data(error), __STACKTRACE__}, label: "CASE_CRASH", limit: 40)
  [name]
 end
end)
report = BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(namespace, "direct-report"), [])
IO.inspect({report, crashes}, label: "SDK_NATIVE_ASSERTIONS", limit: :infinity)
System.halt(if ok and crashes == [] and report[:pass] == 27 and report[:assertions] == 27, do: 0, else: 1)
