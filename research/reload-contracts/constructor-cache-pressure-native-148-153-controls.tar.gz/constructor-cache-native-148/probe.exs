Application.load(:beam_lisp)
{:ok, deps} = :application.get_key(:beam_lisp, :applications)
Enum.each(deps, fn dep -> {:ok, _} = Application.ensure_all_started(dep) end)
:ok = BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
BeamLisp.AOT.boot()
root = System.fetch_env!("BL_PROBE_ROOT")
# Reuse the exact Compiler artifacts produced and hashed by native106.
# This is a diagnostic overlay, never a coherent-floor acceptance.
for module <- [BeamLisp.Ns.Compiler, BeamLisp.Ns.Body.Compiler, BeamLisp.Ns.Init.Compiler] do
 artifact = "/home/user/tmp/product-online-20261014/round2/compiler-metadata-native-127/compiler-beams/" <> Atom.to_string(module) <> ".beam"
 {:module, ^module} = :code.load_binary(module, String.to_charlist(artifact), File.read!(artifact))
 IO.inspect({module, Base.encode16(:crypto.hash(:sha256, File.read!(artifact)), case: :lower)}, label: "REUSED_NATIVE_COMPILER")
end
for module <- [BeamLisp.SourceGraph, BeamLisp.NamespaceInterface] do
 artifact = "/home/user/tmp/product-online-20261014/round2/constructor-context-117/host/" <> Atom.to_string(module) <> ".beam"
 {:module, ^module} = :code.load_binary(module, String.to_charlist(artifact), File.read!(artifact))
end
for {module, directory} <- [{BeamLisp.BuildPlan, "constructor-context-119/host"}, {BeamLisp.AOT, "constructor-reader-native-123/host"}, {:"Elixir.BeamLisp.Ns.Reader-node", "constructor-reader-native-123/reader-beams"}, {:"Elixir.BeamLisp.Ns.Body.Reader-node", "constructor-reader-native-123/reader-beams"}, {BeamLisp.Ns.Reader, "constructor-reader-native-123/reader-beams"}, {BeamLisp.Ns.Body.Reader, "constructor-reader-native-123/reader-beams"}, {BeamLisp.Ns.Init.Reader, "constructor-reader-native-123/reader-beams"}] do
 artifact = "/home/user/tmp/product-online-20261014/round2/" <> directory <> "/" <> Atom.to_string(module) <> ".beam"
 {:module, ^module} = :code.load_binary(module, String.to_charlist(artifact), File.read!(artifact))
 IO.inspect({module, Base.encode16(:crypto.hash(:sha256, File.read!(artifact)), case: :lower)}, label: "EXACT_NATIVE_ARTIFACT")
end
for {module, folder} <- [{BeamLisp.CompilerData, "constructor-resource-free-native-147"}, {BeamLisp.AOT, "constructor-integrated-native-144"}] do
 artifact = "/home/user/tmp/product-online-20261014/round2/" <> folder <> "/host/" <> Atom.to_string(module) <> ".beam"
 {:module, ^module} = :code.load_binary(module, String.to_charlist(artifact), File.read!(artifact))
 IO.inspect({module, Base.encode16(:crypto.hash(:sha256, File.read!(artifact)), case: :lower)}, label: "REUSED_NATIVE_144_ARTIFACT")
end

file = root <> "/cache.direct.bl"
BeamLisp.Compiler.eval_string(File.read!(file), BeamLisp.Compiler.new_env("aot-constructor-cache-test"), file)
benchmark = fn label ->
 value = BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!("aot-constructor-cache-test", "benchmark"), [])
 IO.inspect({label, value}, label: "CACHE_AB")
 value
end
before = benchmark.("baseline")
saved = BeamLisp.Env.capture()
try do
 IO.inspect(BeamLisp.AOT.compile_host_file(root <> "/aot.bl", module: BeamLisp.AOT, output_dir: root <> "/host", load?: true), label: "FRESH_CACHE_CANDIDATE")
after
 BeamLisp.Env.bind(saved)
end
after_result = benchmark.("candidate")
name = "cached-and-uncached-source-routing-remain-owned-and-shadow-aware"
BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!("aot-constructor-cache-test", name), [])
report = BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!("aot-constructor-cache-test", "direct-report"), [])
IO.inspect(report, label: "CACHE_NATIVE_ASSERTIONS", limit: :infinity)
ok = report[:assertions] == 8 and report[:pass] == 8 and before[:"cpp-calls"] == 16 and after_result[:"cpp-calls"] == 1 and before[:"metadata-calls"] == 100 and after_result[:"metadata-calls"] == 1
System.halt(if ok, do: 0, else: 1)
