# Exact new pure native host API controls; not a coherent floor or CLI startup.
Application.load(:beam_lisp)
{:ok, dependencies} = :application.get_key(:beam_lisp, :applications)
Enum.each(dependencies, fn dep -> {:ok, _} = Application.ensure_all_started(dep) end)
:ok = BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
BeamLisp.AOT.boot()
root = System.fetch_env!("BL_PROBE_ROOT")
for module <- [BeamLisp.Ns.Compiler, BeamLisp.Ns.Body.Compiler, BeamLisp.Ns.Init.Compiler] do
 artifact = "/home/user/tmp/product-online-20261014/round2/constructor-context-106/compiler-beams/" <> Atom.to_string(module) <> ".beam"
 {:module, ^module} = :code.load_binary(module, String.to_charlist(artifact), File.read!(artifact))
end
:ok = BeamLisp.Env.push_load_path(root <> "/beam")
expected = root <> "/beam/data/first-order.bl"
true = BeamLisp.Loader.source_path("data.first-order") == expected
BeamLisp.Loader.ensure_loaded("data.first-order")
BeamLisp.Loader.ensure_loaded("proc.tick")
for namespace <- ["proc.server", "proc.tick"] do
 defs = BeamLisp.Env.ns_defs(namespace)
 bytes = :erlang.term_to_binary(defs)
 true = byte_size(bytes) <= 8 * 1024 * 1024
 File.write!(root <> "/" <> namespace <> ".env-anf.term", bytes)
 IO.inspect({namespace, map_size(defs), byte_size(bytes)}, label: "ACTUAL_NATIVE_DECLARATIONS")
end
for binding <- ["concat", "filter"] do
 IO.inspect(BeamLisp.Env.lookup({"core", binding}), label: "CORE_ABI_" <> binding, limit: 30, printable_limit: 500)
end
artifact = "/home/user/tmp/product-online-20261014/round2/constructor-context-114/host/Elixir.BeamLisp.AOT.beam"
{:module, BeamLisp.AOT} = :code.load_binary(BeamLisp.AOT, String.to_charlist(artifact), File.read!(artifact))
fixtures = [{"first-order", "data-first-order-test", ["ordinary-values-and-real-dense-and-trie-vectors-pass", "foreign-runtime-values-refuse-without-forcing", "malformed-vector-storage-refuses-before-protocol-dispatch", "sparse-vector-placement-and-forged-set-storage-refuse", "traversal-budgets-bound-raw-values", "native-kernel-boundary-preserves-sdk-refusals-and-reports-aggregate-cost"], 61}, {"machine", "aot-constructor-machine-test", ["actual-compiler-namespace-definitions-preserve-clause-construction", "native-effects-opaque-input-and-runaway-recursion-refuse-without-execution", "interpreted-lambdas-and-patterns-use-the-actual-compiler-scaffold", "real-tick-contribution-interprets-actual-clause-and-private-helper-anf", "recursive-actual-anf-control-is-depth-bounded", "foreign-shadowed-global-never-becomes-a-core-primitive-by-name", "concatenation-refuses-combined-size-before-native-copying", "mapcat-refuses-an-excessive-prefix-before-retaining-or-flattening-it", "retained-closure-captures-consume-a-cumulative-byte-budget", "interpreted-patterns-preserve-exact-erlang-literal-and-empty-list-matching", "repeated-pattern-variables-use-exact-erlang-equality", "join-proves-separator-expansion-before-native-allocation", "dynamically-created-keywords-have-a-pre-intern-budget", "core-run-and-native-invoke-keep-their-real-abi-identities", "constructed-foreign-structs-refuse-before-native-protocol-dispatch", "pure-primitive-adapters-refuse-unsupported-arities-before-dispatch", "supported-nth-and-merge-adapters-preserve-native-results", "admitted-sequence-type-predicate-matches-actual-runtime", "eager-sequence-family-preserves-runtime-shapes-and-empty-results", "eager-take-and-both-drop-abis-preserve-negative-zero-and-positive-counts", "eager-sequence-operations-refuse-deferred-structs-before-thunks-can-run", "eager-text-materialization-is-bounded-before-grapheme-allocation", "list-star-preserves-the-real-variadic-rest-argument-abi", "form-metadata-adapters-preserve-exact-values-and-authored-metadata", "vary-meta-invokes-only-the-interpreted-callback", "metadata-and-spread-refuse-deferred-structs-without-effects", "list-star-bounds-spread-materialization-before-runtime-allocation", "metadata-and-list-star-native-adapters-have-exact-arities", "closed-numeric-predicates-match-the-selected-native-runtime", "gensym-retains-runtime-prefix-semantics-and-global-hygiene", "fresh-symbol-creation-has-a-per-interpretation-admission-bound", "numeric-predicate-adapters-refuse-wrong-arities", "numeric-predicates-never-dispatch-on-foreign-structs", "native-list-reversal-preserves-supported-arity-and-type-semantics", "native-list-reversal-refuses-deferred-thunks-before-any-effects", "private-process-counter-frame-is-disposed-on-success-refusal-and-native-error"], 511}, {"syntax", "research.constructor-syntax-datum-test", ["regex-reader-literals-remain-inert-code-data-at-the-macro-boundary", "vector-author-metadata-survives-the-bounded-datum-roundtrip", "real-deodorant-declaration-arguments-are-source-data-without-registry-initialization", "actual-native-regex-object-is-explicitly-outside-the-syntax-datum-domain"], 84}, {"metadata", "compiler-metadata-datum-test", ["vector-author-metadata-is-data-at-the-macro-boundary", "author-data-and-reader-position-remain-separate", "plain-runtime-metadata-is-stable-on-repeated-datum-roundtrips"], 11}]
fixtures = fixtures ++ [{"pinned", "aot-pinned-declaration-test", ["executable-nested-host-declarations-refuse-before-source-effects", "genuine-host-forward-calls-and-quoted-declaration-data-remain-valid", "constructor-clause-and-form-helpers-are-actual-native-module-exports"], 18}]
ok = Enum.reduce(fixtures, true, fn {label, namespace, names, expected}, previous ->
 file = root <> "/" <> label <> ".direct.bl"
 try do
  BeamLisp.Compiler.eval_string(File.read!(file), BeamLisp.Compiler.new_env(namespace), file)
  crashes = Enum.flat_map(names, fn name ->
   try do
    value = BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(namespace, name), [])
    IO.inspect({label, name, value}, label: "NATIVE_CASE", limit: 15)
    []
   rescue
    error -> IO.inspect({label, name, error, BeamLisp.ExInfo.ex_data(error), __STACKTRACE__}, label: "NATIVE_CRASH", limit: 40); [name]
   catch
    kind, reason -> IO.inspect({label, name, kind, reason}, label: "NATIVE_THROW", limit: 30); [name]
   end
  end)
  report = BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(namespace, "direct-report"), [])
  IO.inspect({label, report, crashes}, label: "NATIVE_ASSERTIONS", limit: :infinity, printable_limit: :infinity)
  previous and crashes == [] and report[:assertions] == expected and report[:pass] == expected
 rescue
  error -> IO.inspect({label, error, __STACKTRACE__}, label: "NATIVE_FILE_CRASH", limit: 40); false
 end
end)
System.halt(if ok, do: 0, else: 1)
