Application.load(:beam_lisp)
{:ok, dependencies} = :application.get_key(:beam_lisp, :applications)
Enum.each(dependencies, fn dep -> {:ok, _} = Application.ensure_all_started(dep) end)
IO.inspect(BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN")), label: "verified_floor")
BeamLisp.AOT.boot()
BeamLisp.Loader.ensure_loaded("bl.cli")
runner = BeamLisp.Env.fetch_exact!("bl.cli", "run-argv")
{:ok, _root} = Supervisor.start_link([], strategy: :one_for_one, name: BeamLisp.Supervisor)
parent = self()
spawn(fn ->
  Enum.reduce(1..40, %{}, fn turn, previous ->
    Process.sleep(15000)
    rows = Enum.flat_map(Process.list(), fn pid ->
      case Process.info(pid, [:reductions, :status, :memory, :registered_name]) do
        nil -> []
        info -> [{pid, Keyword.fetch!(info, :reductions) - Map.get(previous, pid, 0), info}]
      end
    end)
    ranked = rows |> Enum.sort_by(fn {_, delta, _} -> -delta end) |> Enum.take(3)
    snapshots = Enum.map(ranked, fn {pid, delta, info} ->
      dictionary = case Process.info(pid, :dictionary) do
        {:dictionary, pairs} -> Keyword.take(pairs, [:bl_ns, :bl_loading])
        _ -> []
      end
      {pid, delta, info, dictionary, Process.info(pid, :current_stacktrace)}
    end)
    IO.inspect({turn, snapshots}, label: "PLAN_BUSY_NATIVE_SAMPLE", limit: :infinity, printable_limit: 2000)
    IO.inspect(Process.info(parent, [:status, :message_queue_len]), label: "PLAN_CALLER_SAMPLE")
    Map.new(rows, fn {pid, _, info} -> {pid, Keyword.fetch!(info, :reductions)} end)
  end)
end)
System.put_env("KNOWLEDGER_CREDENTIAL_KEY", String.duplicate("0123456789abcdef", 4))
status = BeamLisp.Ns.Rt.invoke(runner, [BeamLisp.Vector.new(["run", System.fetch_env!("BL_PROBE_ROOT") <> "/project-prepare.bl"])])
System.halt(if status == 0, do: 0, else: 1)
