#!/bin/bash
set -euo pipefail
unset BEAM_LISP_EBIN BEAM_LISP_PATH BL_ROOT BL_EBIN BL_BIN BL_BUILD_ID BL_BOOT_REEXECED BL_CONSTRUCTOR_METADATA_ROOT BL_KERNEL_SOURCE_UNDER_TEST
export BL_COMPONENT_HOME=/home/user/tmp/product-online-20261014/round2/kernel-definition-component239
export BL_DIAGNOSTIC=/home/user/tmp/product-online-20261014/round2/kernel-definition-component239/component.exs
export TMPDIR=/home/user/tmp/product-online-20261014/round2/kernel-definition-component239/tmp
export BEAM_LISP_AOT_CACHE_DIR=/home/user/tmp/product-online-20261014/round2/kernel-definition-component239/cache
export BL_DAEMON=off
export BL_AUTOBUILD=off
export BEAM_LISP_EBIN=/home/user/tmp/product-online-20261014/round2/kernel-definition-component239/image/lib/beam_lisp-0.1.0/ebin
cd /home/user/code/undefine/beam-lisp
exec /home/user/tmp/product-online-20261014/round2/kernel-definition-component239/wrapper
