home=System.fetch_env!("BL_COMPONENT_HOME")
main="/home/user/code/undefine/beam-lisp"
inputs=:json.decode(File.read!(home<>"/inputs.json"))
sha=fn p->Base.encode16(:crypto.hash(:sha256,File.read!(p)),case: :lower) end
verify=fn ->
 {head,0}=System.cmd("git",["rev-parse","HEAD"],cd: main)
 true=String.trim(head)==inputs["sourceCommit"]
 {"",0}=System.cmd("git",["status","--porcelain"],cd: main)
 for row<-inputs["sources"] do true=sha.(main<>"/"<>row["path"])==row["sha256"] end
end
verify.()
Application.load(:beam_lisp)
{:ok,deps}=:application.get_key(:beam_lisp,:applications)
Enum.each(deps,fn dep->{:ok,_}=Application.ensure_all_started(dep) end)
install=BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
true=install==:ok or install=={:staged,:compiler_key_mismatch}
BeamLisp.AOT.boot()
{:ok,[manifest]}=:file.consult(String.to_charlist(main<>"/priv/bootstrap/seed/manifest.term"))
objects=for mod<-[BeamLisp.AOT,BeamLisp.Env,BeamLisp.Emit,BeamLisp.Ns.Compiler,BeamLisp.Ns.Core,BeamLisp.Ns.Rt] do
 {^mod,bytes,_}=:code.get_object_code(mod)
 digest=Base.encode16(:crypto.hash(:sha256,bytes),case: :lower)
 true=digest==manifest["modules"][Atom.to_string(mod)<>".beam"]
 {:ok,{^mod,md5}}=:beam_lib.md5(bytes)
 true=md5==apply(mod,:module_info,[:md5])
 %{module: mod,sha256: digest}
end
false=:ets.member(:beam_lisp_vars,:bl_sdk_runtime_lease)
0=:ets.info(:beam_lisp_owner_index,:size)
defs=BeamLisp.Ns.Rt.__bl_ns_defs__()
selected=Map.take(defs,["reduced?","reduce-reduced?","seed-rows"])
true=map_size(selected)==3
# Only the two public kernel Source bodies are printed; no SDK/application input.
bodies=Map.take(selected,["reduced?","reduce-reduced?"])
File.write!(home<>"/kernel-bodies.txt",inspect(bodies,pretty: true,limit: :infinity,printable_limit: :infinity))
verify.()
result=%{componentDiagnosticPassed: true,currentFloorAccepted: false,sdkAccepted: false,seedObjects: objects,selectedDefinitionCount: map_size(bodies),bootstrapInstallStaged: install=={:staged,:compiler_key_mismatch},sourceCommit: inputs["sourceCommit"],outputSha256: sha.(home<>"/kernel-bodies.txt")}
File.write!(home<>"/result.json",:json.encode(result))
IO.inspect(result,label: "ACTUAL_KERNEL_DEFINITION_COMPONENT")
IO.puts("KERNEL_DEFINITION_COMPONENT_FINISHED")
System.halt(0)
