root = System.fetch_env!("BL_PROBE_ROOT")
Application.load(:beam_lisp)
{:ok, deps} = :application.get_key(:beam_lisp, :applications)
Enum.each(deps, fn dep -> {:ok, _} = Application.ensure_all_started(dep) end)
:ok = BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
BeamLisp.AOT.boot()
false = :ets.member(:beam_lisp_vars, :bl_sdk_runtime_lease)
sha = fn path -> Base.encode16(:crypto.hash(:sha256, File.read!(path)), case: :lower) end
inputs = :json.decode(File.read!(root <> "/inputs.json"))
for {leaf, directory} <- [{"anf", "anf"}, {"compiler", "compiler"}] do
 source = root <> "/" <> leaf <> ".candidate.bl"
 true = sha.(source) == inputs[leaf <> ".candidate.bl"]
 saved = BeamLisp.Env.capture()
 try do
  artifacts = BeamLisp.AOT.compile_file(source, output_dir: root <> "/" <> directory, mark_loaded?: true)
  true = :code.add_patha(String.to_charlist(root <> "/" <> directory))
  BeamLisp.AOTCache.run_init_modules(Enum.map(artifacts, &elem(&1, 0)), root <> "/" <> directory)
  for {module, path} <- artifacts do
   {:ok, {^module, md5}} = :beam_lib.md5(String.to_charlist(path))
   ^md5 = apply(module, :module_info, [:md5])
   IO.inspect({module, sha.(path)}, label: "COMPONENT_NATIVE_ARTIFACT")
  end
 after BeamLisp.Env.bind(saved) end
end
run = fn namespace, file, names, expected ->
 BeamLisp.Compiler.eval_string(File.read!(file), BeamLisp.Compiler.new_env(namespace), file)
 crashes = Enum.flat_map(names, fn name ->
  try do BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(namespace, name), []); []
  rescue error -> IO.inspect({name, BeamLisp.ExInfo.ex_data(error), __STACKTRACE__}, label: "COMPONENT_CASE_CRASH", limit: 30); [name] end
 end)
 report = BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(namespace, "direct-report"), [])
 IO.inspect({namespace, report, crashes}, label: "COMPONENT_ASSERTIONS", limit: :infinity)
 crashes == [] and report[:assertions] == expected and report[:pass] == expected
end
constants_ok = run.("compiler-anf-constant-test", root <> "/constants.direct.bl", ["immutable-anf-construction-preserves-public-value-compatibility", "compiler-ir-never-borrows-mutable-anf-empty-values"], 18)
hook_root = "/home/user/tmp/product-online-20261014/round2/actor-input-compile-native-164"
hook_ok = run.("compiler.input-hook-compile-test", hook_root <> "/compile-only-controls.direct.bl", ["native-pattern-walk-collects-real-bindings-without-wildcards", "native-hook-names-exact-source-export-and-actual-key-bindings", "actual-native-actor-compilation-emits-check-without-loading-or-running-class"], 21)
bl_util_ok = try do
 path = BeamLisp.Loader.source_path("bl.util")
 source = BeamLisp.Loader.read_source(path)
 result = BeamLisp.AOT.compile_source(source, [{:file, path}, {:"stage-sdk?", true}, {:output_dir, root <> "/output"}])
 IO.inspect(%{completed: true, artifacts: length(result)}, label: "ACTUAL_WHOLE_BL_UTIL_STAGE_PASS")
 true
rescue error ->
 IO.inspect({BeamLisp.ExInfo.ex_data(error), __STACKTRACE__}, label: "ACTUAL_WHOLE_BL_UTIL_STAGE_REFUSAL", limit: 40)
 false
end
false = :ets.member(:beam_lisp_vars, :bl_sdk_runtime_lease)
System.halt(if constants_ok and hook_ok and bl_util_ok, do: 0, else: 1)
