root = System.fetch_env!("BL_PROBE_ROOT")
Application.load(:beam_lisp)
{:ok, deps} = :application.get_key(:beam_lisp, :applications)
Enum.each(deps, fn dep -> {:ok, _} = Application.ensure_all_started(dep) end)
:ok = BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
BeamLisp.AOT.boot()
false = :ets.member(:beam_lisp_vars, :bl_sdk_runtime_lease)
base = "/home/user/tmp/product-online-20261014/round2/anf-constructors-169"
for {leaf, modules} <- [{"anf", [BeamLisp.Ns.Body.Anf, BeamLisp.Ns.Init.Anf, BeamLisp.Ns.Anf]}, {"compiler", [BeamLisp.Ns.Body.Compiler, BeamLisp.Ns.Init.Compiler, BeamLisp.Ns.Compiler]}] do
 directory = base <> "/" <> leaf
 for module <- modules do
  artifact = directory <> "/" <> Atom.to_string(module) <> ".beam"
  bytes = File.read!(artifact)
  {:module, ^module} = :code.load_binary(module, String.to_charlist(artifact), bytes)
  {:ok, {^module, md5}} = :beam_lib.md5(bytes)
  ^md5 = apply(module, :module_info, [:md5])
  IO.inspect({module, Base.encode16(:crypto.hash(:sha256, bytes), case: :lower)}, label: "REUSED_EXACT_169_ARTIFACT")
 end
 true = :code.add_patha(String.to_charlist(directory))
 BeamLisp.AOTCache.run_init_modules(modules, directory)
end
tracer = spawn(fn ->
 loop = fn loop ->
  receive do
   {:trace, _, :return_from, {BeamLisp.Env, :fetch!, 2}, value} ->
    IO.inspect(%{kind: cond do is_nil(value) -> :nil; is_function(value) -> :function; is_tuple(value) -> :tuple; true -> :other end}, label: "EXACT_ANF_VAR_RUNTIME_FETCH")
    loop.(loop)
   :stop -> :ok
   _ -> loop.(loop)
  end
 end
 loop.(loop)
end)
1 = :erlang.trace_pattern({BeamLisp.Env, :fetch!, 2}, [{["anf", "var"], [], [{:message, false}, {:return_trace}]}], [:local])
for pid <- Process.list(), pid != tracer do
 try do :erlang.trace(pid, true, [:call, :arity, :set_on_spawn, {:tracer, tracer}]) rescue ArgumentError -> :ok end
end
path = BeamLisp.Loader.source_path("bl.util")
source = BeamLisp.Loader.read_source(path)
try do
 result = BeamLisp.AOT.compile_source(source, [{:file, path}, {:"stage-sdk?", true}, {:output_dir, root <> "/output"}])
 IO.inspect(length(result), label: "FRESH_WHOLE_BL_UTIL_STAGE_PASS")
rescue error ->
 IO.inspect({error.__struct__, String.slice(Exception.message(error), 0, 512), BeamLisp.ExInfo.ex_data(error), __STACKTRACE__}, label: "FRESH_WHOLE_BL_UTIL_EXACT_REFUSAL", limit: 50)
end
System.halt(0)
