root = System.fetch_env!("BL_PROBE_ROOT")
Application.load(:beam_lisp)
{:ok, deps} = :application.get_key(:beam_lisp, :applications)
Enum.each(deps, fn dep -> {:ok, _} = Application.ensure_all_started(dep) end)
:ok = BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
BeamLisp.AOT.boot()
path = BeamLisp.Loader.source_path("core")
source = BeamLisp.Loader.read_source(path)
forms = BeamLisp.Reader.read_string(source, path)
definitions = BeamLisp.AOT.constructor_source_definitions(forms)
form = definitions["or"][:form]
true = not is_nil(form)
compiled = BeamLisp.Compiler.compile(form, BeamLisp.Compiler.new_env("core"))
expression = BeamLisp.AOT.constructor_initializer!(compiled, "core", "or")
File.write!(root <> "/regular-or-initializer.term", :erlang.term_to_binary(expression))
# Only expression positions are walked. Nil optional guards/after slots and
# arbitrary :lit values are intentionally inert. No ANF/source values printed.
walk = fn walk, node, path ->
 if not is_map(node) or not Map.has_key?(node, :op) or is_nil(node[:op]) do
  [%{path: path, kind: cond do is_nil(node) -> :nil; is_map(node) -> :map; is_list(node) -> :list; is_tuple(node) -> :tuple; true -> :other end}]
 else
  scalar = fn key -> walk.(walk, node[key], path <> "." <> Atom.to_string(key)) end
  many = fn values, label -> Enum.flat_map(Enum.with_index(values || []), fn {value, index} -> walk.(walk, value, path <> "." <> label <> "[" <> Integer.to_string(index) <> "]") end) end
  case node[:op] do
   op when op in [:lit, :var, :global, :enil] -> []
   op when op in [:remote, :arith] -> many.(node[:args], "args")
   :apply -> scalar.(:fn) ++ many.(node[:args], "args")
   :let -> scalar.(:init) ++ scalar.(:body)
   :if -> scalar.(:test) ++ scalar.(:then) ++ scalar.(:else)
   :do -> many.(node[:stmts], "stmts")
   :tuple -> many.(node[:elems], "elems")
   :cons -> scalar.(:head) ++ scalar.(:tail)
   op when op in [:map, :struct] ->
    key = if op == :map, do: :pairs, else: :fields
    Enum.flat_map(Enum.with_index(node[key] || []), fn {pair, index} ->
     list = BeamLisp.Ns.Rt."k-to-list"(pair)
     many.(list, Atom.to_string(key) <> "[" <> Integer.to_string(index) <> "]")
    end)
   op when op in [:fn, :case] ->
    prefix = if op == :case, do: scalar.(:subj), else: []
    prefix ++ Enum.flat_map(Enum.with_index(node[:clauses] || []), fn {clause, index} ->
     path = path <> ".clauses[" <> Integer.to_string(index) <> "]"
     guard = if is_nil(clause[:guard]), do: [], else: walk.(walk, clause[:guard], path <> ".guard")
     guard ++ walk.(walk, clause[:body], path <> ".body")
    end)
   _ -> []
  end
 end
end
IO.inspect(%{shape: expression[:op], invalid_children: walk.(walk, expression, "initializer")}, label: "REGULAR_CORE_OR_CANONICAL_ANF")
# Authenticated native component context matches the production SDK constructor
# boundary, but does not publish artifacts or initialize any SDK provider.
previous = BeamLisp.Env.capture()
target_path = BeamLisp.Loader.source_path("bl.util")
target_source = BeamLisp.Loader.read_source(target_path)
input = BeamLisp.AOT.constructor_source_input!("bl.util", target_path, target_source)
scope = BeamLisp.Env.fork(:global)
try do
 BeamLisp.Loader.without_initialization(fn ->
  BeamLisp.Env.with_env(scope, fn ->
   Process.put(:bl_sdk_constructor_context, %{:input => input, :"compiler-env" => scope, :units => %{}, :compiled => %{}, :compiling => BeamLisp.Set.new([]), :clauses => %{}, :"seen-macros" => BeamLisp.Set.new([]), :"kernel-modules" => BeamLisp.Set.new([]), :"kernel-leases" => [], :"macro-steps" => 16384, :"new-atoms" => 128, :expanded => 0})
   BeamLisp.AOT.constructor_install_kernel!()
   BeamLisp.AOT.constructor_unit!("bl.util")
   BeamLisp.Env.in_ns("bl.util")
   try do
    result = BeamLisp.AOT.constructor_compile_binding!("core", "or")
    expression = result[:expression]
    File.write!(root <> "/staged-or-initializer.term", :erlang.term_to_binary(expression))
    IO.inspect(%{shape: expression[:op], invalid_children: walk.(walk, expression, "initializer")}, label: "STAGED_CORE_OR_CANONICAL_ANF")
    for text <- ["(or)", "(or nil)", "(or nil 7)"] do
     try do
      form = hd(BeamLisp.Reader.read_string(text, "constructor-component"))
      value = BeamLisp.Compiler.compile(form, BeamLisp.Compiler.new_env("bl.util"))
      IO.inspect(%{case: text, shape: value[:op], invalid_children: walk.(walk, value, "expanded")}, label: "STAGED_OR_EXPANSION")
     rescue error -> IO.inspect(%{case: text, reason: BeamLisp.ExInfo.ex_data(error), stack: __STACKTRACE__}, label: "STAGED_OR_REFUSAL", limit: 30)
     end
    end
   rescue error -> IO.inspect({BeamLisp.ExInfo.ex_data(error), __STACKTRACE__}, label: "CORE_OR_COMPILATION_REFUSAL", limit: 30)
   end
  end)
 end)
after
 context = Process.get(:bl_sdk_constructor_context)
 if context, do: Enum.each(context[:"kernel-leases"], &BeamLisp.Env.release_code!/1)
 BeamLisp.Env.destroy(scope)
 Process.delete(:bl_sdk_constructor_context)
 BeamLisp.Env.bind(previous)
end
System.halt(0)
