root = "/home/user/tmp/product-online-20261014/round2/constructor-bl-util-167"
expressions = :erlang.binary_to_term(File.read!(root <> "/last-macro-expressions.private.term"))
seq = fn value -> cond do is_list(value) -> value; is_tuple(value) -> Tuple.to_list(value); is_map(value) and is_tuple(value[:items]) -> Tuple.to_list(value[:items]); true -> [] end end
walk = fn walk, node, path ->
 if not is_map(node) or is_nil(node[:op]) do
  [%{invalid: path, kind: if(is_nil(node), do: :nil, else: :other)}]
 else
  many = fn nodes, key -> Enum.flat_map(Enum.with_index(seq.(nodes)), fn {n,i} -> walk.(walk,n,path <> "." <> key <> "[" <> Integer.to_string(i) <> "]") end) end
  one = fn key -> walk.(walk,node[key],path <> "." <> Atom.to_string(key)) end
  case node[:op] do
   op when op in [:lit,:var,:global,:enil] -> []
   op when op in [:remote,:arith] -> [%{remote: {node[:mod],node[:fun]},path: path}] ++ many.(node[:args],"args")
   :apply -> one.(:fn) ++ many.(node[:args],"args")
   :let -> one.(:init) ++ one.(:body)
   :if -> one.(:test) ++ one.(:then) ++ one.(:else)
   :do -> many.(node[:stmts],"stmts")
   :tuple -> many.(node[:elems],"elems")
   :cons -> one.(:head) ++ one.(:tail)
   op when op in [:map,:struct] ->
    Enum.flat_map(Enum.with_index(seq.(node[if(op==:map,do: :pairs,else: :fields)])),fn {p,i}->many.(seq.(p),"pairs["<>Integer.to_string(i)<>"]") end)
   op when op in [:fn,:case] ->
    (if op==:case, do: one.(:subj), else: []) ++ Enum.flat_map(Enum.with_index(seq.(node[:clauses])),fn {c,i}->
     p=path<>".clauses["<>Integer.to_string(i)<>"]"
     (if is_nil(c[:guard]), do: [], else: walk.(walk,c[:guard],p<>".guard")) ++ walk.(walk,c[:body],p<>".body")
    end)
   _ -> []
  end
 end
end
Enum.each(Enum.with_index(expressions),fn {expression,i}->
 rows=walk.(walk,expression,"root")
 IO.inspect(%{index: i,root: expression[:op],invalid: Enum.filter(rows,&Map.has_key?(&1,:invalid)),remotes: Enum.uniq(Enum.map(Enum.filter(rows,&Map.has_key?(&1,:remote)),& &1.remote)),arg_count: length(expression[:args]||[])},label: "CAPTURED_PUBLIC_SDK_MACRO_SHAPE",limit: :infinity)
end)
