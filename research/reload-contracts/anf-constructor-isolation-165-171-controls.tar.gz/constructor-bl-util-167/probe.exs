root = System.fetch_env!("BL_PROBE_ROOT")
Application.load(:beam_lisp)
{:ok, deps} = :application.get_key(:beam_lisp, :applications)
Enum.each(deps, fn dep -> {:ok, _} = Application.ensure_all_started(dep) end)
:ok = BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
BeamLisp.AOT.boot()
path = BeamLisp.Loader.source_path("bl.util")
source = BeamLisp.Loader.read_source(path)
tracer = spawn(fn ->
 loop = fn loop, expressions, recent, invalid ->
  receive do
   {:trace, _pid, :call, {BeamLisp.AOT, :interpret_constructor!, 3}, expression} ->
    expressions = if :erlang.external_size(expression) <= 1048576, do: Enum.take([expression | expressions], 4), else: expressions
    loop.(loop, expressions, recent, invalid)
   {:trace, _pid, :call, {BeamLisp.AOT, :constructor_interpret, 3}, {:op, op}} ->
    loop.(loop, expressions, Enum.take([op | recent], 24), invalid)
   {:trace, _pid, :call, {BeamLisp.AOT, :constructor_interpret, 3}, :invalid} ->
    IO.inspect(%{kind: :nil, recent_ops: recent}, label: "MINIMAL_INVALID_NODE")
    loop.(loop, expressions, recent, true)
   {:finish, from, ref} ->
    File.write!(root <> "/last-macro-expressions.private.term", :erlang.term_to_binary(Enum.reverse(expressions)))
    send(from, {ref, %{captured_expressions: length(expressions), invalid_node_seen: invalid, recent_ops: recent}})
   _ -> loop.(loop, expressions, recent, invalid)
  end
 end
 loop.(loop, [], [], false)
end)
1 = :erlang.trace_pattern({BeamLisp.AOT, :interpret_constructor!, 3}, [{[:"$1", :_, :_], [], [{:message, :"$1"}]}], [:local])
1 = :erlang.trace_pattern({BeamLisp.AOT, :constructor_interpret, 3}, [
 {[nil, :_, :_], [], [{:message, :invalid}]},
 {[:"$1", :_, :_], [{:is_map, :"$1"}, {:is_map_key, :op, :"$1"}], [{:message, {{:op, {:map_get, :op, :"$1"}}}}]}
], [:local])
for pid <- Process.list(), pid != tracer do
 try do :erlang.trace(pid, true, [:call, :arity, :set_on_spawn, {:tracer, tracer}]) rescue ArgumentError -> :ok end
end
try do
 result = BeamLisp.AOT.compile_source(source, [{:file, path}, {:"stage-sdk?", true}, {:output_dir, root <> "/output"}])
 IO.inspect(%{completed: true, result_kind: if(is_tuple(result), do: elem(result, 0), else: :other)}, label: "ACTUAL_BL_UTIL_STAGE_RESULT")
rescue error ->
 IO.inspect(BeamLisp.ExInfo.ex_data(error), label: "ACTUAL_BL_UTIL_STAGE_REFUSAL", limit: :infinity)
 IO.inspect(__STACKTRACE__, label: "ACTUAL_BL_UTIL_NATIVE_STACK", limit: 40)
after
 delivery = :erlang.trace_delivered(:all)
 receive do {:trace_delivered, :all, ^delivery} -> :ok after 5000 -> raise "delivery timeout" end
 ref = make_ref(); send(tracer, {:finish, self(), ref})
 receive do {^ref, summary} -> IO.inspect(summary, label: "MINIMAL_CONSTRUCTOR_TRACE", limit: :infinity) after 5000 -> raise "snapshot timeout" end
end
System.halt(0)
