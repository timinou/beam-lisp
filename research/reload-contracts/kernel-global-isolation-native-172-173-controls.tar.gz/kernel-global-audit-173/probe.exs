Application.load(:beam_lisp)
{:ok, deps} = :application.get_key(:beam_lisp, :applications)
Enum.each(deps, fn dep -> {:ok, _} = Application.ensure_all_started(dep) end)
:ok = BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
BeamLisp.AOT.boot()
root = System.fetch_env!("BL_PROBE_ROOT")
names = ["anf", "compiler", "lower", "reader-node", "rt", "reader", "sugar", "optimize", "server-clause", "diag", "data-readers"]
definitions = Map.new(names, fn name ->
 module = String.to_atom("Elixir.BeamLisp.Ns." <> Macro.camelize(name))
 module = if name in ["reader-node", "server-clause", "data-readers"], do: String.to_atom("Elixir.BeamLisp.Ns." <> String.capitalize(name)), else: module
 true = Code.ensure_loaded?(module)
 {name, apply(module, :__bl_ns_defs__, [])}
end)
walk = fn walk, value, source ->
 cond do
  is_map(value) and Map.get(value,:op) in [:lit, :plit] -> []
  is_map(value) and Map.get(value,:op) == :global ->
   target = {Map.get(value,:ns), Map.get(value,:name)}
   if Map.has_key?(definitions, elem(target,0)) do
    [%{source: source, target: target, kind: if(Map.has_key?(definitions[elem(target,0)],elem(target,1)), do: :function, else: :other), ann: Map.take(Map.get(value,:ann) || %{}, [:line,:column,:file])}]
   else [] end
  is_map(value) -> Enum.flat_map(Map.to_list(Map.delete(value,:ann)), fn {_,v}->walk.(walk,v,source) end)
  is_list(value) -> Enum.flat_map(value, &walk.(walk,&1,source))
  is_tuple(value) -> Enum.flat_map(Tuple.to_list(value), &walk.(walk,&1,source))
  true -> []
 end
end
rows=Enum.flat_map(definitions, fn {namespace,defs}->Enum.flat_map(defs,fn {binding,entries}->Enum.flat_map(entries,fn entry->walk.(walk,elem(entry,3),{namespace,binding}) end) end) end)
File.write!(root<>"/resolved-kernel-globals.term",:erlang.term_to_binary(rows))
IO.inspect(%{total: length(rows),functions: Enum.count(rows,&(&1.kind==:function)),rows: rows},label: "ACTUAL_BOOT_ANF_GLOBAL_READS",limit: :infinity,printable_limit: :infinity)
System.halt(0)
