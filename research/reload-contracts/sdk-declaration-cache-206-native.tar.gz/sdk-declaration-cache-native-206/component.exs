# Actual physical SDK staging only; Root launches against a newly accepted floor.
home=System.fetch_env!("BL_CACHE_COMPONENT_ROOT")
main=System.fetch_env!("BL_ROOT")
mode=System.fetch_env!("BL_CACHE_COMPONENT_MODE")
inputs=:json.decode(File.read!(home<>"/component-inputs.json"))
sha=fn path->Base.encode16(:crypto.hash(:sha256,File.read!(path)),case: :lower) end
Process.put(:sdk_cache_component_assertions,0)
checks=fn label,condition->
 if condition do Process.put(:sdk_cache_component_assertions,Process.get(:sdk_cache_component_assertions)+1);IO.puts("PASS "<>label)
 else raise("FAIL "<>label) end
end
verify_sources=fn ->checks.("all-exact-physical-source-files",Enum.all?(inputs["sources"],fn row->sha.(main<>"/"<>row["path"])==row["sha256"] end)) end
Enum.each(inputs["files"],fn {path,digest}->checks.("frozen-component-input:"<>path,sha.(home<>"/"<>path)==digest) end)
verify_sources.()
checks.("exact-manifest",sha.(main<>"/priv/bootstrap/seed/manifest.term")==inputs["manifestSha256"])
Application.load(:beam_lisp)
{:ok,dependencies}=:application.get_key(:beam_lisp,:applications)
Enum.each(dependencies,fn app->{:ok,_}=Application.ensure_all_started(app) end)
:ok=BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
BeamLisp.AOT.boot()
{:ok,[seed]}=:file.consult(String.to_charlist(main<>"/priv/bootstrap/seed/manifest.term"))
seed_modules=Map.new(seed["modules"])
verify_native=fn ->
 Enum.each([BeamLisp.AOT,BeamLisp.AOTCache,BeamLisp.Env,BeamLisp.Emit,BeamLisp.CompilerData,BeamLisp.Ns.Compiler],fn module->
  {:module,^module}=Code.ensure_loaded(module)
  {^module,bytes,_}=:code.get_object_code(module)
  checks.("native-object:"<>Atom.to_string(module),Base.encode16(:crypto.hash(:sha256,bytes),case: :lower)==Map.fetch!(seed_modules,Atom.to_string(module)<>".beam"))
  {:ok,{^module,md5}}=:beam_lib.md5(bytes)
  checks.("native-loaded:"<>Atom.to_string(module),apply(module,:module_info,[:md5])==md5)
 end)
end
verify_native.()
checks.("compiler-key",BeamLisp.AOTCache.current_compiler_key()==inputs["compilerKey"])
checks.("build-key",BeamLisp.AOTCache.build_key()==inputs["buildKey"])
checks.("no-sdk-lease-before",not :ets.member(:beam_lisp_vars,:bl_sdk_runtime_lease))
checks.("no-actors-before",:ets.info(:beam_lisp_owner_index,:size)==0)
units=inputs["units"]
Enum.each(units,fn unit->
 ns=unit["namespace"]
 selected=BeamLisp.Loader.source_path(ns)
 actual=File.stat!(selected);expected=File.stat!(main<>"/"<>unit["path"])
 checks.("actual-source-inode:"<>ns,{actual.major_device,actual.minor_device,actual.inode}=={expected.major_device,expected.minor_device,expected.inode})
 checks.("not-initialized-before:"<>ns,not BeamLisp.Env.loaded_ns?(ns))
 Enum.each(unit["deferredValues"],fn name->checks.("value-unbound-before:"<>ns<>"/"<>name,BeamLisp.Env.lookup({ns,name})==:error) end)
end)
# Local native call_count has no tracer callback and includes real recursive
# dependency stages. Native compiler work cannot hide behind a mocked counter.
mfa={BeamLisp.AOT,:constructor_compile_sdk_unit!,2}
checks.("actual-native-counter-installed",:erlang.trace_pattern(mfa,true,[:local,:call_count])==1)
started=System.monotonic_time(:microsecond)
Enum.each(units,fn unit->
 ns=unit["namespace"];source=BeamLisp.Loader.source_path(ns);shim=BeamLisp.Emit.module_for(ns)
 row=apply(BeamLisp.AOT,:stage_sdk_dependency!,[ns,source,shim])
 checks.("actual-staged-source:"<>ns,row[:"source-digest"]==:crypto.hash(:sha256,File.read!(source)))
 checks.("actual-complete-sdk-unit:"<>ns,BeamLisp.AOT.sdk_unit_compiled?(ns))
end)
elapsed=System.monotonic_time(:microsecond)-started
{:call_count,count}=:erlang.trace_info(mfa,:call_count)
:erlang.trace_pattern(mfa,false,[:local,:call_count])
checks.("constructor-count",if(mode=="cold",do: count>=length(units),else: count==0))
snapshot=Enum.map(units,fn unit->
 ns=unit["namespace"];shim=BeamLisp.Emit.module_for(ns)
 row=apply(BeamLisp.AOT,:source_sdk_receipt,[shim])
 modules=[shim|row[:"unit-references"]]
 key=BeamLisp.AOTCache.key_for_ns(ns);closure=BeamLisp.AOT.ns_closure_hash(ns)
 entry=apply(BeamLisp.AOTCache,:entry_dir,[key,closure])
 native=Enum.sort_by(Enum.map(modules,fn module->
  bytes=File.read!(entry<>"/"<>Atom.to_string(module)<>".beam")
  actual_row=apply(BeamLisp.AOT,:source_sdk_receipt,[module])
  checks.("actual-member-object:"<>Atom.to_string(module),actual_row[:sha256]==:crypto.hash(:sha256,bytes))
  {:ok,{^module,md5}}=:beam_lib.md5(bytes)
  checks.("actual-member-md5:"<>Atom.to_string(module),apply(module,:module_info,[:md5])==md5)
  %{"module"=>Atom.to_string(module),"sha256"=>Base.encode16(:crypto.hash(:sha256,bytes),case: :lower),"md5"=>Base.encode16(md5,case: :lower)}
 end),& &1["module"])
 checks.("not-initialized-after:"<>ns,not BeamLisp.Env.loaded_ns?(ns))
 Enum.each(unit["deferredValues"],fn name->checks.("value-unbound-after:"<>ns<>"/"<>name,BeamLisp.Env.lookup({ns,name})==:error) end)
 # A real complete cache entry must exist in the emitter's tier generation.
 key=BeamLisp.AOTCache.key_for_ns(ns);closure=BeamLisp.AOT.ns_closure_hash(ns)
 entry=apply(BeamLisp.AOTCache,:entry_dir,[key,closure])
 checks.("valid-persistent-tier-cache:"<>ns,Enum.sort(apply(BeamLisp.AOTCache,:valid_keyed_entry,[entry,key,closure])||[])==Enum.sort(modules))
 %{"namespace"=>ns,"sourceDigest"=>Base.encode16(row[:"source-digest"],case: :lower),"closure"=>closure,"key"=>key,"native"=>native}
end)
if mode=="warm" do
 cold=:json.decode(File.read!(home<>"/cold-result.json"))
 checks.("same-native-source-objects",snapshot==cold["units"])
 checks.("build-tier-is-distinct",Enum.find(snapshot,& &1["namespace"]=="mix-shim")["key"]==inputs["buildKey"] and inputs["buildKey"]!=inputs["compilerKey"])
 # Negative controls use only copies of the genuine completed cache. They do
 # not install edited metadata as SDK authority or execute a candidate factory.
 unit=hd(units);ns=unit["namespace"];source=BeamLisp.Loader.source_path(ns);content=File.read!(source);shim=BeamLisp.Emit.module_for(ns)
 key=BeamLisp.AOTCache.key_for_ns(ns);closure=BeamLisp.AOT.ns_closure_hash(ns)
 original=apply(BeamLisp.AOTCache,:entry_dir,[key,closure]);previous=System.fetch_env!("BEAM_LISP_AOT_CACHE_DIR")
 manifest=:erlang.binary_to_term(File.read!(original<>"/manifest.term"),[:safe])
 members=manifest.modules;body=Enum.find(members,& &1!=shim)
 parsed=apply(BeamLisp.AOT,:sdk_stage_manifest!,[File.read!(original<>"/manifest.term")])
 checks.("actual-v2-manifest-modules",parsed.modules==Enum.map(members,&Atom.to_string/1))
 checks.("actual-v2-manifest-digests",parsed.digests==Map.new(manifest.digests,fn {m,d}->{Atom.to_string(m),d} end))
 closed_refusal=fn fun->try do fun.();false rescue _->true end end
 malformed=[
  {:compressed,:erlang.term_to_binary(manifest,[:compressed])},
  {:missing_field,:erlang.term_to_binary(Map.delete(manifest,:digests))},
  {:duplicate_modules,:erlang.term_to_binary(%{manifest|modules: [shim,shim]})},
  {:improper_modules,:erlang.term_to_binary(%{manifest|modules: [shim|:bad_tail]})},
  {:reference_module,:erlang.term_to_binary(%{manifest|modules: [make_ref()]})},
  {:function_module,:erlang.term_to_binary(%{manifest|modules: [fn->raise "MUST NEVER RUN" end]})},
  {:bad_digest,:erlang.term_to_binary(%{version: 2,modules: [shim],digests: %{shim=><<1>>}})},
  {:mismatched_keys,:erlang.term_to_binary(%{version: 2,modules: [shim],digests: %{body=><<0::256>>}})},
  {:too_many_modules,:erlang.term_to_binary(%{manifest|modules: List.duplicate(shim,8193)})},
  {:trailing,:erlang.term_to_binary(manifest)<><<0>>},
  {:truncated,binary_part(:erlang.term_to_binary(manifest),0,15)},
  {:oversize,:binary.copy(<<0>>,1048577)}
 ]
 Enum.each(malformed,fn {label,bytes}->
  before=:erlang.system_info(:atom_count)
  refused=closed_refusal.(fn->apply(BeamLisp.AOT,:sdk_stage_manifest!,[bytes]) end)
  after_count=:erlang.system_info(:atom_count)
  checks.("manifest-refusal:"<>Atom.to_string(label),refused)
  checks.("manifest-no-atom-creation:"<>Atom.to_string(label),before==after_count)
 end)
 encode_atom=fn name-><<119,byte_size(name)>> <> name end
 fresh_name="Elixir.BeamLisp.CacheProbe.UniqueModuleNeverInterned204"
 fresh_manifest=<<131,116,0,0,0,3>><>encode_atom.("version")<><<97,2>><>encode_atom.("modules")<><<108,0,0,0,1>><>encode_atom.(fresh_name)<><<106>><>encode_atom.("digests")<><<116,0,0,0,1>><>encode_atom.(fresh_name)<><<109,0,0,0,32,0::256>>
 before=:erlang.system_info(:atom_count)
 fresh=apply(BeamLisp.AOT,:sdk_stage_manifest!,[fresh_manifest])
 after_count=:erlang.system_info(:atom_count)
 checks.("module-identities-stay-binary",fresh.modules==[fresh_name] and Map.keys(fresh.digests)==[fresh_name])
 checks.("fresh-name-not-interned",before==after_count and closed_refusal.(fn->:erlang.binary_to_existing_atom(fresh_name,:utf8) end))
 read_file=home<>"/bounded-read.bin";File.write!(read_file,<<1,2,3,4>>)
 checks.("bounded-read-exact",apply(BeamLisp.AOT,:sdk_cache_read_bounded!,[read_file,4])==<<1,2,3,4>>)
 checks.("bounded-read-overflow",closed_refusal.(fn->apply(BeamLisp.AOT,:sdk_cache_read_bounded!,[read_file,3]) end))
 checks.("bounded-read-zero-refused",closed_refusal.(fn->apply(BeamLisp.AOT,:sdk_cache_read_bounded!,[read_file,0]) end))
 File.rm!(read_file)
 Enum.each([:missing_manifest,:corrupt_object,:missing_member,:incomplete_unit,:wrong_compiler,:wrong_closure],fn fault->
  root=home<>"/faults/"<>Atom.to_string(fault);entry=root<>"/"<>key<>"/"<>closure
  File.mkdir_p!(Path.dirname(entry));{:ok,_}=File.cp_r(original,entry)
  case fault do
   :missing_manifest->File.rm!(entry<>"/manifest.term")
   :corrupt_object->File.write!(entry<>"/"<>Atom.to_string(body)<>".beam",<<0>>)
   :missing_member->File.rm!(entry<>"/"<>Atom.to_string(body)<>".beam")
   :incomplete_unit->File.write!(entry<>"/manifest.term",:erlang.term_to_binary(%{manifest|modules: List.delete(members,body),digests: Map.delete(manifest.digests,body)}))
   _->:ok
  end
  System.put_env("BEAM_LISP_AOT_CACHE_DIR",root)
  try do
   out=home<>"/negative-objects/"<>Atom.to_string(fault);File.mkdir_p!(out)
   effective_key=if fault==:wrong_compiler,do: String.duplicate("0",64),else: key
   effective_closure=if fault==:wrong_closure,do: String.duplicate("0",64),else: closure
   value=apply(BeamLisp.AOT,:sdk_stage_cached_unit,[ns,source,content,shim,effective_key,effective_closure,out])
   checks.("cache-refusal:"<>Atom.to_string(fault),value==nil)
   checks.("prior-native-unit-preserved:"<>Atom.to_string(fault),BeamLisp.AOT.sdk_unit_compiled?(ns))
   checks.("still-uninitialized:"<>Atom.to_string(fault),not BeamLisp.Env.loaded_ns?(ns))
  after System.put_env("BEAM_LISP_AOT_CACHE_DIR",previous) end
 end)
 # Independently authored raw native objects test the pre-load opcode/literal
 # validator only. They are NEVER candidates for positive SDK authority.
 for {module,attributes,body,reason}<-[
  {:CacheOnLoadRefusal,[{:attribute,1,:on_load,{:on_load,0}}],{:map,1,[]},:sdk_stage_cached_on_load_refused},
  {:CacheExecutableDefsRefusal,[],{:call,1,{:remote,1,{:atom,1,:erlang},{:atom,1,:error}},[{:atom,1,:must_never_execute}]},:sdk_stage_cached_definition_not_literal}
 ] do
  forms=[{:attribute,1,:module,module},{:attribute,1,:export,[{:__bl_ns_defs__,0},{:on_load,0}]}]++attributes++[
   {:function,1,:__bl_ns_defs__,0,[{:clause,1,[],[],[body]}]},
   {:function,1,:on_load,0,[{:clause,1,[],[],[{:atom,1,:ok}]}]}]
  {:ok,^module,bytes}=:compile.forms(forms,[:binary,:no_spawn_compiler_process])
  result=try do apply(BeamLisp.AOT,:sdk_stage_literal_definitions!,[module,bytes]);:unexpected_acceptance rescue e in ErlangError->e.original end
  checks.("native-preload-refusal:"<>Atom.to_string(module),result==reason)
  checks.("native-never-loaded:"<>Atom.to_string(module),not :erlang.module_loaded(module))
 end
end
checks.("no-sdk-lease-after",not :ets.member(:beam_lisp_vars,:bl_sdk_runtime_lease))
checks.("no-actors-after",:ets.info(:beam_lisp_owner_index,:size)==0)
verify_sources.();verify_native.()
result=%{"mode"=>mode,"actualAssertionsPassed"=>Process.get(:sdk_cache_component_assertions),"constructorCompileCalls"=>count,"stageElapsedUs"=>elapsed,"units"=>snapshot,"scope"=>"actual physical SDK compile-only staging; no value initialization/readiness/SDK lease or application acceptance"}
File.write!(home<>"/"<>mode<>"-result.json",:json.encode(result))
IO.inspect(result,label: "ACTUAL_SDK_DECLARATION_CACHE_COMPONENT",limit: :infinity)
