# Diagnostic native component only. Explicit ordinary header initialization
# is NOT an ordinary Launcher acceptance, SDK receipt or class permission.
root = System.fetch_env!("BL_PROBE_ROOT")
main = System.fetch_env!("BL_ROOT")
sha = fn p -> Base.encode16(:crypto.hash(:sha256,File.read!(p)),case: :lower) end
inputs = :json.decode(File.read!(root <> "/inputs.json"))
Enum.each(inputs["mainSources"],fn {p,d} -> true = sha.(main<>"/"<>p)==d end)
Enum.each(inputs["files"],fn {p,d} -> true = sha.(root<>"/"<>p)==d end)
Application.load(:beam_lisp)
{:ok,deps} = :application.get_key(:beam_lisp,:applications)
Enum.each(deps,fn d -> {:ok,_}=Application.ensure_all_started(d) end)
:ok = BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
BeamLisp.AOT.boot()
false = :ets.member(:beam_lisp_vars,:bl_sdk_runtime_lease)
{BeamLisp.AOT,path} = BeamLisp.AOT.compile_host_file(root<>"/aot.candidate.bl",module: BeamLisp.AOT,output_dir: root<>"/host",load?: false)
bytes = File.read!(path)
{:module,BeamLisp.AOT} = :code.load_binary(BeamLisp.AOT,String.to_charlist(path),bytes)
{:ok,{BeamLisp.AOT,md5}} = :beam_lib.md5(bytes)
^md5 = apply(BeamLisp.AOT,:module_info,[:md5])
IO.inspect(%{source: inputs["candidateSha256"],artifact: sha.(path),md5: Base.encode16(md5,case: :lower)},label: "DIAGNOSTIC_AOT_NATIVE_IDENTITY")
results = Enum.map(inputs["targets"],fn namespace ->
 source = BeamLisp.Loader.source_path(namespace)
 content = BeamLisp.Loader.read_source(source)
 true = sha.(source)==inputs["targetSources"][namespace]
 forms = BeamLisp.Reader.read_string(content,source)
 metadata = apply(BeamLisp.AOT,:capture_ns_decl,[%{},hd(forms)])[namespace]
 requires = metadata[:requires] || []
 IO.inspect(%{namespace: namespace,requires: requires},label: "EXPLICIT_COMPONENT_DEPENDENCY_INITIALIZATION")
 before = System.monotonic_time(:microsecond)
 Enum.each(requires,fn n -> BeamLisp.Loader.ensure_loaded(n) end)
 false = :ets.member(:beam_lisp_vars,:bl_sdk_runtime_lease)
 IO.inspect(%{namespace: namespace,microseconds: System.monotonic_time(:microsecond)-before},label: "COMPONENT_DEPENDENCIES_READY")
 saved = BeamLisp.Env.capture()
 before = System.monotonic_time(:microsecond)
 try do
  artifacts = BeamLisp.AOT.compile_source(content,[{:file,source},{:output_dir,root<>"/output/"<>namespace},{:"stage-sdk?",true}])
  # Native BL keyword spelling is :stage-sdk?, not Elixir identifier sugar.
  IO.inspect(%{namespace: namespace,artifacts: length(artifacts),microseconds: System.monotonic_time(:microsecond)-before},label: "TARGET_COMPILE_RESULT")
  %{namespace: namespace,status: :pass}
 rescue e ->
  data = BeamLisp.ExInfo.ex_data(e)
  safe = if is_map(data),do: Map.take(data,[:kind,:detail,:reason,:operation,:"constructor-operation",:"constructor-namespace",:"constructor-macro",:"constructor-call-stack"]),else: nil
  IO.inspect(%{namespace: namespace,error_type: e.__struct__,message: Exception.message(e),data: safe,microseconds: System.monotonic_time(:microsecond)-before},label: "TARGET_COMPILE_REFUSAL",limit: 50)
  IO.inspect(__STACKTRACE__,label: "TARGET_NATIVE_STACK",limit: 25)
  %{namespace: namespace,status: :refused}
 after BeamLisp.Env.bind(saved) end
end)
false = :ets.member(:beam_lisp_vars,:bl_sdk_runtime_lease)
Enum.each(inputs["mainSources"],fn {p,d} -> true = sha.(main<>"/"<>p)==d end)
IO.inspect(results,label: "TARGET_DIAGNOSTIC_RESULTS")
System.halt(if Enum.all?(results,&(&1.status==:pass)),do: 0,else: 70)
