# Component only. Candidate macro ANF is supplied to the bounded public
# interpreter, not installed as authenticated SDK Source or an SDK receipt.
root = System.fetch_env!("BL_PROBE_ROOT")
main = System.fetch_env!("BL_ROOT")
sha = fn p -> Base.encode16(:crypto.hash(:sha256,File.read!(p)),case: :lower) end
inputs = :json.decode(File.read!(root<>"/inputs.json"))
Enum.each(inputs["files"],fn {p,d} -> true = sha.(root<>"/"<>p)==d end)
Enum.each(inputs["mainSources"],fn {p,d} -> true = sha.(main<>"/"<>p)==d end)
Application.load(:beam_lisp)
{:ok,deps} = :application.get_key(:beam_lisp,:applications)
Enum.each(deps,fn d -> {:ok,_}=Application.ensure_all_started(d) end)
:ok=BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
BeamLisp.AOT.boot()
false=:ets.member(:beam_lisp_vars,:bl_sdk_runtime_lease)
path=root<>"/host/Elixir.BeamLisp.AOT.beam"
true=sha.(path)==inputs["profileArtifactSha256"]
{:module,BeamLisp.AOT}=:code.load_binary(BeamLisp.AOT,String.to_charlist(path),File.read!(path))
{:ok,{BeamLisp.AOT,expected_md5}}=:beam_lib.md5(File.read!(path))
^expected_md5=apply(BeamLisp.AOT,:module_info,[:md5])
IO.inspect(%{source: inputs["profileSourceSha256"],artifact: sha.(path)},label: "EXACT_187_PROFILE_NATIVE_REPLAY")
report=:atomics.new(2,[])
check=fn label,value ->
 :atomics.add(report,1,1)
 if value do :atomics.add(report,2,1) else IO.inspect(label,label: "LETFN_COMPONENT_FAILED") end
end
unwrap=fn unwrap,node ->
 if is_tuple(node) and tuple_size(node)==3 and elem(node,0)==:meta,do: unwrap.(unwrap,elem(node,1)),else: node
end
letfn_node=fn find,node ->
 node=unwrap.(unwrap,node)
 cond do
  is_tuple(node) and tuple_size(node)==2 and elem(node,0)==:list ->
   items=elem(node,1)
   head=if items==[],do: nil,else: unwrap.(unwrap,hd(items))
   if head=={:symbol,"letfn"},do: node,else: Enum.find_value(items,&find.(find,&1))
  is_tuple(node) and tuple_size(node)==2 and elem(node,0) in [:vector,:set] -> Enum.find_value(elem(node,1),&find.(find,&1))
  is_tuple(node) and tuple_size(node)==2 and elem(node,0)==:map -> Enum.find_value(elem(node,1),fn {k,v}->find.(find,k)||find.(find,v) end)
  true -> nil
 end
end
args_for=fn text ->
 form=hd(BeamLisp.Reader.read_string(text,"letfn-component"))
 node=letfn_node.(letfn_node,form)
 true=not is_nil(node)
 [apply(BeamLisp.Ns.Compiler,:datum,[node]),
  apply(BeamLisp.Ns.Compiler,:"macro-env",[BeamLisp.Compiler.new_env("component.letfn")]) |
  Enum.map(tl(elem(node,1)),&apply(BeamLisp.Ns.Compiler,:datum,[&1]))]
end
normalize=fn value ->
 # Alpha-rename only this expansion's exact generated TABLE symbol. Preserve
 # all user symbols, metadata, collection shape and literal values.
 bindings=Enum.at(value,1)
 table=elem(Map.fetch!(bindings,:items),0)
 rewrite=fn rewrite,node ->
  cond do
   node==table -> {:symbol,"COMPONENT_CANONICAL_TABLE"}
   is_list(node) -> Enum.map(node,&rewrite.(rewrite,&1))
   is_tuple(node) -> node|>Tuple.to_list()|>Enum.map(&rewrite.(rewrite,&1))|>List.to_tuple()
   is_map(node) -> Map.new(Map.to_list(node),fn {k,v}->{rewrite.(rewrite,k),rewrite.(rewrite,v)} end)
   true -> node
  end
 end
 rewrite.(rewrite,value)
end
native_old=BeamLisp.Env.fetch_exact!("core","letfn")
true=is_tuple(native_old) and elem(native_old,0)==:"$macro"
small=[
 {"self","(letfn [(f [n] (if (= n 0) 1 (* n (f (dec n)))))] (f 5))"},
 {"siblings","(letfn [(a [n] (if (= n 0) true (b (dec n)))) (b [n] (if (= n 0) false (a (dec n))))] (a 8))"},
 {"variadic","(letfn [(f [x & xs] (+ x (count xs)))] (f 10 1 2))"},
 {"shadow","(let [f 99] (letfn [(f [x] (let [f x] f))] (f 42)))"},
 {"quoted-name","(letfn [(f [x] '(f quoted))] (f 1))"},
 {"multi-arity-shape","(letfn [(f ([x] x) ([x y] (+ x y)))] (f 1 2))"}
]
original_capture=BeamLisp.Env.capture()
source=BeamLisp.Loader.source_path("reload.collection-constructor")
content=BeamLisp.Loader.read_source(source)
input=BeamLisp.AOT.constructor_source_input!("reload.collection-constructor",source,content)
scope=BeamLisp.Env.fork(:global)
try do
 BeamLisp.Loader.without_initialization(fn -> BeamLisp.Env.with_env(scope,fn ->
  Process.put(:bl_sdk_constructor_context,%{:input=>input,:"compiler-env"=>scope,:units=>%{},:compiled=>%{},:compiling=>BeamLisp.Set.new([]),:clauses=>%{},:"seen-macros"=>BeamLisp.Set.new([]),:"kernel-modules"=>BeamLisp.Set.new([]),:"kernel-leases"=>[],:"macro-steps"=>16384,:"new-atoms"=>128,:expanded=>0})
  BeamLisp.AOT.constructor_install_kernel!()
  BeamLisp.AOT.constructor_unit!("reload.collection-constructor")
  BeamLisp.Env.in_ns("reload.collection-constructor")
  old=BeamLisp.AOT.constructor_compile_binding!("core","letfn")[:expression]
  candidate_form=hd(BeamLisp.Reader.read_string(File.read!(root<>"/letfn.candidate.bl"),root<>"/letfn.candidate.bl"))
  compiled=BeamLisp.Compiler.compile(candidate_form,BeamLisp.Compiler.new_env("core"))
  new=BeamLisp.AOT.constructor_initializer!(compiled,"core","letfn")
  expand=fn initializer,args ->
   expression=%{op: :apply,fn: Enum.at(initializer[:elems],1),args: Enum.map(args,&%{op: :lit,val: &1})}
   apply(BeamLisp.AOT,:constructor_profile_component!,[expression,%{},%{}])
  end
  Enum.each(small,fn {label,text} ->
   args=args_for.(text)
   a=expand.(old,args);b=expand.(new,args)
   native=BeamLisp.Ns.Rt.invoke(elem(native_old,1),args)
   check.(label<>" exact bounded expansion",normalize.(a.value)==normalize.(b.value))
   check.(label<>" exact native expansion",normalize.(a.value)==normalize.(native))
   check.(label<>" no additional macro allocations",b[:"allocation-nodes"]<=1_000_000 and b[:"allocation-bytes"]<=16_777_216)
  end)
  Enum.each([2,4,6],fn n ->
   specs=Enum.map_join(0..(n-1)," ",fn i -> "(f"<>Integer.to_string(i)<>" [x] (do "<>Enum.map_join(1..16," ",&Integer.to_string/1)<>" x))" end)
   args=args_for.("(letfn ["<>specs<>"] (f0 1))")
   rows=Enum.map([:old,:new,:new,:old],fn which ->
    before=System.monotonic_time(:microsecond)
    result=expand.(if(which==:old,do: old,else: new),args)
    %{variant: which,microseconds: System.monotonic_time(:microsecond)-before,steps: result.steps,value: result.value}
   end)
   check.("padded "<>Integer.to_string(n)<>" exact AST parity",Enum.all?(rows,&(normalize.(&1.value)==normalize.(hd(rows).value))))
   check.("padded "<>Integer.to_string(n)<>" both fit unchanged work budget",Enum.all?(rows,&(&1.steps>0 and &1.steps<=1_000_000)))
   if n==6,do: check.("largest paired component reduces repeated work",Enum.max(Enum.map(Enum.filter(rows,&(&1.variant==:new)),& &1.steps))<Enum.min(Enum.map(Enum.filter(rows,&(&1.variant==:old)),& &1.steps)))
   IO.inspect(%{siblings: n,paddingForms: 16,rows: Enum.map(rows,&Map.delete(&1,:value))},label: "PAIRED_FIXED_BUDGET_MACRO_COMPONENT")
  end)
  forms=BeamLisp.Reader.read_string(content,source)
  real=Enum.find_value(forms,&letfn_node.(letfn_node,&1))
  true=not is_nil(real)
  args=[apply(BeamLisp.Ns.Compiler,:datum,[real]),
        apply(BeamLisp.Ns.Compiler,:"macro-env",[BeamLisp.Compiler.new_env("reload.collection-constructor")]) |
        Enum.map(tl(elem(real,1)),&apply(BeamLisp.Ns.Compiler,:datum,[&1]))]
  old_reason=try do expand.(old,args);:unexpected_pass rescue e -> BeamLisp.ExInfo.ex_data(e)[:detail] end
  check.("original real producer reaches unchanged step budget",old_reason==:"step-budget")
  before=System.monotonic_time(:microsecond)
  result=expand.(new,args)
  check.("candidate real producer fits unchanged step budget",result.steps<=1_000_000)
  IO.inspect(%{steps: result.steps,microseconds: System.monotonic_time(:microsecond)-before,allocationNodes: result[:"allocation-nodes"],allocationBytes: result[:"allocation-bytes"]},label: "ACTUAL_SOURCE_LETFN_CANDIDATE_COMPONENT")
 end) end)
after
 context=Process.get(:bl_sdk_constructor_context)
 if context,do: Enum.each(context[:"kernel-leases"],&BeamLisp.Env.release_code!/1)
 Process.delete(:bl_sdk_constructor_context)
 BeamLisp.Env.destroy(scope)
 BeamLisp.Env.bind(original_capture)
end
# Ordinary macro runtime behavior in isolated environments; no SDK receipt is
# granted to this candidate. Exact authenticated whole-unit staging waits for
# the coherent source floor with the candidate physically installed.
Enum.each(small,fn {label,text} ->
 values=Enum.map(["letfn.original.bl","letfn.candidate.bl"],fn macro_file ->
  private=BeamLisp.Env.fork(:global)
  try do BeamLisp.Env.with_env(private,fn ->
   BeamLisp.Compiler.eval_string(File.read!(root<>"/"<>macro_file),BeamLisp.Compiler.new_env("core"),root<>"/"<>macro_file)
   try do {:ok,BeamLisp.Compiler.eval_string(text,BeamLisp.Compiler.new_env("component.letfn"),"letfn-behavior")}
   rescue e -> {:error,e.__struct__,Exception.message(e)} end
  end) after BeamLisp.Env.destroy(private) end
 end)
 check.(label<>" native behavior/error parity",hd(values)==Enum.at(values,1))
end)
# Actual complete unit through ordinary Compiler.compile, with candidate
# macro binding private to this environment. This proves compiler behavior,
# not Source-owned SDK publication or receipts. No unit initializer executes.
forms=BeamLisp.Reader.read_string(content,source)
metadata=apply(BeamLisp.AOT,:capture_ns_decl,[%{},hd(forms)])["reload.collection-constructor"]
Enum.each(metadata[:requires]||[],&BeamLisp.Loader.ensure_loaded/1)
private=BeamLisp.Env.fork(:global)
try do BeamLisp.Env.with_env(private,fn ->
 BeamLisp.Compiler.eval_string(File.read!(root<>"/letfn.candidate.bl"),BeamLisp.Compiler.new_env("core"),root<>"/letfn.candidate.bl")
 ns="reload.collection-constructor"
 BeamLisp.Env.declare_ns(ns)
 BeamLisp.Env.in_ns(ns)
 Enum.each(metadata[:aliases]||[],fn {alias_name,target}->BeamLisp.Env.add_alias(ns,alias_name,target) end)
 Enum.each(tl(forms),&BeamLisp.Compiler.prelink_defn(&1,ns))
 before=System.monotonic_time(:microsecond)
 nodes=Enum.map(tl(forms),&BeamLisp.Compiler.compile(&1,BeamLisp.Compiler.new_env(ns)))
 check.("ordinary whole actual collection unit compiles without evaluating declarations",length(nodes)==length(tl(forms)) and Enum.all?(nodes,&(is_map(&1) and not is_nil(&1[:op]))))
 IO.inspect(%{forms: length(nodes),microseconds: System.monotonic_time(:microsecond)-before},label: "ORDINARY_COMPILER_WHOLE_UNIT_COMPONENT")
end) after BeamLisp.Env.destroy(private) end
marker=root<>"/forbidden-effect.marker"
File.rm(marker)
reason=try do
 BeamLisp.AOT.interpret_constructor!(%{op: :remote,mod: File,fun: :write!,args: [%{op: :lit,val: marker},%{op: :lit,val: "never"}]},%{},%{})
 :unexpected_pass
rescue e -> BeamLisp.ExInfo.ex_data(e)[:detail] end
check.("unknown native effects remain refused",is_map(reason) and Map.has_key?(reason,:remote))
check.("unknown native effects never run",not File.exists?(marker))
spin=%{op: :apply,fn: %{op: :global,ns: "component",name: "spin"},args: []}
body=%{op: :fn,clauses: [%{pats: [],guard: nil,body: spin}]}
reason=try do BeamLisp.AOT.interpret_constructor!(spin,%{},%{globals: %{BeamLisp.Vector.new(["component","spin"])=>body}});:unexpected_pass
rescue e -> BeamLisp.ExInfo.ex_data(e)[:detail] end
check.("runaway recursion keeps unchanged depth bound",reason==:"depth-budget")
false=:ets.member(:beam_lisp_vars,:bl_sdk_runtime_lease)
check.("no SDK lifetime claim",true)
Enum.each(inputs["mainSources"],fn {p,d}->true=sha.(main<>"/"<>p)==d end)
summary=%{assertions: :atomics.get(report,1),pass: :atomics.get(report,2)}
IO.inspect(summary,label: "LETFN_COMPONENT_ASSERTIONS")
System.halt(if summary.assertions==38 and summary.pass==38,do: 0,else: 1)
