Application.load(:beam_lisp)
{:ok, deps} = :application.get_key(:beam_lisp, :applications)
Enum.each(deps, fn dep -> {:ok, _} = Application.ensure_all_started(dep) end)
:ok = BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
root = System.fetch_env!("BL_PROBE_ROOT")
for {module, directory} <- [{BeamLisp.Ns.Compiler, "constructor-context-106/compiler-beams"}, {BeamLisp.Ns.Body.Compiler, "constructor-context-106/compiler-beams"}, {BeamLisp.Ns.Init.Compiler, "constructor-context-106/compiler-beams"}, {BeamLisp.SourceGraph, "constructor-context-117/host"}, {BeamLisp.NamespaceInterface, "constructor-context-117/host"}, {BeamLisp.BuildPlan, "constructor-context-119/host"}, {BeamLisp.AOT, "constructor-context-119/host"}] do
 artifact = "/home/user/tmp/product-online-20261014/round2/" <> directory <> "/" <> Atom.to_string(module) <> ".beam"
 {:module, ^module} = :code.load_binary(module, String.to_charlist(artifact), File.read!(artifact))
end
{:ok, _} = BeamLisp.Env.start_link([])
{:ok, _} = BeamLisp.Loader.Server.start_link([])
BeamLisp.Ns.Rt.seed_core()
BeamLisp.Ns.Core.__bl_init__()
BeamLisp.Env.mark_loaded("core")
BeamLisp.Reader.enable_bl_reader()
BeamLisp.Compiler.enable_bl_backend()
providers = ["build-plan", "source-graph", "ns-interface"]
loaded_before = Enum.map(providers, &BeamLisp.Env.loaded_ns?/1)
IO.inspect(loaded_before, label: "MINIMAL_BOOT_PROVIDER_STATUS")
source = "(ns isolated) (defn f [] 1)"
expected = Base.encode16(:crypto.hash(:sha256, "isolated:" <> Base.encode16(:crypto.hash(:sha256, source))), case: :lower)
actual = BeamLisp.Loader.without_initialization(fn -> BeamLisp.BuildPlan.key_for("isolated", fn _ -> source end, nil) end)
true = actual == expected
true = loaded_before == Enum.map(providers, &BeamLisp.Env.loaded_ns?/1)
IO.inspect({actual, loaded_before}, label: "FRESH_ARTIFACT_PURE_KEY")
# Complete ordinary minimal boot only AFTER independent native key check.
BeamLisp.AOT.boot()
fixtures = [{"pinned", "aot-pinned-declaration-test", ["executable-nested-host-declarations-refuse-before-source-effects", "genuine-host-forward-calls-and-quoted-declaration-data-remain-valid", "constructor-clause-and-form-helpers-are-actual-native-module-exports", "first-class-pinned-local-functions-refuse-before-native-emission", "explicit-native-local-closures-work-after-temporary-bindings-disappear"], 34}, {"planner", "pinned-build-plan-test", ["pure-pinned-planner-preserves-reference-interface-and-closure-keys", "content-interface-and-plan-parts-have-one-shared-semantic-owner", "interface-coverage-and-macro-invalidation-remain-exact", "pinned-planning-never-evaluates-source-forms", "pure-planner-needs-no-provider-init-or-inherited-callables", "aot-closure-validation-does-not-call-mutable-planner-provider-vars"], 25}, {"graph", "source-graph.test", ["header-ns-with-no-requires", "header-takes-only-each-specs-target", "header-no-ns-form-yields-nil-and-empty", "header-empty-source-is-nil-and-empty", "header-malformed-source-raises", "header-a-require-in-a-comment-is-not-an-edge", "header-refer-list-members-are-not-requires", "header-a-semicolon-in-a-string-does-not-truncate-the-form", "an-acyclic-graph-has-none", "a-two-node-cycle-is-named-as-a-closed-path", "the-bug-064-shape-a-four-node-substrate-application-cycle", "a-cycle-off-the-spine-of-an-acyclic-root-is-still-found", "a-self-require-is-a-cycle-of-one", "an-unresolvable-require-is-skipped-not-crashed-on", "closure-is-transitive-and-includes-self", "closure-is-cycle-safe", "hash-changes-iff-a-closure-members-source-hash-changes", "an-unresolvable-member-is-a-distinct-stable-contribution"], nil}, {"interface", "ns-interface.test", ["invariant-under-unobservable-edits", "sensitive-to-observable-edits", "names-cover-every-observable-definition", "a-bare-literal-top-level-form-names-nothing", "references-attribute-qualified-names", "plan-keys-on-interface-when-covered", "plan-without-interface-fields-is-the-closure-hash", "real-prelude-body-edit-rebuilds-one", "record-layout-and-generated-constructors-are-an-observable-interface", "record-constructor-edges-use-interface-and-still-invalidate-layout-edits"], nil}]
ok = Enum.reduce(fixtures, true, fn {label, namespace, names, expected}, previous ->
 file = root <> "/" <> label <> ".direct.bl"
 try do
  BeamLisp.Compiler.eval_string(File.read!(file), BeamLisp.Compiler.new_env(namespace), file)
  crashes = Enum.flat_map(names, fn name ->
   try do
    BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(namespace, name), [])
    []
   rescue error ->
    IO.inspect({label, name, error, BeamLisp.ExInfo.ex_data(error), __STACKTRACE__}, label: "NATIVE_CASE_CRASH", limit: 35)
    [name]
   end
  end)
  report = BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(namespace, "direct-report"), [])
  IO.inspect({label, report, crashes}, label: "NATIVE_ASSERTIONS", limit: :infinity, printable_limit: :infinity)
  previous and crashes == [] and report[:assertions] > 0 and report[:pass] == report[:assertions] and (expected == nil or report[:assertions] == expected)
 rescue error ->
  IO.inspect({label, error, BeamLisp.ExInfo.ex_data(error), __STACKTRACE__}, label: "NATIVE_FILE_CRASH", limit: 40)
  false
 end
end)
System.halt(if ok, do: 0, else: 1)
