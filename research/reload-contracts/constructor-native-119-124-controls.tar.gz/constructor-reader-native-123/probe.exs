# Exact new pure native host API controls; not a coherent floor or CLI startup.
Application.load(:beam_lisp)
{:ok, dependencies} = :application.get_key(:beam_lisp, :applications)
Enum.each(dependencies, fn dep -> {:ok, _} = Application.ensure_all_started(dep) end)
:ok = BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
BeamLisp.AOT.boot()
root = System.fetch_env!("BL_PROBE_ROOT")
for module <- [BeamLisp.Ns.Compiler, BeamLisp.Ns.Body.Compiler, BeamLisp.Ns.Init.Compiler] do
 artifact = "/home/user/tmp/product-online-20261014/round2/constructor-context-106/compiler-beams/" <> Atom.to_string(module) <> ".beam"
 {:module, ^module} = :code.load_binary(module, String.to_charlist(artifact), File.read!(artifact))
end
:ok = BeamLisp.Env.push_load_path(root <> "/beam")
expected = root <> "/beam/data/first-order.bl"
true = BeamLisp.Loader.source_path("data.first-order") == expected
BeamLisp.Loader.ensure_loaded("data.first-order")
BeamLisp.Loader.ensure_loaded("proc.tick")
for namespace <- ["proc.server", "proc.tick"] do
 defs = BeamLisp.Env.ns_defs(namespace)
 bytes = :erlang.term_to_binary(defs)
 true = byte_size(bytes) <= 8 * 1024 * 1024
 File.write!(root <> "/" <> namespace <> ".env-anf.term", bytes)
 IO.inspect({namespace, map_size(defs), byte_size(bytes)}, label: "ACTUAL_NATIVE_DECLARATIONS")
end
for binding <- ["concat", "filter"] do
 IO.inspect(BeamLisp.Env.lookup({"core", binding}), label: "CORE_ABI_" <> binding, limit: 30, printable_limit: 500)
end
for {module, directory} <- [{BeamLisp.SourceGraph, "constructor-context-117/host"}, {BeamLisp.NamespaceInterface, "constructor-context-117/host"}, {BeamLisp.BuildPlan, "constructor-context-119/host"}] do
 artifact = "/home/user/tmp/product-online-20261014/round2/" <> directory <> "/" <> Atom.to_string(module) <> ".beam"
 {:module, ^module} = :code.load_binary(module, String.to_charlist(artifact), File.read!(artifact))
end
saved = BeamLisp.Env.capture()
try do
 IO.inspect(BeamLisp.AOT.compile_host_file(root <> "/aot.bl", module: BeamLisp.AOT, output_dir: root <> "/host", load?: true), label: "FRESH_NATIVE_AOT")
after
 BeamLisp.Env.bind(saved)
end
for leaf <- ["reader-node.bl", "reader.bl"] do
 saved = BeamLisp.Env.capture()
 try do
  IO.inspect(BeamLisp.AOT.compile_file(root <> "/" <> leaf, output_dir: root <> "/reader-beams"), label: "FRESH_NATIVE_READER")
 after
  BeamLisp.Env.bind(saved)
 end
end
fixtures = [{"first-order", "data-first-order-test", ["ordinary-values-and-real-dense-and-trie-vectors-pass", "foreign-runtime-values-refuse-without-forcing", "malformed-vector-storage-refuses-before-protocol-dispatch", "sparse-vector-placement-and-forged-set-storage-refuse", "traversal-budgets-bound-raw-values", "native-kernel-boundary-preserves-sdk-refusals-and-reports-aggregate-cost"], 61}, {"machine", "aot-constructor-machine-test", ["actual-compiler-namespace-definitions-preserve-clause-construction", "native-effects-opaque-input-and-runaway-recursion-refuse-without-execution", "interpreted-lambdas-and-patterns-use-the-actual-compiler-scaffold", "real-tick-contribution-interprets-actual-clause-and-private-helper-anf", "recursive-actual-anf-control-is-depth-bounded", "foreign-shadowed-global-never-becomes-a-core-primitive-by-name", "concatenation-refuses-combined-size-before-native-copying", "mapcat-refuses-an-excessive-prefix-before-retaining-or-flattening-it", "retained-closure-captures-consume-a-cumulative-byte-budget", "interpreted-patterns-preserve-exact-erlang-literal-and-empty-list-matching", "repeated-pattern-variables-use-exact-erlang-equality", "join-proves-separator-expansion-before-native-allocation", "dynamically-created-keywords-have-a-pre-intern-budget", "core-run-and-native-invoke-keep-their-real-abi-identities", "constructed-foreign-structs-refuse-before-native-protocol-dispatch", "pure-primitive-adapters-refuse-unsupported-arities-before-dispatch", "supported-nth-and-merge-adapters-preserve-native-results", "admitted-sequence-type-predicate-matches-actual-runtime", "eager-sequence-family-preserves-runtime-shapes-and-empty-results", "eager-take-and-both-drop-abis-preserve-negative-zero-and-positive-counts", "eager-sequence-operations-refuse-deferred-structs-before-thunks-can-run", "eager-text-materialization-is-bounded-before-grapheme-allocation", "list-star-preserves-the-real-variadic-rest-argument-abi", "form-metadata-adapters-preserve-exact-values-and-authored-metadata", "vary-meta-invokes-only-the-interpreted-callback", "metadata-and-spread-refuse-deferred-structs-without-effects", "list-star-bounds-spread-materialization-before-runtime-allocation", "metadata-and-list-star-native-adapters-have-exact-arities", "closed-numeric-predicates-match-the-selected-native-runtime", "gensym-retains-runtime-prefix-semantics-and-global-hygiene", "fresh-symbol-creation-has-a-per-interpretation-admission-bound", "numeric-predicate-adapters-refuse-wrong-arities", "numeric-predicates-never-dispatch-on-foreign-structs", "native-list-reversal-preserves-supported-arity-and-type-semantics", "native-list-reversal-refuses-deferred-thunks-before-any-effects", "private-process-counter-frame-is-disposed-on-success-refusal-and-native-error"], 511}, {"recipe", "aot-constructor-recipe-test", ["interpreted-recipes-consume-finite-sequences-without-native-resources", "recipe-thunks-memoize-before-a-second-sequence-consumption", "private-recipe-shape-and-field-observations-refuse", "recipe-forgery-and-native-callbacks-never-gain-execution-authority", "finite-chain-and-cursor-materialization-never-invent-physical-cell-shapes", "nested-recipes-and-large-realized-prefixes-have-explicit-bounds", "finite-runtime-stack-guards-keep-the-selected-sorted-predicate-semantics", "finite-recipes-cannot-be-reinterpreted-as-ordinary-cons-tails", "opaque-observation-diagnostics-expose-only-fixed-native-target"], 36}, {"pinned", "aot-pinned-declaration-test", ["executable-nested-host-declarations-refuse-before-source-effects", "genuine-host-forward-calls-and-quoted-declaration-data-remain-valid", "constructor-clause-and-form-helpers-are-actual-native-module-exports", "first-class-pinned-local-functions-refuse-before-native-emission", "explicit-native-local-closures-work-after-temporary-bindings-disappear"], 34}, {"planner", "pinned-build-plan-test", ["pure-pinned-planner-preserves-reference-interface-and-closure-keys", "content-interface-and-plan-parts-have-one-shared-semantic-owner", "interface-coverage-and-macro-invalidation-remain-exact", "pinned-planning-never-evaluates-source-forms", "pure-planner-needs-no-provider-init-or-inherited-callables", "aot-closure-validation-does-not-call-mutable-planner-provider-vars"], 25}, {"graph", "source-graph.test", ["header-ns-with-no-requires", "header-takes-only-each-specs-target", "header-no-ns-form-yields-nil-and-empty", "header-empty-source-is-nil-and-empty", "header-malformed-source-raises", "header-a-require-in-a-comment-is-not-an-edge", "header-refer-list-members-are-not-requires", "header-a-semicolon-in-a-string-does-not-truncate-the-form", "an-acyclic-graph-has-none", "a-two-node-cycle-is-named-as-a-closed-path", "the-bug-064-shape-a-four-node-substrate-application-cycle", "a-cycle-off-the-spine-of-an-acyclic-root-is-still-found", "a-self-require-is-a-cycle-of-one", "an-unresolvable-require-is-skipped-not-crashed-on", "closure-is-transitive-and-includes-self", "closure-is-cycle-safe", "hash-changes-iff-a-closure-members-source-hash-changes", "an-unresolvable-member-is-a-distinct-stable-contribution"], 29}, {"interface", "ns-interface.test", ["invariant-under-unobservable-edits", "sensitive-to-observable-edits", "names-cover-every-observable-definition", "a-bare-literal-top-level-form-names-nothing", "references-attribute-qualified-names", "plan-keys-on-interface-when-covered", "plan-without-interface-fields-is-the-closure-hash", "real-prelude-body-edit-rebuilds-one", "record-layout-and-generated-constructors-are-an-observable-interface", "record-constructor-edges-use-interface-and-still-invalidate-layout-edits"], 38}, {"reader", "reader.test", ["literals", "symbols-and-keywords", "quoted-keyword-literals-bug-004", "collections", "nesting", "quote-sugar", "comments-and-commas-are-whitespace", "multiple-forms", "syntax-errors", "four-digit-escapes-decode-to-one-character", "braced-escapes-reach-above-the-bmp", "escapes-compose-with-surrounding-text", "the-other-escapes-still-work", "a-malformed-escape-is-an-error-not-a-mangled-string", "a-surrogate-half-is-rejected"], nil}, {"reader-meta", "reader-meta.test", ["literal-key-survives", "expression-key-evaluates", "for-rows-are-keyed", "map-preserves-key", "meta-invisible-to-equality", "no-meta-is-nil", "only-vectors-carry-runtime-meta", "threading-still-works", "reader-offsets-are-not-author-metadata"], nil}, {"reader-eager", "reader-eager-projection-test", ["syntax-projection-does-not-invoke-shadowed-core-collection-functions", "node-to-form-projection-uses-fixed-reader-helpers-and-exact-containers"], 12}]
ok = Enum.reduce(fixtures, true, fn {label, namespace, names, expected}, previous ->
 file = root <> "/" <> label <> ".direct.bl"
 try do
  BeamLisp.Compiler.eval_string(File.read!(file), BeamLisp.Compiler.new_env(namespace), file)
  crashes = Enum.flat_map(names, fn name ->
   try do
    BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(namespace, name), [])
    []
   rescue error ->
    IO.inspect({label, name, error, BeamLisp.ExInfo.ex_data(error), __STACKTRACE__}, label: "NATIVE_CASE_CRASH", limit: 35)
    [name]
   end
  end)
  report = BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(namespace, "direct-report"), [])
  IO.inspect({label, report, crashes}, label: "NATIVE_ASSERTIONS", limit: :infinity, printable_limit: :infinity)
  previous and crashes == [] and report[:assertions] > 0 and report[:pass] == report[:assertions] and (expected == nil or report[:assertions] == expected)
 rescue error ->
  IO.inspect({label, error, BeamLisp.ExInfo.ex_data(error), __STACKTRACE__}, label: "NATIVE_FILE_CRASH", limit: 40)
  false
 end
end)
System.halt(if ok, do: 0, else: 1)
