Application.load(:beam_lisp)
{:ok, deps} = :application.get_key(:beam_lisp, :applications)
Enum.each(deps, fn dep -> {:ok, _} = Application.ensure_all_started(dep) end)
:ok = BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
root = System.fetch_env!("BL_PROBE_ROOT")
for {module, directory} <- [{BeamLisp.Ns.Compiler, "constructor-context-106/compiler-beams"}, {BeamLisp.Ns.Body.Compiler, "constructor-context-106/compiler-beams"}, {BeamLisp.Ns.Init.Compiler, "constructor-context-106/compiler-beams"}, {BeamLisp.SourceGraph, "constructor-context-117/host"}, {BeamLisp.NamespaceInterface, "constructor-context-117/host"}, {BeamLisp.BuildPlan, "constructor-context-119/host"}, {BeamLisp.AOT, "constructor-context-119/host"}] do
 artifact = "/home/user/tmp/product-online-20261014/round2/" <> directory <> "/" <> Atom.to_string(module) <> ".beam"
 {:module, ^module} = :code.load_binary(module, String.to_charlist(artifact), File.read!(artifact))
end
{:ok, _} = BeamLisp.Env.start_link([])
{:ok, _} = BeamLisp.Loader.Server.start_link([])
BeamLisp.Ns.Rt.seed_core()
BeamLisp.Ns.Core.__bl_init__()
BeamLisp.Env.mark_loaded("core")
BeamLisp.Reader.enable_bl_reader()
BeamLisp.Compiler.enable_bl_backend()
providers = ["build-plan", "source-graph", "ns-interface"]
loaded_before = Enum.map(providers, &BeamLisp.Env.loaded_ns?/1)
IO.inspect(loaded_before, label: "MINIMAL_BOOT_PROVIDER_STATUS")
source = "(ns isolated) (defn f [] 1)"
expected = Base.encode16(:crypto.hash(:sha256, "isolated:" <> Base.encode16(:crypto.hash(:sha256, source))), case: :lower)
actual = BeamLisp.Loader.without_initialization(fn -> BeamLisp.BuildPlan.key_for("isolated", fn _ -> source end, nil) end)
true = actual == expected
true = loaded_before == Enum.map(providers, &BeamLisp.Env.loaded_ns?/1)
IO.inspect({actual, loaded_before}, label: "FRESH_ARTIFACT_PURE_KEY")
# Complete ordinary minimal boot only AFTER independent native key check.
BeamLisp.AOT.boot()
scope = BeamLisp.Env.fork(:global)
try do
 BeamLisp.Env.with_env(scope, fn ->
  for {namespace, name} <- [{"build-plan", "key-for"}, {"build-plan", "memo-node"}, {"core", "list"}, {"core", "count"}] do
   BeamLisp.Env.intern(namespace, name, nil)
  end
  BeamLisp.Loader.without_initialization(fn ->
   IO.inspect(BeamLisp.BuildPlan.key_for("isolated", fn _ -> "(ns isolated) (defn f [] 1)" end, nil), label: "SHADOWED_PURE_KEY")
  end)
 end)
rescue error ->
 IO.inspect({error, BeamLisp.ExInfo.ex_data(error), __STACKTRACE__}, label: "EXACT_SHADOW_FRONTIER", limit: 70, printable_limit: 5000)
 System.halt(1)
after
 BeamLisp.Env.destroy(scope)
end
