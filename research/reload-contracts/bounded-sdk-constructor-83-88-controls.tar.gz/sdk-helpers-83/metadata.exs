# Narrow native SDK metadata experiment, not ordinary Application startup.
Application.load(:beam_lisp)
{:ok, dependencies} = :application.get_key(:beam_lisp, :applications)
Enum.each(dependencies, fn dep -> {:ok, _} = Application.ensure_all_started(dep) end)
:ok = BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
BeamLisp.AOT.boot()
BeamLisp.Loader.ensure_loaded("proc.tick")
root = System.fetch_env!("BL_DIAGNOSTIC_OUTPUT")
for namespace <- ["proc.server", "proc.tick", "proc.reg"] do
  definitions = BeamLisp.Env.ns_defs(namespace)
  if map_size(definitions) > 0 do
    bytes = :erlang.term_to_binary(definitions)
    true = byte_size(bytes) <= 8 * 1024 * 1024
    file = root <> "/" <> namespace <> ".env-anf.term"
    File.write!(file, bytes)
    File.write!(file <> ".txt", inspect(definitions, pretty: true, limit: :infinity, printable_limit: :infinity))
    source = BeamLisp.Loader.source_path(namespace)
    IO.inspect(%{namespace: namespace, bytes: byte_size(bytes), functions: map_size(definitions),
                 source: source, source_sha256: Base.encode16(:crypto.hash(:sha256, File.read!(source)), case: :lower),
                 complete_compiler_unit: BeamLisp.AOT.sdk_unit_compiled?(namespace)}, label: "SDK_DECLARATION_METADATA")
  end
end
registry = BeamLisp.Env.fetch_exact!("proc.server", "registry")
IO.inspect(BeamLisp.Refs.deref(registry) |> Map.has_key?(:tick), label: "ACTUAL_TICK_REGISTRATION")
