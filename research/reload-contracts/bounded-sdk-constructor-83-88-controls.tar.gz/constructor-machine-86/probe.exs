# Minimal native constructor experiment; not normal Application/ward acceptance.
Application.load(:beam_lisp)
{:ok, dependencies} = :application.get_key(:beam_lisp, :applications)
Enum.each(dependencies, fn dep -> {:ok, _} = Application.ensure_all_started(dep) end)
:ok = BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
BeamLisp.AOT.boot()
BeamLisp.Loader.ensure_loaded("proc.tick")
root = System.fetch_env!("BL_CONSTRUCTOR_METADATA_ROOT")
for namespace <- ["proc.server", "proc.tick"] do
  definitions = BeamLisp.Env.ns_defs(namespace)
  bytes = :erlang.term_to_binary(definitions)
  true = byte_size(bytes) <= 8 * 1024 * 1024
  File.write!(root <> "/" <> namespace <> ".env-anf.term", bytes)
  IO.inspect({namespace, map_size(definitions), byte_size(bytes)}, label: "ACTUAL_NATIVE_DECLARATIONS")
end
:ok = BeamLisp.Env.push_load_path(root <> "/beam")
BeamLisp.Loader.ensure_loaded("research.constructor-machine")
file = root <> "/machine-direct.bl"
namespace = "research.constructor-machine-test"
BeamLisp.Compiler.eval_string(File.read!(file), BeamLisp.Compiler.new_env(namespace), file)
names = ["actual-compiler-namespace-definitions-preserve-clause-construction",
         "native-effects-opaque-input-and-runaway-recursion-refuse-without-execution",
         "interpreted-lambdas-and-patterns-use-the-actual-compiler-scaffold",
         "real-tick-contribution-interprets-actual-clause-and-private-helper-anf",
         "recursive-actual-anf-control-is-depth-bounded",
         "foreign-shadowed-global-never-becomes-a-core-primitive-by-name"]
crashes = Enum.flat_map(names, fn name ->
  try do
    value = BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(namespace, name), [])
    IO.inspect({name, value}, label: "CONSTRUCTOR_CASE")
    []
  rescue
    error ->
      IO.inspect({name, error, BeamLisp.ExInfo.ex_data(error), __STACKTRACE__}, label: "CONSTRUCTOR_CRASH", limit: 40)
      [name]
  catch
    kind, reason -> IO.inspect({name, kind, reason}, label: "CONSTRUCTOR_THROW"); [name]
  end
end)
report = BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(namespace, "direct-report"), [])
IO.inspect(report, label: "CONSTRUCTOR_ASSERTIONS", limit: 100)
IO.inspect(crashes, label: "CONSTRUCTOR_CRASHES")
System.halt(if crashes == [] and report[:assertions] == report[:pass] and report[:assertions] == 18, do: 0, else: 1)
