# Exact new pure native host API controls; not a coherent floor or CLI startup.
Application.load(:beam_lisp)
{:ok, dependencies} = :application.get_key(:beam_lisp, :applications)
Enum.each(dependencies, fn dep -> {:ok, _} = Application.ensure_all_started(dep) end)
:ok = BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
BeamLisp.AOT.boot()
root = System.fetch_env!("BL_PROBE_ROOT")
before = BeamLisp.Env.capture()
try do
  result = BeamLisp.AOT.compile_host_file(root <> "/compiler_data.bl",
             module: BeamLisp.CompilerData, output_dir: root <> "/host", load?: true)
  IO.inspect(result, label: "ACTUAL_FRESH_COMPILER_DATA")
after
  BeamLisp.Env.bind(before)
end
:ok = BeamLisp.Env.push_load_path(root <> "/beam")
expected = root <> "/beam/data/first-order.bl"
true = BeamLisp.Loader.source_path("data.first-order") == expected
BeamLisp.Loader.ensure_loaded("data.first-order")
BeamLisp.Loader.ensure_loaded("proc.tick")
for namespace <- ["proc.server", "proc.tick"] do
 defs = BeamLisp.Env.ns_defs(namespace)
 bytes = :erlang.term_to_binary(defs)
 true = byte_size(bytes) <= 8 * 1024 * 1024
 File.write!(root <> "/" <> namespace <> ".env-anf.term", bytes)
 IO.inspect({namespace, map_size(defs), byte_size(bytes)}, label: "ACTUAL_NATIVE_DECLARATIONS")
end
for binding <- ["concat", "filter"] do
 IO.inspect(BeamLisp.Env.lookup({"core", binding}), label: "CORE_ABI_" <> binding, limit: 30, printable_limit: 500)
end
BeamLisp.Loader.ensure_loaded("research.constructor-machine-production")
fixtures = [{"first-order", "data-first-order-test", ["ordinary-values-and-real-dense-and-trie-vectors-pass", "foreign-runtime-values-refuse-without-forcing", "malformed-vector-storage-refuses-before-protocol-dispatch", "sparse-vector-placement-and-forged-set-storage-refuse", "traversal-budgets-bound-raw-values", "native-kernel-boundary-preserves-sdk-refusals-and-reports-aggregate-cost"], 61}, {"machine", "research.constructor-machine-production-test", ["actual-compiler-namespace-definitions-preserve-clause-construction", "native-effects-opaque-input-and-runaway-recursion-refuse-without-execution", "interpreted-lambdas-and-patterns-use-the-actual-compiler-scaffold", "real-tick-contribution-interprets-actual-clause-and-private-helper-anf", "recursive-actual-anf-control-is-depth-bounded", "foreign-shadowed-global-never-becomes-a-core-primitive-by-name", "concatenation-refuses-combined-size-before-native-copying", "mapcat-refuses-an-excessive-prefix-before-retaining-or-flattening-it", "retained-closure-captures-consume-a-cumulative-byte-budget", "interpreted-patterns-preserve-exact-erlang-literal-and-empty-list-matching", "private-process-counter-frame-is-disposed-on-success-refusal-and-native-error"], 30}, {"syntax", "research.constructor-syntax-datum-test", ["regex-reader-literals-remain-inert-code-data-at-the-macro-boundary", "vector-author-metadata-survives-the-bounded-datum-roundtrip", "real-deodorant-declaration-arguments-are-source-data-without-registry-initialization", "actual-native-regex-object-is-explicitly-outside-the-syntax-datum-domain"], 84}]
ok = Enum.reduce(fixtures, true, fn {label, namespace, names, expected}, previous ->
 file = root <> "/" <> label <> ".direct.bl"
 try do
  BeamLisp.Compiler.eval_string(File.read!(file), BeamLisp.Compiler.new_env(namespace), file)
  crashes = Enum.flat_map(names, fn name ->
   try do
    value = BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(namespace, name), [])
    IO.inspect({label, name, value}, label: "NATIVE_CASE", limit: 15)
    []
   rescue
    error -> IO.inspect({label, name, error, BeamLisp.ExInfo.ex_data(error), __STACKTRACE__}, label: "NATIVE_CRASH", limit: 40); [name]
   catch
    kind, reason -> IO.inspect({label, name, kind, reason}, label: "NATIVE_THROW", limit: 30); [name]
   end
  end)
  report = BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(namespace, "direct-report"), [])
  IO.inspect({label, report, crashes}, label: "NATIVE_ASSERTIONS", limit: :infinity, printable_limit: :infinity)
  previous and crashes == [] and report[:assertions] == expected and report[:pass] == expected
 rescue
  error -> IO.inspect({label, error, __STACKTRACE__}, label: "NATIVE_FILE_CRASH", limit: 40); false
 end
end)
System.halt(if ok, do: 0, else: 1)
