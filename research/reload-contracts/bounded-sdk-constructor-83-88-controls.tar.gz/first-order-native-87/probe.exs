# Exact new pure native host API controls; not a coherent floor or CLI startup.
Application.load(:beam_lisp)
{:ok, dependencies} = :application.get_key(:beam_lisp, :applications)
Enum.each(dependencies, fn dep -> {:ok, _} = Application.ensure_all_started(dep) end)
:ok = BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
BeamLisp.AOT.boot()
root = System.fetch_env!("BL_PROBE_ROOT")
before = BeamLisp.Env.capture()
try do
  result = BeamLisp.AOT.compile_host_file(root <> "/compiler_data.bl",
             module: BeamLisp.CompilerData, output_dir: root <> "/host", load?: true)
  IO.inspect(result, label: "ACTUAL_FRESH_COMPILER_DATA")
after
  BeamLisp.Env.bind(before)
end
:ok = BeamLisp.Env.push_load_path(root <> "/beam")
expected = root <> "/beam/data/first-order.bl"
true = BeamLisp.Loader.source_path("data.first-order") == expected
BeamLisp.Loader.ensure_loaded("data.first-order")
file = root <> "/test.direct.bl"
namespace = "data-first-order-test"
BeamLisp.Compiler.eval_string(File.read!(file), BeamLisp.Compiler.new_env(namespace), file)
names = ["ordinary-values-and-real-dense-and-trie-vectors-pass",
         "foreign-runtime-values-refuse-without-forcing",
         "malformed-vector-storage-refuses-before-protocol-dispatch",
         "sparse-vector-placement-and-forged-set-storage-refuse",
         "traversal-budgets-bound-raw-values",
         "native-kernel-boundary-preserves-sdk-refusals-and-reports-aggregate-cost"]
crashes = Enum.flat_map(names, fn name ->
  try do
    result = BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(namespace, name), [])
    IO.inspect({name, result}, label: "FIRST_ORDER_CASE")
    []
  rescue
    error -> IO.inspect({name, error, __STACKTRACE__}, label: "FIRST_ORDER_CRASH", limit: 40); [name]
  catch
    kind, reason -> IO.inspect({name, kind, reason}, label: "FIRST_ORDER_THROW"); [name]
  end
end)
report = BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(namespace, "direct-report"), [])
IO.inspect(report, label: "FIRST_ORDER_ASSERTIONS", limit: 100)
IO.inspect(crashes, label: "FIRST_ORDER_CRASHES")
System.halt(if crashes == [] and report[:assertions] == 61 and report[:pass] == 61, do: 0, else: 1)
