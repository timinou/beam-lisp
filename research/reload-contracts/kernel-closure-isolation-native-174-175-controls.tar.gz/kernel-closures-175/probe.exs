root = System.fetch_env!("BL_PROBE_ROOT")
System.put_env("BL_COMPILER_SOURCE_UNDER_TEST", "/home/user/tmp/product-online-20261014/round2/kernel-closures-174/compiler.candidate.bl")
System.put_env("BL_KERNEL_SOURCE_UNDER_TEST", "/home/user/tmp/product-online-20261014/round2/kernel-closures-174")
Application.load(:beam_lisp)
{:ok, deps} = :application.get_key(:beam_lisp, :applications)
Enum.each(deps, fn dep -> {:ok, _} = Application.ensure_all_started(dep) end)
:ok = BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
BeamLisp.AOT.boot()
false = :ets.member(:beam_lisp_vars, :bl_sdk_runtime_lease)
sha = fn path -> Base.encode16(:crypto.hash(:sha256, File.read!(path)), case: :lower) end
inputs = :json.decode(File.read!(root <> "/inputs.json"))
# Reuse exact174 emitted artifact bytes; no Source kernel compilation.
artifact_rows = :json.decode(File.read!(root <> "/artifacts.json"))
prepared = Enum.map(artifact_rows, fn row ->
 bytes = File.read!(row["path"])
 true = sha.(row["path"]) == row["sha256"]
 module = String.to_existing_atom(row["module"])
 {:ok, {^module, md5}} = :beam_lib.md5(bytes)
 {row, module, bytes, md5}
end)
Enum.each(prepared, fn {row, module, bytes, md5} ->
 {:module, ^module} = :code.load_binary(module, String.to_charlist(row["path"]), bytes)
 ^md5 = apply(module, :module_info, [:md5])
 IO.inspect({module, row["sha256"]}, label: "REUSED_EXACT_174_NATIVE_ARTIFACT")
end)
for unit <- ["anf", "lower", "diag", "reader", "compiler"] do
 rows = Enum.filter(prepared, fn {row, _, _, _} -> row["unit"] == unit end)
 directory = Path.dirname(elem(hd(rows), 0)["path"])
 true = :code.add_patha(String.to_charlist(directory))
 BeamLisp.AOTCache.run_init_modules(Enum.map(rows, fn {_, module, _, _} -> module end), directory)
end
# Whole-unit staging runs first, without earlier fixture mutation.
bl_util_started = System.monotonic_time(:microsecond)
bl_util_ok = try do
 path = BeamLisp.Loader.source_path("bl.util")
 source = BeamLisp.Loader.read_source(path)
 result = BeamLisp.AOT.compile_source(source, [{:file, path}, {:"stage-sdk?", true}, {:output_dir, root <> "/output"}])
 IO.inspect(%{completed: true, artifacts: length(result), elapsed_us: System.monotonic_time(:microsecond) - bl_util_started}, label: "ACTUAL_WHOLE_BL_UTIL_STAGE_PASS")
 true
rescue error ->
 IO.inspect({error.__struct__, String.slice(Exception.message(error), 0, 512), BeamLisp.ExInfo.ex_data(error), __STACKTRACE__}, label: "ACTUAL_WHOLE_BL_UTIL_STAGE_REFUSAL", limit: 40)
 false
end
# Original oracle diagnosis: full ANF/Core equality, no normalization.
old_file = "/home/user/tmp/product-online-20261014/round2/kernel-closures-174/kernel.direct.bl"
BeamLisp.Compiler.eval_string(File.read!(old_file), BeamLisp.Compiler.new_env("compiler-kernel-values-test"), old_file)
namespace = "compiler-kernel-values-test"
invoke = fn name, args -> BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(namespace, name), args) end
inventory = invoke.("owned-inventory", [])
texts = ["()", "'(a b)", "(fn [x] x)", "(fn [& xs] xs)", "(let [[x & xs] []] xs)", "(System/get_env \"HOME\")", "(try 1 (catch error error) (finally nil))", "(receive x x (after 0 nil))"]
for {text, index} <- Enum.with_index(texts) do
 expected = invoke.("compile-probe", [text])
 expected_core = apply(BeamLisp.Ns.Lower, :"lower-anf", [expected])
 for {poison, kind} <- [{nil, :nil}, {%{op: :poison, pop: :poison}, :map}] do
  {actual, actual_core} = invoke.("with-masked-kernel", [inventory, poison, fn ->
   compiled = invoke.("compile-probe", [text])
   {compiled, apply(BeamLisp.Ns.Lower, :"lower-anf", [compiled])}
  end])
  IO.inspect(%{form_index: index, poison: kind, anf_equal: expected == actual, core_equal: expected_core == actual_core}, label: "ORIGINAL_ORACLE_COUNTER_DIAGNOSTIC")
 end
end
run = fn namespace, file, names, expected ->
 BeamLisp.Compiler.eval_string(File.read!(file), BeamLisp.Compiler.new_env(namespace), file)
 crashes = Enum.flat_map(names, fn name ->
  try do BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(namespace, name), []); []
  rescue error -> IO.inspect({name, BeamLisp.ExInfo.ex_data(error), __STACKTRACE__}, label: "COMPONENT_CASE_CRASH", limit: 30); [name] end
 end)
 report = BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(namespace, "direct-report"), [])
 IO.inspect({namespace, report, crashes}, label: "COMPONENT_ASSERTIONS", limit: :infinity)
 crashes == [] and report[:assertions] == expected and report[:pass] == expected
end
constants_ok = run.("compiler-anf-constant-test", root <> "/constants.direct.bl", ["immutable-anf-construction-preserves-public-value-compatibility", "compiler-ir-never-borrows-mutable-anf-empty-values", "reader-guard-detects-executable-anf-values-without-literal-false-positives", "compiler-source-keeps-anf-construction-on-native-call-sites", "malformed-function-diagnostics-never-borrow-reader-callback-values"], 32)
hook_root = "/home/user/tmp/product-online-20261014/round2/actor-input-compile-native-164"
hook_ok = run.("compiler.input-hook-compile-test", hook_root <> "/compile-only-controls.direct.bl", ["native-pattern-walk-collects-real-bindings-without-wildcards", "native-hook-names-exact-source-export-and-actual-key-bindings", "actual-native-actor-compilation-emits-check-without-loading-or-running-class"], 21)
kernel_ok = run.("compiler-kernel-values-test", root <> "/kernel.direct.bl", ["semantic-global-guard-preserves-literals-and-lexical-callbacks", "compiled-boot-kernel-never-borrows-its-source-function-or-data-values", "native-compilation-and-lowering-ignore-masked-source-kernel-values", "immutable-kernel-data-is-one-literal-and-preserves-compatibility-vars", "private-kernel-data-poison-cannot-change-native-reader-diag-or-compiler"], 124)
data_ok = true # The 90 data controls are included in kernel_ok (124 assertions).
false = :ets.member(:beam_lisp_vars, :bl_sdk_runtime_lease)
System.halt(if constants_ok and hook_ok and kernel_ok and data_ok and bl_util_ok, do: 0, else: 1)
