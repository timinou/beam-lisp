root = System.fetch_env!("BL_PROBE_ROOT")
System.put_env("BL_COMPILER_SOURCE_UNDER_TEST", root <> "/compiler.candidate.bl")
System.put_env("BL_KERNEL_SOURCE_UNDER_TEST", root)
Application.load(:beam_lisp)
{:ok, deps} = :application.get_key(:beam_lisp, :applications)
Enum.each(deps, fn dep -> {:ok, _} = Application.ensure_all_started(dep) end)
:ok = BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
BeamLisp.AOT.boot()
false = :ets.member(:beam_lisp_vars, :bl_sdk_runtime_lease)
sha = fn path -> Base.encode16(:crypto.hash(:sha256, File.read!(path)), case: :lower) end
inputs = :json.decode(File.read!(root <> "/inputs.json"))
# Compile/replay each exact candidate; public compatibility bindings remain
# available during bootstrap. No SDK runtime lease or candidate initializer.
for unit <- ["anf", "lower", "diag", "reader", "compiler"] do
 source = root <> "/" <> unit <> ".candidate.bl"
 true = sha.(source) == inputs[unit <> ".candidate.bl"]
 saved = BeamLisp.Env.capture()
 try do
  artifacts = BeamLisp.AOT.compile_file(source, output_dir: root <> "/" <> unit, mark_loaded?: true)
  true = :code.add_patha(String.to_charlist(root <> "/" <> unit))
  BeamLisp.AOTCache.run_init_modules(Enum.map(artifacts, &elem(&1, 0)), root <> "/" <> unit)
  for {module, path} <- artifacts do
   {:ok, {^module, md5}} = :beam_lib.md5(String.to_charlist(path))
   ^md5 = apply(module, :module_info, [:md5])
   IO.inspect({module, sha.(path)}, label: "COMPONENT_NATIVE_ARTIFACT")
  end
 after BeamLisp.Env.bind(saved) end
end
# Whole-unit staging runs first, without earlier fixture mutation.
bl_util_ok = try do
 path = BeamLisp.Loader.source_path("bl.util")
 source = BeamLisp.Loader.read_source(path)
 result = BeamLisp.AOT.compile_source(source, [{:file, path}, {:"stage-sdk?", true}, {:output_dir, root <> "/output"}])
 IO.inspect(%{completed: true, artifacts: length(result)}, label: "ACTUAL_WHOLE_BL_UTIL_STAGE_PASS")
 true
rescue error ->
 IO.inspect({error.__struct__, String.slice(Exception.message(error), 0, 512), BeamLisp.ExInfo.ex_data(error), __STACKTRACE__}, label: "ACTUAL_WHOLE_BL_UTIL_STAGE_REFUSAL", limit: 40)
 false
end
run = fn namespace, file, names, expected ->
 BeamLisp.Compiler.eval_string(File.read!(file), BeamLisp.Compiler.new_env(namespace), file)
 crashes = Enum.flat_map(names, fn name ->
  try do BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(namespace, name), []); []
  rescue error -> IO.inspect({name, BeamLisp.ExInfo.ex_data(error), __STACKTRACE__}, label: "COMPONENT_CASE_CRASH", limit: 30); [name] end
 end)
 report = BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(namespace, "direct-report"), [])
 IO.inspect({namespace, report, crashes}, label: "COMPONENT_ASSERTIONS", limit: :infinity)
 crashes == [] and report[:assertions] == expected and report[:pass] == expected
end
constants_ok = run.("compiler-anf-constant-test", root <> "/constants.direct.bl", ["immutable-anf-construction-preserves-public-value-compatibility", "compiler-ir-never-borrows-mutable-anf-empty-values", "reader-guard-detects-executable-anf-values-without-literal-false-positives", "compiler-source-keeps-anf-construction-on-native-call-sites", "malformed-function-diagnostics-never-borrow-reader-callback-values"], 32)
hook_root = "/home/user/tmp/product-online-20261014/round2/actor-input-compile-native-164"
hook_ok = run.("compiler.input-hook-compile-test", hook_root <> "/compile-only-controls.direct.bl", ["native-pattern-walk-collects-real-bindings-without-wildcards", "native-hook-names-exact-source-export-and-actual-key-bindings", "actual-native-actor-compilation-emits-check-without-loading-or-running-class"], 21)
kernel_ok = run.("compiler-kernel-values-test", root <> "/kernel.direct.bl", ["semantic-global-guard-preserves-literals-and-lexical-callbacks", "compiled-boot-kernel-never-borrows-its-source-function-or-data-values", "native-compilation-and-lowering-ignore-masked-source-kernel-values", "immutable-kernel-data-is-one-literal-and-preserves-compatibility-vars", "private-kernel-data-poison-cannot-change-native-reader-diag-or-compiler"], 124)
data_ok = true # The 90 data controls are included in kernel_ok (124 assertions).
false = :ets.member(:beam_lisp_vars, :bl_sdk_runtime_lease)
System.halt(if constants_ok and hook_ok and kernel_ok and data_ok and bl_util_ok, do: 0, else: 1)
