Application.load(:beam_lisp)
{:ok, deps} = :application.get_key(:beam_lisp, :applications)
Enum.each(deps, fn dep -> {:ok, _} = Application.ensure_all_started(dep) end)
:ok = BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
BeamLisp.AOT.boot()
false = :ets.member(:beam_lisp_vars, :bl_sdk_runtime_lease)
Code.eval_file("/home/user/tmp/product-online-20261014/round2/bootstrap-online-170/kernel-prelude.exs")
root = "/home/user/tmp/product-online-20261014/round2/bootstrap-recovery-177"
main = "/home/user/code/undefine/beam-lisp"
^main = File.cwd!()
System.put_env("BL_ROOT", main)
true = Code.prepend_path(main <> "/.bl/lib/beam_lisp-0.1.0/ebin")
BeamLisp.Env.add_search_path(main <> "/priv/build")
BeamLisp.AOTCache.reset_keys()
expected_key = BeamLisp.AOTCache.compiler_key()
sha = fn bytes -> Base.encode16(:crypto.hash(:sha256, bytes), case: :lower) end
inputs = :json.decode(File.read!(root <> "/inputs.json"))
true = sha.(File.read!(main <> "/scripts/regenerate-seed.bl")) == inputs["script_sha256"]
reused = :json.decode(File.read!(root <> "/reused-170-boot-inputs.json"))
Enum.each(reused["files"], fn row -> true = sha.(File.read!(row["path"])) == row["sha256"] end)
# Exact170 files are reusable only with fresh current physical source/key proof.
sources = Path.wildcard(main <> "/priv/boot/*.bl") ++ [main <> "/priv/std/multi.bl"]
source_rows = Map.new(sources, fn path ->
 content = BeamLisp.Loader.read_source(path)
 namespace = BeamLisp.Loader.declared_ns(content)
 {namespace, %{path: path, digest: :crypto.hash(:sha256, content), key: BeamLisp.AOTCache.key_for_source(path), closure: BeamLisp.AOT.ns_closure_hash(namespace, path)}}
end)
verified = Enum.map(Enum.filter(reused["files"], &String.ends_with?(&1["path"], ".beam")), fn row ->
 {:ok, {module, [{:attributes, attrs}]}} = :beam_lib.chunks(String.to_charlist(row["path"]), [:attributes])
 get = fn name -> BeamLisp.AOT.normalized_attribute(attrs, name) end
 namespace = get.(:bl_unit_namespace)
 source = Map.fetch!(source_rows, namespace)
 true = get.(:bl_compiler_key) == expected_key and get.(:bl_compiler_key) == source.key
 true = get.(:bl_source_hash) == source.closure
 true = get.(:bl_unit_source_digest) == source.digest
 {module, row["sha256"]}
end)
IO.inspect(%{boot_beams: length(verified), source_units: map_size(source_rows), compiler_key: expected_key}, label: "EXACT_170_BOOT_ARTIFACTS_CURRENT_PROVENANCE_VERIFIED")
# Real invalid-project controls run before any expensive host regeneration.
namespace = "regenerate-seed-project-test"
file = root <> "/project.direct.bl"
BeamLisp.Compiler.eval_string(File.read!(file), BeamLisp.Compiler.new_env(namespace), file)
crashes = Enum.flat_map(["physical-project-preflight-ignores-missing-or-foreign-cli-cache", "invalid-physical-project-refuses-before-any-host-or-build-output"], fn name ->
 try do BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(namespace, name), []); []
 rescue error -> IO.inspect({name, BeamLisp.ExInfo.ex_data(error), __STACKTRACE__}, label: "PROJECT_PREFLIGHT_CASE_CRASH", limit: 30); [name] end
end)
report = BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(namespace, "direct-report"), [])
IO.inspect(report, label: "PROJECT_PREFLIGHT_15_ASSERTIONS", limit: :infinity)
true = crashes == [] and report[:assertions] == 15 and report[:pass] == 15
false = :ets.member(:beam_lisp_vars, :bl_sdk_runtime_lease)
script = main <> "/scripts/regenerate-seed.bl"
BeamLisp.Compiler.eval_string(File.read!(script), BeamLisp.Compiler.new_env("tooling.regenerate-seed"), script)
IO.puts("COMPLETE_SOURCE_FLOOR_177_BUILD_CHECK_INSTALL_FINISHED")
System.halt(0)
