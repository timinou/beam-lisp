from pathlib import Path
import hashlib,json,re
root=Path(__file__).parent
accepted=Path('/home/user/tmp/product-online-20261014/round2/kernel-closures-174')
source_inputs=json.loads((accepted/'inputs.json').read_text())
units=['anf','lower','diag','reader','compiler']
log=Path('/home/user/tmp/product-online-20261014/round2/kernel-closures-174.log').read_text()
rows=re.findall(r'COMPONENT_NATIVE_ARTIFACT:\s*\{(BeamLisp\.[^,\s]+),\s*"([0-9a-f]{64})"\}',log)
seen={}
for name,digest in rows:
 module='Elixir.'+name
 assert module not in seen,('duplicate artifact',module)
 seen[module]=digest
sources=[];artifacts=[]
for unit in units:
 sources.append({'path':'priv/boot/'+unit+'.bl','sha256':source_inputs[unit+'.candidate.bl']})
 paths=sorted((accepted/unit).glob('*.beam'))
 expected=['Elixir.BeamLisp.Ns.'+unit.capitalize(),'Elixir.BeamLisp.Ns.Body.'+unit.capitalize()]
 if unit!='lower':expected+=['Elixir.BeamLisp.Ns.Init.'+unit.capitalize()]
 assert sorted(x.stem for x in paths)==sorted(expected),(unit,[x.name for x in paths])
 for path in paths:
  digest=hashlib.sha256(path.read_bytes()).hexdigest()
  assert seen[path.stem]==digest,(path,seen.get(path.stem),digest)
  artifacts.append({'module':path.stem,'path':str(path),'sha256':digest,'unit':unit})
assert len(artifacts)==len(seen)==14
receipt={'scope':'Exact174 artifacts accepted by175; trusted recovery compiler only, not current floor/runtime SDK authority','component_inputs_sha256':hashlib.sha256((accepted/'inputs.json').read_bytes()).hexdigest(),'sources':sources,'artifacts':artifacts,'unit_order':units,'module_count':len(artifacts)}
(root/'kernel-prelude-inputs.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('COMPLETE_174_KERNEL_INPUTS',len(artifacts))
