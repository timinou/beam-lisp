from pathlib import Path
import re,json,hashlib,subprocess
r=Path(__file__).parent;main=Path('/home/user/code/undefine/beam-lisp')
seed=(main/'priv/build/seed.bl').read_text();body=seed[seed.index('  [host-dir]\n  [{:module'):];body=body[:body.index('\n(defn ')]
hosts=re.findall(r':source \(Path/join host-dir "([^"]+)"\)',body);assert len(hosts)==70
paths={main/'priv/host'/leaf for leaf in hosts};assert len(paths)==65
paths.update((main/'priv/boot').glob('*.bl'));paths.add(main/'priv/std/multi.bl')
paths.update(main/leaf for leaf in ['priv/build/seed.bl','scripts/regenerate-seed.bl','scripts/install-seed.bl']);assert len(paths)==81
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rows=lambda ps:[{'path':str(p.relative_to(main)),'sha256':sha(p)} for p in sorted(ps)]
native=sorted((main/'priv/native').glob('*.so'));assert len(native)==10
extra=set((main/'priv/build').rglob('*.bl'))|{main/'priv/std/bl/cli.bl'};extra-=paths
commands=[r/f for f in ['probe.exs','command.sh','source-bootstrap-wrapper','kernel-prelude.exs','kernel-prelude-inputs.json','build-kernel-prelude-inputs.py']]
prelude=json.loads((r/'kernel-prelude-inputs.json').read_text())
for row in prelude['sources']:assert sha(main/row['path'])==row['sha256'],row['path']
receipt={'scope':'Final Main physical source freeze before official coherent170 generation; not a completed floor receipt','source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=main,text=True).strip(),'host_module_entries':len(hosts),'unique_pinned_host_files':65,'physical_source_count':len(paths),'sources':rows(paths),'additional_build_driver_source_count':len(extra),'additional_build_driver_sources':rows(extra),'native_asset_count':len(native),'native_assets':rows(native),'commands':[{'path':str(p),'sha256':sha(p)} for p in commands],'recovery_kernel_modules':prelude['module_count']}
(r/'physical-inputs.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if not isinstance(v,list)},indent=2))
