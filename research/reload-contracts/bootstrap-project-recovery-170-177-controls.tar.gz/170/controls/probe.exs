Application.load(:beam_lisp)
{:ok, deps} = :application.get_key(:beam_lisp, :applications)
Enum.each(deps, fn dep -> {:ok, _} = Application.ensure_all_started(dep) end)
:ok = BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
BeamLisp.AOT.boot()
false = :ets.member(:beam_lisp_vars, :bl_sdk_runtime_lease)
IO.inspect({BeamLisp.AOTCache.compiler_key(), BeamLisp.Tiers.priv_root()}, label: "COHERENT_157_BUILD_SUBSTRATE_NO_SDK_LEASE")
Code.eval_file("/home/user/tmp/product-online-20261014/round2/bootstrap-online-170/kernel-prelude.exs")
main = "/home/user/code/undefine/beam-lisp"
^main = File.cwd!()
file = main <> "/scripts/regenerate-seed.bl"
BeamLisp.Compiler.eval_string(File.read!(file), BeamLisp.Compiler.new_env("tooling.regenerate-seed"), file)
IO.puts("COMPLETE_SOURCE_FLOOR_170_BUILD_CHECK_INSTALL_FINISHED")
System.halt(0)
