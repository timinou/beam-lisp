Application.load(:beam_lisp)
{:ok, deps} = :application.get_key(:beam_lisp, :applications)
Enum.each(deps, fn dep -> {:ok, _} = Application.ensure_all_started(dep) end)
:ok = BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
BeamLisp.AOT.boot()
root = System.fetch_env!("BL_PROBE_ROOT")
# Reuse the exact Compiler artifacts produced and hashed by native106.
# This is a diagnostic overlay, never a coherent-floor acceptance.
for module <- [BeamLisp.Ns.Compiler, BeamLisp.Ns.Body.Compiler, BeamLisp.Ns.Init.Compiler] do
 artifact = "/home/user/tmp/product-online-20261014/round2/compiler-metadata-native-127/compiler-beams/" <> Atom.to_string(module) <> ".beam"
 {:module, ^module} = :code.load_binary(module, String.to_charlist(artifact), File.read!(artifact))
 IO.inspect({module, Base.encode16(:crypto.hash(:sha256, File.read!(artifact)), case: :lower)}, label: "REUSED_NATIVE_COMPILER")
end
for module <- [BeamLisp.SourceGraph, BeamLisp.NamespaceInterface] do
 artifact = "/home/user/tmp/product-online-20261014/round2/constructor-context-117/host/" <> Atom.to_string(module) <> ".beam"
 {:module, ^module} = :code.load_binary(module, String.to_charlist(artifact), File.read!(artifact))
end
for {module, directory} <- [{BeamLisp.BuildPlan, "constructor-context-119/host"}, {BeamLisp.AOT, "constructor-reader-native-123/host"}, {:"Elixir.BeamLisp.Ns.Reader-node", "constructor-reader-native-123/reader-beams"}, {:"Elixir.BeamLisp.Ns.Body.Reader-node", "constructor-reader-native-123/reader-beams"}, {BeamLisp.Ns.Reader, "constructor-reader-native-123/reader-beams"}, {BeamLisp.Ns.Body.Reader, "constructor-reader-native-123/reader-beams"}, {BeamLisp.Ns.Init.Reader, "constructor-reader-native-123/reader-beams"}] do
 artifact = "/home/user/tmp/product-online-20261014/round2/" <> directory <> "/" <> Atom.to_string(module) <> ".beam"
 {:module, ^module} = :code.load_binary(module, String.to_charlist(artifact), File.read!(artifact))
 IO.inspect({module, Base.encode16(:crypto.hash(:sha256, File.read!(artifact)), case: :lower)}, label: "EXACT_NATIVE_ARTIFACT")
end
saved = BeamLisp.Env.capture()
try do
 IO.inspect(BeamLisp.AOT.compile_host_file(root <> "/aot.bl", module: BeamLisp.AOT, output_dir: root <> "/host", load?: true), label: "FRESH_NATIVE_AOT")
after
 BeamLisp.Env.bind(saved)
end
fixtures = [{"recipe", "aot-constructor-recipe-test", ["interpreted-recipes-consume-finite-sequences-without-native-resources", "recipe-thunks-memoize-before-a-second-sequence-consumption", "private-recipe-shape-and-field-observations-refuse", "recipe-forgery-and-native-callbacks-never-gain-execution-authority", "finite-chain-and-cursor-materialization-never-invent-physical-cell-shapes", "nested-recipes-and-large-realized-prefixes-have-explicit-bounds", "finite-runtime-stack-guards-keep-the-selected-sorted-predicate-semantics", "finite-recipes-cannot-be-reinterpreted-as-ordinary-cons-tails", "opaque-observation-diagnostics-expose-only-fixed-native-target", "modeled-lazy-identity-matches-only-real-lazy-nodes", "source-core-reduce-uses-actual-compiled-wrapper-clauses", "native-fold-policy-is-closed-and-callback-output-remains-first-order", "compat-fold-never-invokes-a-mutable-runtime-predicate", "proved-capsule-vector-and-set-predicates-match-the-real-counterparts", "source-nil-guard-may-test-only-known-nontuple-recipe-identity", "real-source-into-uses-pure-predicates-and-the-normal-fold-path"], 74}, {"staging", "aot-sdk-constructor-staging-test", ["ordinary-compilation-does-not-have-sdk-constructor-authority", "ordinary-macro-kind-inspection-never-invokes-the-expander", "source-declaration-fold-uses-native-element-then-accumulator-order", "an-sdk-filename-with-different-source-refuses-before-effects", "cold-sdk-actor-source-never-borrows-mutable-core-or-initializes-provider", "canonical-native-namespace-is-not-invented-as-a-source-unit"], 27}, {"ordered", "aot-ordered-staging-test", ["ordered-sdk-values-and-unnamed-actions-have-no-effects-until-normal-replay", "ordinary-sdk-clause-extension-is-collected-without-registering-before-replay", "loaded-and-pending-arbitrary-action-macros-refuse-before-their-expander-can-run", "ordinary-clause-extension-uses-definition-owned-registration-from-a-foreign-namespace", "loaded-foreign-macros-in-deferred-declarations-refuse-before-expansion"], 35}, {"machine", "aot-constructor-machine-test", ["actual-compiler-namespace-definitions-preserve-clause-construction", "native-effects-opaque-input-and-runaway-recursion-refuse-without-execution", "interpreted-lambdas-and-patterns-use-the-actual-compiler-scaffold", "real-tick-contribution-interprets-actual-clause-and-private-helper-anf", "recursive-actual-anf-control-is-depth-bounded", "foreign-shadowed-global-never-becomes-a-core-primitive-by-name", "concatenation-refuses-combined-size-before-native-copying", "mapcat-refuses-an-excessive-prefix-before-retaining-or-flattening-it", "retained-closure-captures-consume-a-cumulative-byte-budget", "interpreted-patterns-preserve-exact-erlang-literal-and-empty-list-matching", "repeated-pattern-variables-use-exact-erlang-equality", "join-proves-separator-expansion-before-native-allocation", "dynamically-created-keywords-have-a-pre-intern-budget", "core-run-and-native-invoke-keep-their-real-abi-identities", "constructed-foreign-structs-refuse-before-native-protocol-dispatch", "pure-primitive-adapters-refuse-unsupported-arities-before-dispatch", "supported-nth-and-merge-adapters-preserve-native-results", "admitted-sequence-type-predicate-matches-actual-runtime", "eager-sequence-family-preserves-runtime-shapes-and-empty-results", "eager-take-and-both-drop-abis-preserve-negative-zero-and-positive-counts", "eager-sequence-operations-refuse-deferred-structs-before-thunks-can-run", "eager-text-materialization-is-bounded-before-grapheme-allocation", "list-star-preserves-the-real-variadic-rest-argument-abi", "form-metadata-adapters-preserve-exact-values-and-authored-metadata", "vary-meta-invokes-only-the-interpreted-callback", "metadata-and-spread-refuse-deferred-structs-without-effects", "list-star-bounds-spread-materialization-before-runtime-allocation", "metadata-and-list-star-native-adapters-have-exact-arities", "closed-numeric-predicates-match-the-selected-native-runtime", "gensym-retains-runtime-prefix-semantics-and-global-hygiene", "fresh-symbol-creation-has-a-per-interpretation-admission-bound", "numeric-predicate-adapters-refuse-wrong-arities", "numeric-predicates-never-dispatch-on-foreign-structs", "native-list-reversal-preserves-supported-arity-and-type-semantics", "native-list-reversal-refuses-deferred-thunks-before-any-effects", "private-process-counter-frame-is-disposed-on-success-refusal-and-native-error", "canonical-cpp-keyword-route-keeps-guarded-keyword-semantics", "seeded-apply-aliases-preserve-fixed-and-final-sequence-arguments", "implementation-walks-never-execute-a-live-core-reduced-predicate", "constructor-call-refuses-opaque-argument-iterators-before-normalizing", "readable-printer-is-bounded-first-order-data-only", "transientable-predicate-keeps-exact-canonical-data-semantics"], 547}]
ok = Enum.reduce(fixtures, true, fn {label, namespace, names, expected}, previous ->
 file = root <> "/" <> label <> ".direct.bl"
 try do
  if label == "machine" do
   :ok = BeamLisp.Env.push_load_path(root <> "/beam")
   BeamLisp.Loader.ensure_loaded("data.first-order")
   BeamLisp.Loader.ensure_loaded("proc.tick")
   for selected <- ["proc.server", "proc.tick"] do
    definitions = BeamLisp.Env.ns_defs(selected)
    bytes = :erlang.term_to_binary(definitions)
    true = byte_size(bytes) <= 8 * 1024 * 1024
    File.write!(root <> "/" <> selected <> ".env-anf.term", bytes)
   end
  end
  BeamLisp.Compiler.eval_string(File.read!(file), BeamLisp.Compiler.new_env(namespace), file)
  crashes = Enum.flat_map(names, fn name ->
   try do
    IO.inspect({label, name}, label: "NATIVE_CASE_START")
    BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(namespace, name), [])
    progress = BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(namespace, "direct-report"), [])
    IO.inspect({label, name, Map.take(progress, [:pass, :assertions])}, label: "NATIVE_CASE_PROGRESS")
    []
   rescue error ->
    IO.inspect({label, name, error, BeamLisp.ExInfo.ex_data(error), __STACKTRACE__}, label: "CASE_CRASH", limit: 40)
    [name]
   end
  end)
  report = BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(namespace, "direct-report"), [])
  IO.inspect({label, report, crashes}, label: "NATIVE_ASSERTIONS", limit: :infinity)
  previous and crashes == [] and report[:assertions] == expected and report[:assertions] == report[:pass]
 rescue error ->
  IO.inspect({label, error, BeamLisp.ExInfo.ex_data(error), __STACKTRACE__}, label: "FILE_CRASH", limit: 40)
  false
 end
end)
System.halt(if ok, do: 0, else: 1)
