Application.load(:beam_lisp)
{:ok, deps} = :application.get_key(:beam_lisp, :applications)
Enum.each(deps, fn dep -> {:ok, _} = Application.ensure_all_started(dep) end)
:ok = BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
BeamLisp.AOT.boot()
# Exact coherent94 machine, no host overlays or application startup.
try do
 BeamLisp.Loader.ensure_loaded("vm.owner")
 IO.puts("VM_OWNER_LOADED")
rescue error ->
 IO.inspect({error, BeamLisp.ExInfo.ex_data(error), __STACKTRACE__}, label: "ACTUAL_SOURCE_FRONTIER", limit: 25, printable_limit: 1500)
end
# Source metadata scan only: report inert non-list top-level expressions.
unmeta = fn unwrap, node ->
 case node do {:meta, inner, _} -> unwrap.(unwrap, inner); other -> other end
end
for ns <- ["core", "sugar", "reload.declaration", "reload.registration", "system.ir", "proc.server", "vm.owner"] do
 path = BeamLisp.Loader.source_path(ns)
 forms = BeamLisp.Reader.read_string(File.read!(path), path)
 Enum.with_index(forms) |> Enum.each(fn {node, index} ->
  case unmeta.(unmeta, node) do
   {:list, [{:symbol, _} | _]} -> :ok
   other -> IO.inspect({ns, index, other}, label: "NON_DECLARATION_SOURCE_FORM", limit: 5, printable_limit: 200)
  end
 end)
end
