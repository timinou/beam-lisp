Application.load(:beam_lisp)
{:ok, deps} = :application.get_key(:beam_lisp, :applications)
Enum.each(deps, fn dep -> {:ok, _} = Application.ensure_all_started(dep) end)
:ok = BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
BeamLisp.AOT.boot()
# Exact coherent94 machine, no host overlays or application startup.
{:ok, _} = :dbg.tracer(:process, {fn message, state ->
 case message do
  {:trace, _, :call, {BeamLisp.AOT, :constructor_unit!, [namespace]}} -> IO.inspect(namespace, label: "ACTUAL_CONSTRUCTOR_UNIT")
  _ -> :ok
 end
 state
end, nil})
:dbg.p(self(), :c)
:dbg.tpl(BeamLisp.AOT, :constructor_unit!, 1, [])
try do
 BeamLisp.Loader.ensure_loaded("build")
 IO.puts("BUILD_LOADED")
rescue error ->
 IO.inspect({error, BeamLisp.ExInfo.ex_data(error), __STACKTRACE__}, label: "ACTUAL_SOURCE_FRONTIER", limit: 25, printable_limit: 1500)
end

:dbg.stop_clear()
