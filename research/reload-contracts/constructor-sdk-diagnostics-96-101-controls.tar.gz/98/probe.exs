Application.load(:beam_lisp)
{:ok, deps} = :application.get_key(:beam_lisp, :applications)
Enum.each(deps, fn dep -> {:ok, _} = Application.ensure_all_started(dep) end)
:ok = BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
BeamLisp.AOT.boot()
# Exact coherent94 machine, no host overlays or application startup.
{:ok, _} = :dbg.tracer(:process, {fn message, state ->
 case message do
  {:trace, _, :call, {BeamLisp.AOT, :constructor_unit!, [namespace]}} -> IO.inspect(namespace, label: "ACTUAL_CONSTRUCTOR_UNIT")
  _ -> :ok
 end
 state
end, nil})
:dbg.p(self(), :c)
:dbg.tpl(BeamLisp.AOT, :constructor_unit!, 1, [])
try do
 path = BeamLisp.Loader.source_path("build")
 IO.inspect(BeamLisp.AOT.compile_source(File.read!(path), file: path, output_dir: System.fetch_env!("BL_PROBE_ROOT") <> "/output", "stage-sdk?": true), label: "ACTUAL_STAGED_UNIT", limit: 3)
 IO.puts("BUILD_STAGED")
rescue error ->
 IO.inspect({error, BeamLisp.ExInfo.ex_data(error), __STACKTRACE__}, label: "ACTUAL_SOURCE_FRONTIER", limit: 25, printable_limit: 1500)
end

:dbg.stop_clear()
