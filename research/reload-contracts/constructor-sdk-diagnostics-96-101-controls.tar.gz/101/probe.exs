Application.load(:beam_lisp)
{:ok, deps} = :application.get_key(:beam_lisp, :applications)
Enum.each(deps, fn dep -> {:ok, _} = Application.ensure_all_started(dep) end)
:ok = BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
BeamLisp.AOT.boot()
root = System.fetch_env!("BL_PROBE_ROOT")
artifact = "/home/user/tmp/product-online-20261014/round2/constructor-context-100/host/Elixir.BeamLisp.AOT.beam"
{:module, BeamLisp.AOT} = :code.load_binary(BeamLisp.AOT, String.to_charlist(artifact), File.read!(artifact))
true = :erlang.function_exported(BeamLisp.AOT, :stage_sdk_dependency!, 3)
ok = Enum.reduce(["build", "vm.owner"], true, fn namespace, previous ->
 try do
  path = BeamLisp.Loader.source_path(namespace)
  receipt = BeamLisp.Loader.without_initialization(fn ->
   BeamLisp.AOT.stage_sdk_dependency!(namespace, path, BeamLisp.Emit.module_for(namespace))
  end)
  IO.inspect({namespace, Map.take(receipt, [:namespace, :source_digest])}, label: "ACTUAL_RECURSIVE_STAGED_UNIT")
  previous
 rescue error ->
  IO.inspect({namespace, error, BeamLisp.ExInfo.ex_data(error), __STACKTRACE__}, label: "ACTUAL_SOURCE_FRONTIER", limit: 40, printable_limit: 1800)
  false
 end
end)
System.halt(if ok, do: 0, else: 1)
