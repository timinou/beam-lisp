# Native provisioning-mode regression. Does not accept ordinary app startup.
Application.load(:beam_lisp)
{:ok, dependencies} = :application.get_key(:beam_lisp, :applications)
Enum.each(dependencies, fn dep -> {:ok, _} = Application.ensure_all_started(dep) end)
IO.inspect(BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN")), label: "verified_floor")
BeamLisp.AOT.boot()
IO.puts("PROVISIONING_MODE_NO_INITIAL_SDK_LEASE")
BeamLisp.Loader.ensure_loaded("bl.cli")
runner = BeamLisp.Env.fetch_exact!("bl.cli", "run-argv")
{:ok, _root} = Supervisor.start_link([], strategy: :one_for_one, name: BeamLisp.Supervisor)
args = ["test" | ["test/bl/reload/namespace_rewrite_test.bl", "test/bl/reload/source_spans_test.bl", "test/bl/reload/source_facts_test.bl", "test/bl/reader_test.bl", "test/bl/reader_stream_test.bl", "test/bl/wave20_reader_pos_test.bl", "test/bl/eval_closed_reader_test.bl", "test/bl/source_graph_test.bl", "test/bl/reload/binding_test.bl", "test/bl/reload/static_generation_test.bl"]]
status = BeamLisp.Ns.Rt.invoke(runner, [BeamLisp.Vector.new(args)])
IO.inspect(status, label: "PROVISIONING_READER_STATUS")
System.halt(if status == 0, do: 0, else: 1)
