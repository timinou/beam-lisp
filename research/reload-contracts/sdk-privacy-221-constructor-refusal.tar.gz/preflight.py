#!/usr/bin/env python3
"""Read-only physical/provenance verification; reserve only the explicit launch slot."""
from pathlib import Path
import hashlib,json,os,subprocess,sys
HERE=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def inventory(root):
 rows=[]
 assert root.is_dir() and not root.is_symlink()
 for p in sorted(root.rglob('*')):
  assert not p.is_symlink(),'cache symlink refused'
  if p.is_dir():continue
  assert p.is_file() and p.stat().st_size>0,'cache non-regular or empty file refused'
  rows.append({'path':str(p.relative_to(root)),'sha256':sha(p),'bytes':p.stat().st_size})
 assert rows and len(rows)<=4096 and sum(r['bytes'] for r in rows)<=256*1024*1024
 return rows
def verify_rows(root,rows):
 for r in rows:
  p=root/r['path'];s=p.stat()
  if p.is_symlink():
   link=p.lstat();assert r.get('sourceAlias')=={'target':os.readlink(p),'device':link.st_dev,'inode':link.st_ino,'mtimeNs':link.st_mtime_ns} and r['path']=='research/js-actors/runtime.bl'
  else:assert 'sourceAlias' not in r
  assert (s.st_dev,s.st_ino,sha(p))==(r['device'],r['inode'],r['sha256']),'physical input drift: '+r['path']
def verify():
 x=json.loads((HERE/'component-inputs.json').read_text());main=Path(x['main'])
 for label in ['floorInputs','floorResult','floorLog']:assert sha(x[label])==x[label+'Sha256']
 assert len(x['seed'])==104
 if x.get('sdkSourceSuccessor'):
  from source_successor import project
  assert project(main,Path(x['floorInputs']),enabled=True)==x['sdkSourceSuccessor']
 for name,digest in x['files'].items():assert sha(HERE/name)==digest,'control drift: '+name
 verify_rows(main,x['sources']);verify_rows(main,x['nativeAssets']);verify_rows(main/'priv/bootstrap/seed',x['seed'])
 paths=subprocess.check_output(['git','ls-files','-z'],cwd=main).decode().split('\0')
 assert {p:sha(main/p) for p in paths if p and (main/p).is_file()}==x['trackedMain'],'tracked Main content/inventory drift'
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=main).decode().strip()==x['sourceCommit']
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=main),'Main must remain clean'
 actual={str(p.relative_to(main)) for p in (main/'priv').rglob('*') if p.is_file() and p.name.endswith(tuple(x['sourceExtensions']))}
 expected={r['path'] for r in x['sources'] if r['path'].startswith('priv/') and r['path'].endswith(tuple(x['sourceExtensions']))}
 assert actual==expected,'physical Source addition/removal'
 assert sha(main/'priv/bootstrap/seed/manifest.term')==x['manifestSha256']
 p=x['failedArtifactProvenance'];assert p['accepted'] is False
 for label in ['inputs','result','parent','log']:assert sha(p[label])==p[label+'Sha256'],'failed provenance drift'
 return x
if __name__=='__main__':
 x=verify()
 if sys.argv[1:]!=['--verify']:
  assert sys.argv[1:] in (['privacy'],['diagnostic'])
  mode=sys.argv[1]
  cache=inventory(HERE/'aot-cache') if mode=='diagnostic' else []
  if mode=='diagnostic':
   assert cache==x['initialCandidateCache'],'initial unaccepted artifacts changed'
   parent=json.loads(Path(x['privacyParent']).read_text())
   result=json.loads((HERE/'privacy-result.json').read_text())
   command=parent['command'];assert parent['exitCode']==0 and command[-1]==str(HERE/'privacy.sh') and parent['scriptSha256']==sha(HERE/'privacy.sh')
   logs=[v.removeprefix('--property=StandardOutput=append:') for v in command if v.startswith('--property=StandardOutput=append:')]
   assert len(logs)==1 and parent['logSha256']==sha(logs[0])
   assert Path(logs[0]).read_text().splitlines()[-1]=='DIAGNOSTIC_PRIVACY_79_FINISHED'
   assert result['accepted'] is True and result['mode']=='privacy' and result['benchmark'] is False and result['acceptanceRole']=='isolated-privacy-component-diagnostic'
   assert result['coreAssertions']==79 and result['assertions']['privacy']=={'assertions':79,'passed':79,'failed':0}
  else:assert not list((HERE/'privacy-cache').rglob('*')),'privacy component cache must begin empty'
  assert not list((HERE/'images'/mode/'lib/beam_lisp-0.1.0/ebin').iterdir()),'fresh kernel image required'
  with (HERE/(mode+'-started.json')).open('x') as f:json.dump({'mode':mode,'inputsSha256':sha(HERE/'component-inputs.json'),'cache':cache,'cacheAccepted':False,'pid':os.getpid()},f)
 print(json.dumps({'preflight':'PASS','VMsLaunched':0,'mode':sys.argv[1:],'cacheAccepted':False}))
