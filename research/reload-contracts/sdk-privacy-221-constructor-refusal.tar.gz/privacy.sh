#!/bin/bash
set -euo pipefail
unset BEAM_LISP_EBIN BEAM_LISP_PATH BL_ROOT BL_EBIN BL_BIN BL_BUILD_ID BL_BOOT_REEXECED BL_CONSTRUCTOR_METADATA_ROOT BL_KERNEL_SOURCE_UNDER_TEST BL_REGENERATE_SCRIPT_UNDER_TEST
python3 /home/user/tmp/product-online-20261014/round2/sdk-privacy-precompiled-diagnostic-221/preflight.py privacy
export BL_CACHE_COMPONENT_ROOT=/home/user/tmp/product-online-20261014/round2/sdk-privacy-precompiled-diagnostic-221
export BL_DIAGNOSTIC=/home/user/tmp/product-online-20261014/round2/sdk-privacy-precompiled-diagnostic-221/component.exs
export TMPDIR=/home/user/tmp/product-online-20261014/round2/sdk-privacy-precompiled-diagnostic-221/tmp
export BEAM_LISP_AOT_CACHE_DIR=/home/user/tmp/product-online-20261014/round2/sdk-privacy-precompiled-diagnostic-221/privacy-cache
export BL_DAEMON=off
export BL_AUTOBUILD=off
export BL_CACHE_COMPONENT_MODE=privacy
export BEAM_LISP_EBIN=/home/user/tmp/product-online-20261014/round2/sdk-privacy-precompiled-diagnostic-221/images/privacy/lib/beam_lisp-0.1.0/ebin
cd /home/user/code/undefine/beam-lisp
exec /home/user/tmp/product-online-20261014/round2/sdk-privacy-precompiled-diagnostic-221/source-wrapper
