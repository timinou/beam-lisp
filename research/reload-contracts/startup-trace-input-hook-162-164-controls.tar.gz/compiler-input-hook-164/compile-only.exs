# ROOT ONLY. Explicit candidate compile/emission, never SDK actor acceptance.
root=System.fetch_env!("BL_PROBE_ROOT")
manifest=:json.decode(File.read!(Path.join(root,"manifest.json")))
sha=fn path -> Base.encode16(:crypto.hash(:sha256,File.read!(path)),case: :lower) end
unless sha.(Path.join(System.fetch_env!("BL_ROOT"),"priv/boot/compiler.bl"))==manifest["compilerHook"]["baseSha256"],do: raise("Compiler base changed; rebase candidate")
Application.load(:beam_lisp)
{:ok,deps}=:application.get_key(:beam_lisp,:applications)
Enum.each(deps,fn dep -> {:ok,_}=Application.ensure_all_started(dep) end)
:ok=BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
BeamLisp.AOT.boot()
if :ets.member(:beam_lisp_vars,:bl_sdk_runtime_lease),do: raise("refuse changing Compiler with SDK runtime lease present")
source=Path.join(root,"compiler.candidate.bl")
unless sha.(source)==manifest["compilerHook"]["draftSha256"],do: raise("candidate changed")
saved=BeamLisp.Env.capture()
try do
 artifacts=BeamLisp.AOT.compile_file(source,output_dir: Path.join(root,"compiler"),mark_loaded?: true)
 true=:code.add_patha(String.to_charlist(Path.join(root,"compiler")))
 BeamLisp.AOTCache.run_init_modules(Enum.map(artifacts,&elem(&1,0)),Path.join(root,"compiler"))
 for {module,path} <- artifacts do
  {:ok,{^module,md5}}=:beam_lib.md5(String.to_charlist(path))
  unless apply(module,:module_info,[:md5])==md5,do: raise("new Compiler artifact is not loaded")
  IO.inspect({module,sha.(path)},label: "COMPILE_ONLY_NATIVE_COMPILER")
 end
after BeamLisp.Env.bind(saved) end
fixture=manifest["compileOnly"]; namespace=fixture["namespace"];file=Path.join(root,fixture["direct"])
unless sha.(file)==fixture["directSha256"],do: raise("compile controls changed")
BeamLisp.Compiler.eval_string(File.read!(file),BeamLisp.Compiler.new_env(namespace),file)
crashes=Enum.flat_map(fixture["functions"],fn name ->
 try do BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(namespace,name),[]);[]
 rescue error -> IO.inspect({name,error,BeamLisp.ExInfo.ex_data(error),__STACKTRACE__},label: "COMPILE_ONLY_CASE_CRASH",limit: 30);[name]
 catch kind,reason -> IO.inspect({name,kind,reason},label: "COMPILE_ONLY_CASE_THROW",limit: 30);[name]
 end
end)
report=BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(namespace,"direct-report"),[])
IO.inspect({report,crashes},label: "COMPILE_ONLY_ASSERTIONS",limit: :infinity)
if :ets.member(:beam_lisp_vars,:bl_sdk_runtime_lease),do: raise("compile-only unexpectedly admitted an SDK actor")
System.halt(if crashes==[] and report[:assertions]==21 and report[:pass]==21,do: 0,else: 1)
