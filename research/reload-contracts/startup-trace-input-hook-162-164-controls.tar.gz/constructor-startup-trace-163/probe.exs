root = System.fetch_env!("BL_PROBE_ROOT")
true = Code.ensure_loaded?(BeamLisp.AOT)
{BeamLisp.AOT, object, path} = :code.get_object_code(BeamLisp.AOT)
manifest = BeamLisp.Bootstrap.manifest()
expected = manifest["modules"]["Elixir.BeamLisp.AOT.beam"]
^expected = Base.encode16(:crypto.hash(:sha256, object), case: :lower)
IO.inspect({path, expected}, label: "UNCHANGED_MANIFEST_AOT_TRACE_TARGET")
nil = Process.whereis(BeamLisp.Env)
known_fields = [:op, :val, :name, :ns, :lookup, :mod, :fun, :args, :fn, :body, :init, :test, :then, :else, :stmts, :elems, :pairs, :head, :tail, :fields, :subj, :clauses, :guard, :pats, :bif]
shape = fn node ->
 kind = cond do
  is_nil(node) -> :nil
  is_map(node) -> :map
  is_list(node) -> :list
  is_tuple(node) -> :tuple
  is_binary(node) -> :binary
  is_atom(node) -> :atom
  is_integer(node) -> :integer
  is_float(node) -> :float
  is_function(node) -> :function
  is_reference(node) -> :reference
  is_pid(node) -> :pid
  true -> :other
 end
 result = %{kind: kind, keys: if(is_map(node), do: Enum.filter(known_fields, &Map.has_key?(node, &1)), else: [])}
 if is_tuple(node), do: Map.put(result, :tuple_arity, tuple_size(node)), else: result
end
tracer = spawn(fn ->
 loop = fn loop, recent, invalid, events ->
  receive do
   {:trace, pid, :call, {BeamLisp.AOT, :constructor_interpret, 3}, node} ->
    summary = %{node: shape.(node), recent_source_names: recent}
    if length(invalid) < 4, do: IO.inspect(summary, label: "ACTUAL_INVALID_CONSTRUCTOR_NODE", limit: :infinity)
    loop.(loop, recent, Enum.take([summary | invalid], 4), events + 1)
   {:trace, _pid, :call, {BeamLisp.AOT, _, _}, names} ->
    loop.(loop, Enum.take([names | recent], 16), invalid, events + 1)
   {:snapshot, from, ref} ->
    send(from, {ref, %{recent_source_names: recent, invalid_nodes: Enum.reverse(invalid), events: events}})
    loop.(loop, recent, invalid, events)
   {:reset, from, ref} ->
    send(from, {ref, :reset})
    loop.(loop, [], [], 0)
   :stop -> :ok
   unknown ->
    if is_tuple(unknown) and tuple_size(unknown) > 0 and elem(unknown, 0) in [:trace, :trace_ts] do
     safe = %{tuple_arity: tuple_size(unknown), event: if(tuple_size(unknown) > 2 and is_atom(elem(unknown, 2)), do: elem(unknown, 2), else: :unknown)}
     if events < 4, do: IO.inspect(safe, label: "UNRECOGNIZED_TRACE_SHAPE")
     loop.(loop, recent, invalid, events + 1)
    else
     loop.(loop, recent, invalid, events)
    end
  end
 end
 loop.(loop, [], [], 0)
end)
invalid = [
 {[ :"$1", :_, :_ ], [{:not, {:is_map, :"$1"}}], [{:message, :"$1"}]},
 {[ :"$1", :_, :_ ], [{:is_map, :"$1"}, {:not, {:is_map_key, :op, :"$1"}}], [{:message, :"$1"}]},
 {[ :"$1", :_, :_ ], [{:is_map, :"$1"}, {:is_map_key, :op, :"$1"}, {:"==", {:map_get, :op, :"$1"}, nil}], [{:message, :"$1"}]}
]
1 = :erlang.trace_pattern({BeamLisp.AOT, :constructor_interpret, 3}, invalid, [:local])
for {fun, arity, tag} <- [{:constructor_compile_binding!, 2, :physical_binding}, {:staged_macro_lookup, 2, :macro_lookup}, {:constructor_unit!, 1, :source_unit}] do
 head = if arity == 1, do: [:"$1"], else: [:"$1", :"$2"]
 guards = if arity == 1, do: [{:is_binary, :"$1"}, {:"=<", {:byte_size, :"$1"}, 256}], else: [{:is_binary, :"$1"}, {:"=<", {:byte_size, :"$1"}, 256}, {:is_binary, :"$2"}, {:"=<", {:byte_size, :"$2"}, 256}]
 message = if arity == 1, do: {{tag, :"$1"}}, else: {{tag, :"$1", :"$2"}}
 1 = :erlang.trace_pattern({BeamLisp.AOT, fun, arity}, [{head, guards, [{:message, message}]}], [:local])
end
# OTP application startup is spawned by the pre-existing controller, not by
# launcher self. Cover a bounded existing-process snapshot and its descendants;
# function filters remain restricted to the four exact AOT methods above.
pids = Process.list()
true = length(pids) <= 4096
for pid <- pids, pid != tracer do
 try do :erlang.trace(pid, true, [:call, :arity, :set_on_spawn, {:tracer, tracer}]) rescue ArgumentError -> :ok end
end
IO.inspect(length(pids), label: "BOUNDED_VM_TRACE_PID_COUNT")
snapshot = fn ->
 delivery = :erlang.trace_delivered(:all)
 receive do {:trace_delivered, :all, ^delivery} -> :ok after 5000 -> raise "trace delivery timeout" end
 ref = make_ref()
 send(tracer, {:snapshot, self(), ref})
 receive do {^ref, report} -> report after 5000 -> raise "trace snapshot timeout" end
end
# Deliberately invalid entry proves the pattern and tracer before paying for
# startup. Runtime/counter preconditions may refuse before ANF dispatch; entry
# tracing itself must still observe this nil first argument. No Env is started.
try do BeamLisp.AOT.constructor_interpret(nil, %{}, %{}) rescue _ -> :ok end
control = snapshot.()
true = control.events > 0 and length(control.invalid_nodes) > 0
IO.inspect(control, label: "INVALID_ENTRY_TRACE_CONTROL_PASS")
nil = Process.whereis(BeamLisp.Env)
ref = make_ref()
send(tracer, {:reset, self(), ref})
receive do {^ref, :reset} -> :ok after 5000 -> raise "trace reset timeout" end
try do
 BeamLisp.Launcher.main(["run", "/home/user/tmp/product-online-20261014/round2/ordinary-native-159/receipt.bl"])
rescue error ->
 data = BeamLisp.ExInfo.ex_data(error)
 for mfa <- [{BeamLisp.AOT, :constructor_interpret, 3}, {BeamLisp.AOT, :constructor_compile_binding!, 2}, {BeamLisp.AOT, :staged_macro_lookup, 2}, {BeamLisp.AOT, :constructor_unit!, 1}] do
  IO.inspect({mfa, :erlang.trace_info(mfa, :traced)}, label: "POST_STARTUP_TRACE_PATTERN_STATUS")
 end
 IO.inspect(data, label: "UNCHANGED_STARTUP_EXACT_REFUSAL", limit: :infinity)
 IO.inspect(__STACKTRACE__, label: "UNCHANGED_STARTUP_NATIVE_STACK", limit: 100)
 delivery = :erlang.trace_delivered(:all)
 receive do {:trace_delivered, :all, ^delivery} -> :ok after 5000 -> :ok end
 ref = make_ref()
 send(tracer, {:snapshot, self(), ref})
 receive do {^ref, snapshot} -> IO.inspect(snapshot, label: "BOUNDED_CONSTRUCTOR_TRACE", limit: :infinity) after 5000 -> IO.puts("TRACE_SNAPSHOT_TIMEOUT") end
 System.halt(if is_map(data) and data[:kind] == :"constructor-machine-refused", do: 0, else: 1)
end
