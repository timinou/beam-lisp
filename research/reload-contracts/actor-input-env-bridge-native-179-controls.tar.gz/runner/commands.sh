#!/usr/bin/env bash
set -euo pipefail
probe_root=/home/user/tmp/product-online-20261014/round2/actor-input-env-bridge-179d
export BL_PROBE_ROOT="$probe_root" TMPDIR="$probe_root/tmp" BEAM_LISP_AOT_CACHE_DIR="$probe_root/aot-cache"
unset BEAM_LISP_EBIN BEAM_LISP_PATH BL_ROOT BL_EBIN BL_BIN BL_BUILD_ID BL_BOOT_REEXECED
export BL_DIAGNOSTIC="$probe_root/probe.exs"
"$probe_root/source-component-wrapper"
