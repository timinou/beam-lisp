# ROOT ONLY. Exact179b native artifact replay; no production/runtime SDK claim.
root=System.fetch_env!("BL_PROBE_ROOT");main=System.fetch_env!("BL_ROOT")
sha=fn path -> Base.encode16(:crypto.hash(:sha256,File.read!(path)),case: :lower) end
inputs=:json.decode(File.read!(Path.join(root,"inputs.json")))
for {relative,row} <- inputs["inputs"] do
 unless sha.(Path.join(main,relative))==row["baseSha256"],do: raise("Main base changed")
 unless sha.(Path.join(root,row["candidate"]))==row["candidateSha256"],do: raise("candidate changed")
end
for row <- inputs["replayArtifacts"] do
 unless sha.(Path.join(root,row["file"]))==row["sha256"],do: raise("179b native artifact changed")
end
Application.load(:beam_lisp)
{:ok,deps}=:application.get_key(:beam_lisp,:applications)
Enum.each(deps,fn dep -> {:ok,_}=Application.ensure_all_started(dep) end)
:ok=BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
BeamLisp.AOT.boot()
false=:ets.member(:beam_lisp_vars,:bl_sdk_runtime_lease)
IO.inspect({main,BeamLisp.AOTCache.compiler_key(),sha.(Path.join(main,"priv/bootstrap/seed/manifest.term"))},label: "ACTUAL_COMPONENT_BASE")
load = fn relative,module ->
 path=Path.join(root,relative)
 {:module,^module}=:code.load_binary(module,String.to_charlist(path),File.read!(path))
 {:ok,{^module,md5}}=:beam_lib.md5(String.to_charlist(path));^md5=apply(module,:module_info,[:md5])
 IO.inspect({module,sha.(path),Base.encode16(md5,case: :lower)},label: "EXACT_179B_NATIVE_REPLAY")
end
load.("host/Elixir.BeamLisp.Env.beam",BeamLisp.Env)
{:ok,{BeamLisp.Env,[imports: imports]}}=:beam_lib.chunks(File.read!(Path.join(root,"host/Elixir.BeamLisp.Env.beam")),[:imports])
false=Enum.any?(imports,fn {module,_,_} -> module==BeamLisp.Ns.Proc.Contract end)
IO.puts("NATIVE_ENV_HAS_NO_CONTRACT_IMPORT")
Code.eval_file(Path.join(root,"native-negative-controls.exs"))
true=:code.add_patha(String.to_charlist(Path.join(root,"compiler")))
for {file,module} <- [{"Elixir.BeamLisp.Ns.Body.Compiler.beam",BeamLisp.Ns.Body.Compiler},
 {"Elixir.BeamLisp.Ns.Compiler.beam",BeamLisp.Ns.Compiler},
 {"Elixir.BeamLisp.Ns.Init.Compiler.beam",BeamLisp.Ns.Init.Compiler}] do load.("compiler/"<>file,module) end
BeamLisp.AOTCache.run_init_modules([BeamLisp.Ns.Compiler,BeamLisp.Ns.Body.Compiler,BeamLisp.Ns.Init.Compiler],Path.join(root,"compiler"))
# Let both ordinary fixture declarations load Main dependencies first. Then
# replay the actual pure candidate helper LAST, with no readiness shortcut.
for fixture <- inputs["componentFixtures"] do
 file=Path.join(root,fixture["direct"])
 unless sha.(file)==fixture["directSha256"],do: raise("direct fixture changed")
 BeamLisp.Compiler.eval_string(File.read!(file),BeamLisp.Compiler.new_env(fixture["namespace"]),file)
end
# Alias-only require is lazy. Genuinely initialize its Main provider before
# the temporary pure Source override; never mark readiness without its init.
BeamLisp.Loader.ensure_loaded("reload.server-entry")
true=BeamLisp.Env.loaded_ns?("reload.server-entry")
true=BeamLisp.Env.ns_ready?("reload.server-entry")
helper=Path.join(root,inputs["inputs"]["priv/std/reload/server-entry.bl"]["candidate"])
BeamLisp.Compiler.eval_string(File.read!(helper),BeamLisp.Compiler.new_env("reload.server-entry"),helper)
results=Enum.map(inputs["componentFixtures"],fn fixture ->
 crashes=Enum.flat_map(fixture["functions"],fn name ->
  try do BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(fixture["namespace"],name),[]);[]
  rescue error -> IO.inspect({name,error,BeamLisp.ExInfo.ex_data(error),__STACKTRACE__},label: "INPUT_BRIDGE_CASE_CRASH",limit: 35);[name]
  catch kind,reason -> IO.inspect({name,kind,reason},label: "INPUT_BRIDGE_CASE_THROW",limit: 35);[name]
  end
 end)
 report=BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(fixture["namespace"],"direct-report"),[])
 IO.inspect({fixture["namespace"],report,crashes},label: "INPUT_BRIDGE_COMPONENT_ASSERTIONS",limit: :infinity)
 crashes==[] and report[:pass]==fixture["expectedAssertions"] and report[:assertions]==fixture["expectedAssertions"]
end)
false=:ets.member(:beam_lisp_vars,:bl_sdk_runtime_lease)
System.halt(if Enum.all?(results),do: 0,else: 1)
