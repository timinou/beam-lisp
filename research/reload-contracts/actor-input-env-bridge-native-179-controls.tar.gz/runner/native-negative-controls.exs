# ROOT ONLY, appended inside the same component VM AFTER candidate Env load.
# No SDK lease/provenance, sealed graph, native actor or adoption is fabricated.
# The generic proof below exercises EXISTING trusted native lease APIs solely
# as a negative: full code admission still cannot impersonate server entry.
bridge_checks = :counters.new(1, [])
assert_bridge = fn truth, label ->
  unless truth, do: raise("Env input bridge assertion failed: " <> label)
  :counters.add(bridge_checks, 1, 1)
end
refusal = fn thunk ->
  try do
    thunk.()
    :accepted
  rescue
    error in ErlangError -> error.original
  end
end
saved_context = BeamLisp.Env.capture()
contract_before = :code.is_loaded(BeamLisp.Ns.Proc.Contract)
assert_bridge.(function_exported?(BeamLisp.Env, :check_server_inputs!, 3), "actual native export")
assert_bridge.(Process.get(:bl_generation) == nil, "genuinely unmanaged initial context")
assert_bridge.(Process.get(:bl_server_execution_owner) == nil, "no invented server owner")
try do
  assert_bridge.(BeamLisp.Env.check_server_inputs!(BeamLisp.Env, nil, %{}) == :ok, "unmanaged no-op")
  # Native fixture metadata only. This is NOT a prepared/sealed graph and is
  # never passed to Server.start or any authority that adopts managed actors.
  graph = %{ :scope => BeamLisp.Env.env_id(), :modules => BeamLisp.Vector.new([BeamLisp.Env]),
             :"server-classes" => BeamLisp.Set.new([])}
  BeamLisp.Env.bind(Map.put(saved_context, :generation, graph))
  assert_bridge.(refusal.(fn -> BeamLisp.Env.check_server_inputs!(BeamLisp.Env, nil, %{}) end) == :unadmitted_actor_input_check,
                 "copied public graph refuses")
  ticket = BeamLisp.Env.retain_code!([BeamLisp.Env])
  try do
    assert_bridge.(BeamLisp.Env.code_lease_active?(ticket), "real retained ticket")
    assert_bridge.(refusal.(fn -> BeamLisp.Env.check_server_inputs!(BeamLisp.Env, nil, %{}) end) == :unadmitted_actor_input_check,
                   "retention alone refuses")
    BeamLisp.Env.with_owned_code_execution(ticket, fn ->
      BeamLisp.Env.with_owned_generation_execution(fn ->
        assert_bridge.(BeamLisp.Env.executing_generation?(graph), "actual existing generic native execution proof")
        assert_bridge.(refusal.(fn -> BeamLisp.Env.check_server_inputs!(BeamLisp.Env, nil, %{}) end) == :unadmitted_actor_input_check,
                       "generic proof still lacks server extent")
        BeamLisp.Env.bind(saved_context)
        assert_bridge.(refusal.(fn -> BeamLisp.Env.check_server_inputs!(BeamLisp.Env, nil, %{}) end) == :execution_origin_context_mismatch,
                       "nil public G cannot erase admitted origin")
      end)
    end)
  after
    BeamLisp.Env.release_code!(ticket)
  end
  assert_bridge.(:code.is_loaded(BeamLisp.Ns.Proc.Contract) == contract_before, "no contract load or lookup on negative/SDK-independent paths")
after
  BeamLisp.Env.bind(saved_context)
end
IO.inspect(%{assertions: :counters.get(bridge_checks, 1), expected: 11, scope: :native_negative_entry_only}, label: "NATIVE_INPUT_BRIDGE_NEGATIVES")
unless :counters.get(bridge_checks, 1) == 11, do: raise("Env bridge count mismatch")
