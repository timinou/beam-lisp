Application.load(:beam_lisp)
{:ok, deps} = :application.get_key(:beam_lisp, :applications)
Enum.each(deps, fn dep -> {:ok, _} = Application.ensure_all_started(dep) end)
:ok = BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
BeamLisp.AOT.boot()
root = System.fetch_env!("BL_PROBE_ROOT")
artifact = "/home/user/tmp/product-online-20261014/round2/constructor-context-102/host/Elixir.BeamLisp.AOT.beam"
{:module, BeamLisp.AOT} = :code.load_binary(BeamLisp.AOT, String.to_charlist(artifact), File.read!(artifact))
true = :erlang.function_exported(BeamLisp.AOT, :stage_sdk_dependency!, 3)
file = root <> "/pinned.direct.bl"
BeamLisp.Compiler.eval_string(File.read!(file), BeamLisp.Compiler.new_env("aot-pinned-declaration-test"), file)
crashes = Enum.flat_map(["executable-nested-host-declarations-refuse-before-source-effects", "genuine-host-forward-calls-and-quoted-declaration-data-remain-valid", "constructor-clause-and-form-helpers-are-actual-native-module-exports"], fn name ->
 try do
  BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!("aot-pinned-declaration-test", name), [])
  []
 rescue error ->
  IO.inspect({name, error, BeamLisp.ExInfo.ex_data(error), __STACKTRACE__}, label: "NATIVE_CASE_CRASH", limit: 30)
  [name]
 end
end)
report = BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!("aot-pinned-declaration-test", "direct-report"), [])
IO.inspect({report, crashes}, label: "NATIVE_ASSERTIONS", limit: :infinity, printable_limit: :infinity)
System.halt(if crashes == [] and report[:assertions] == 18 and report[:pass] == 18, do: 0, else: 1)
