Application.load(:beam_lisp)
{:ok, dependencies} = :application.get_key(:beam_lisp, :applications)
Enum.each(dependencies, fn dep -> {:ok, _} = Application.ensure_all_started(dep) end)
IO.inspect(BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN")), label: "verified_floor")
BeamLisp.AOT.boot()
root=System.fetch_env!("BL_PROBE_ROOT")
Enum.each(["baseline", "candidate"], fn name ->
 BeamLisp.AOT.compile_source(File.read!(root<>"/"<>name<>".bl"),file: root<>"/"<>name<>".bl",output_dir: root<>"/output")
end)
baseline=BeamLisp.Env.fetch_exact!("prototype.symbol-baseline","executable-symbols")
candidate=BeamLisp.Env.fetch_exact!("prototype.symbol-candidate","executable-symbols")
inputs=Jason.decode!(File.read!(root<>"/inputs.json"))
results=Enum.map(inputs,fn input ->
 forms=BeamLisp.Reader.read_string(File.read!(input["file"]),input["file"])
 args=tl(forms)
 samples=Enum.map([{:baseline,baseline},{:candidate,candidate},{:candidate,candidate},{:baseline,baseline}],fn {name,fun} ->
   {micros,value}=:timer.tc(fn -> Enum.flat_map(args,fn form -> Enum.to_list(BeamLisp.Ns.Rt.invoke(fun,[form])) end) end)
   hash=Base.encode16(:crypto.hash(:sha256,:erlang.term_to_binary(value,[:deterministic])),case: :lower)
   row=%{variant: name, microseconds: micros, output_sha256: hash}
   IO.inspect(row,label: "FINITE_SYMBOL_ABBA")
   row
 end)
 unless length(Enum.uniq(Enum.map(samples,& &1.output_sha256)))==1, do: raise("different reference results")
 Map.put(input,"samples",samples)
end)
File.write!(root<>"/result.json",Jason.encode!(%{scope: "executable-symbol source-only ABBA; no whole-plan or startup claim",inputs: results},pretty: true))
IO.puts("FINITE_SYMBOL_ABBA_PASS")
