Application.load(:beam_lisp)
{:ok, dependencies} = :application.get_key(:beam_lisp, :applications)
Enum.each(dependencies, fn dep -> {:ok, _} = Application.ensure_all_started(dep) end)
:ok = BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
BeamLisp.AOT.boot()
root = System.fetch_env!("BL_PROBE_ROOT")
base = Path.dirname(root)
for module <- [BeamLisp.Ns.Compiler, BeamLisp.Ns.Body.Compiler, BeamLisp.Ns.Init.Compiler] do
 path = base <> "/constructor-context-106/compiler-beams/" <> Atom.to_string(module) <> ".beam"
 {:module, ^module} = :code.load_binary(module, String.to_charlist(path), File.read!(path))
end
for {module, directory} <- [{BeamLisp.SourceGraph, "constructor-context-117/host"}, {BeamLisp.NamespaceInterface, "constructor-context-117/host"}, {BeamLisp.BuildPlan, "constructor-context-119/host"}, {BeamLisp.AOT, "constructor-reader-native-123/host"}] do
 path = base <> "/" <> directory <> "/" <> Atom.to_string(module) <> ".beam"
 {:module, ^module} = :code.load_binary(module, String.to_charlist(path), File.read!(path))
end
for {label, expression} <- [
 {"literal", "(meta ^{:key 42} [:li 1])"},
 {"fn-row", "(let [row ((fn [t] ^{:key (:id t)} [:li (:id t)]) {:id 7})] [(meta row) row])"},
 {"map-rows", "(mapv (fn [r] (meta r)) (map (fn [t] ^{:key (:id t)} [:li (:id t)]) [{:id 1} {:id 2}]))"},
 {"for-rows", "(mapv (fn [r] (meta r)) (for [t [{:slug \"a\"} {:slug \"b\"}]] ^{:key (:slug t)} [:li (:slug t)]))"},
 {"quote", "(quote ^{:key (:id t)} [:li (:id t)])"}
] do
 for {variant, directory} <- [{:new, base <> "/constructor-context-106/compiler-beams"}, {:old, base <> "/ordinary-source-95/build"}] do
  for module <- [BeamLisp.Ns.Compiler, BeamLisp.Ns.Body.Compiler, BeamLisp.Ns.Init.Compiler] do
   :code.soft_purge(module)
   path = directory <> "/" <> Atom.to_string(module) <> ".beam"
   {:module, ^module} = :code.load_binary(module, String.to_charlist(path), File.read!(path))
  end
  try do
   value = BeamLisp.Compiler.eval_string(expression, BeamLisp.Compiler.new_env("metadata-diagnostic"), "metadata-diagnostic.bl")
   IO.inspect({variant, label, value}, label: "ACTUAL_METADATA_VALUE", limit: :infinity)
  rescue error -> IO.inspect({variant,label,error,BeamLisp.ExInfo.ex_data(error)}, label: "METADATA_ERROR", limit: 30)
  end
 end
end
