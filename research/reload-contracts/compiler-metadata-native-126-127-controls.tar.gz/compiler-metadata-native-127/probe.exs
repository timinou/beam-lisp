Application.load(:beam_lisp)
{:ok, dependencies} = :application.get_key(:beam_lisp, :applications)
Enum.each(dependencies, fn dep -> {:ok, _} = Application.ensure_all_started(dep) end)
:ok = BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
BeamLisp.AOT.boot()
root = System.fetch_env!("BL_PROBE_ROOT")
base = Path.dirname(root)
for module <- [BeamLisp.Ns.Compiler, BeamLisp.Ns.Body.Compiler, BeamLisp.Ns.Init.Compiler] do
 path = base <> "/constructor-context-106/compiler-beams/" <> Atom.to_string(module) <> ".beam"
 {:module, ^module} = :code.load_binary(module, String.to_charlist(path), File.read!(path))
end
for {module, directory} <- [{BeamLisp.SourceGraph, "constructor-context-117/host"}, {BeamLisp.NamespaceInterface, "constructor-context-117/host"}, {BeamLisp.BuildPlan, "constructor-context-119/host"}, {BeamLisp.AOT, "constructor-reader-native-123/host"}] do
 path = base <> "/" <> directory <> "/" <> Atom.to_string(module) <> ".beam"
 {:module, ^module} = :code.load_binary(module, String.to_charlist(path), File.read!(path))
end
saved = BeamLisp.Env.capture()
try do
 IO.inspect(BeamLisp.AOT.compile_file(root <> "/compiler.bl", output_dir: root <> "/compiler-beams"), label: "FRESH_NATIVE_COMPILER")
after
 BeamLisp.Env.bind(saved)
end
fixtures = [{"reader-meta", "reader-meta.test", ["literal-key-survives", "expression-key-evaluates", "for-rows-are-keyed", "map-preserves-key", "meta-invisible-to-equality", "no-meta-is-nil", "only-vectors-carry-runtime-meta", "threading-still-works", "reader-offsets-are-not-author-metadata"]}, {"codec", "compiler-metadata-datum-test", ["vector-author-metadata-is-data-at-the-macro-boundary", "author-data-and-reader-position-remain-separate", "plain-runtime-metadata-is-stable-on-repeated-datum-roundtrips", "macro-metadata-expressions-rebuild-executable-syntax", "explicit-metadata-wrappers-and-quoted-data-roundtrip"]}]
ok = Enum.reduce(fixtures, true, fn {label, namespace, names}, previous ->
 file = root <> "/" <> label <> ".direct.bl"
 BeamLisp.Compiler.eval_string(File.read!(file), BeamLisp.Compiler.new_env(namespace), file)
 crashes = Enum.flat_map(names, fn name ->
  try do
   BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(namespace, name), [])
   []
  rescue error ->
   IO.inspect({label, name, error, BeamLisp.ExInfo.ex_data(error), __STACKTRACE__}, label: "CASE_CRASH", limit: 35)
   [name]
  end
 end)
 report = BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(namespace, "direct-report"), [])
 IO.inspect({label, report, crashes}, label: "METADATA_ASSERTIONS", limit: :infinity)
 previous and crashes == [] and report[:assertions] == report[:pass]
end)
System.halt(if ok, do: 0, else: 1)
