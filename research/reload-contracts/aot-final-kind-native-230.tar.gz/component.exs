# Actual installed native floor plus ordinary public compiler fixture evaluation.
home=System.fetch_env!("BL_FAST_ROOT")
main=System.fetch_env!("BL_ROOT")
mode=System.fetch_env!("BL_FAST_MODE")
inputs=:json.decode(File.read!(home<>"/component-inputs.json"))
sha=fn p->Base.encode16(:crypto.hash(:sha256,File.read!(p)),case: :lower) end
Process.put(:component_native_checks,0)
check=fn label,value->
 if value==true,do: Process.put(:component_native_checks,Process.get(:component_native_checks)+1),else: throw({:component_check_failed,label})
end
persist=fn value->
 File.write!(home<>"/"<>mode<>"-progress.json.tmp",:json.encode(value))
 File.rename!(home<>"/"<>mode<>"-progress.json.tmp",home<>"/"<>mode<>"-progress.json")
end
safe_return=fn value->
 case value do
  :ok->%{tag: "ok"}
  {:staged,:compiler_key_mismatch}->%{tag: "staged",reason: "compiler_key_mismatch"}
  {:error,{:already_loaded,:beam_lisp}}->%{tag: "error",reason: "already_loaded_beam_lisp"}
  {:ok,items} when is_list(items)->%{tag: "ok",listCount: length(items)}
  {output,exit_code} when is_binary(output) and is_integer(exit_code)->%{tag: "system_cmd",exitCode: exit_code}
  {:error,_}->%{tag: "error",detail: "redacted"}
  value when is_tuple(value)->%{tag: "unclassified_tuple",arity: tuple_size(value)}
  _->%{tag: "unclassified",detail: "redacted"}
 end
end
breadcrumb=fn stage,status->
 row=%{stage: stage,status: status}
 rows=Process.get(:bootstrap_stages,[])++[row]
 Process.put(:bootstrap_stages,rows)
 File.write!(home<>"/probe-bootstrap-progress.json.tmp",:json.encode(%{stages: rows,currentFloorAccepted: false}))
 File.rename!(home<>"/probe-bootstrap-progress.json.tmp",home<>"/probe-bootstrap-progress.json")
 IO.inspect(row,label: "ACTUAL_COMPONENT_BOOTSTRAP_STAGE")
end
observe=fn ->%{bootstrapStages: Process.get(:bootstrap_stages,[]),bootstrapInstallObservation: Process.get(:bootstrap_install_observation)} end
try do
 breadcrumb.("physical-preflight-before",%{tag: "begin"})
 preflight_result=System.cmd("python3",[home<>"/preflight.py","--verify"])
 breadcrumb.("physical-preflight-after",safe_return.(preflight_result))
 check.("physical-preflight-exit0",elem(preflight_result,1)==0)
 breadcrumb.("application-load-before",%{tag: "begin"})
 app_load=Application.load(:beam_lisp)
 breadcrumb.("application-load-after",safe_return.(app_load))
 check.("actual-application-load",app_load==:ok or app_load=={:error,{:already_loaded,:beam_lisp}})
 dependencies=:application.get_key(:beam_lisp,:applications)
 breadcrumb.("application-dependencies",safe_return.(dependencies))
 check.("actual-application-dependency-list",match?({:ok,items} when is_list(items),dependencies))
 {:ok,deps}=dependencies
 Enum.each(deps,fn dep->
  started=Application.ensure_all_started(dep)
  breadcrumb.("dependency-start",safe_return.(started))
  check.("actual-dependency-start",match?({:ok,items} when is_list(items),started))
 end)
 breadcrumb.("bootstrap-install-before",%{tag: "begin"})
 installed=BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
 observed_install=safe_return.(installed)
 Process.put(:bootstrap_install_observation,observed_install)
 breadcrumb.("bootstrap-install-after",observed_install)
 # Only documented integrity-verified previous-generation bootstrap staging.
 check.("actual-bootstrap-install-supported-return",installed==:ok or installed=={:staged,:compiler_key_mismatch})
 breadcrumb.("actual-installed226-aot-boot-before",%{tag: "begin"})
 boot_result=BeamLisp.AOT.boot()
 breadcrumb.("actual-installed226-aot-boot-after",safe_return.(boot_result))
 check.("initial-sdk-lease-absent",not :ets.member(:beam_lisp_vars,:bl_sdk_runtime_lease))
 breadcrumb.("actual-seed-manifest-before",%{tag: "begin"})
 {:ok,[manifest]}=:file.consult(String.to_charlist(main<>"/priv/bootstrap/seed/manifest.term"))
 breadcrumb.("actual-seed-manifest-after",%{tag: "ok"})
 modules=Map.new(manifest["modules"])
 native=fn ->
  for module<-[BeamLisp.AOT,BeamLisp.AOTCache,BeamLisp.Env,BeamLisp.Emit,BeamLisp.CompilerData,BeamLisp.Ns.Compiler,BeamLisp.Ns.Core,BeamLisp.Ns.Rt] do
   {:module,^module}=Code.ensure_loaded(module)
   {^module,bytes,_}=:code.get_object_code(module)
   check.("actual-seed-object",Base.encode16(:crypto.hash(:sha256,bytes),case: :lower)==Map.fetch!(modules,Atom.to_string(module)<>".beam"))
   {:ok,{^module,md5}}=:beam_lib.md5(bytes)
   check.("actual-loaded-module-md5",md5==apply(module,:module_info,[:md5]))
  end
 end
 breadcrumb.("actual-eight-seed-object-proof-before",%{tag: "begin"})
 native.()
 breadcrumb.("actual-eight-seed-object-proof-after",%{tag: "ok",modules: 8})
 probe=BeamLisp.AOTFinalKindSourceProbe230
 check.("fresh-independent-AOT-probe",:code.is_loaded(probe)==false)
 source=home<>"/aot.candidate.bl"
 check.("exact-reviewed-AOT-source",sha.(source)==inputs["candidateSha256"])
 breadcrumb.("compile-independent-AOT-before",%{tag: "begin"})
 {^probe,path}=BeamLisp.AOT.compile_host_file(source,[module: probe,output_dir: home<>"/probe-native",source_hash: inputs["candidateSha256"],load?: false])
 bytes=File.read!(path)
 {:ok,{^probe,probe_md5}}=:beam_lib.md5(bytes)
 {:module,^probe}=:code.load_binary(probe,String.to_charlist(path),bytes)
 check.("actual-independent-AOT-MD5",apply(probe,:module_info,[:md5])==probe_md5)
 breadcrumb.("compile-independent-AOT-after",%{tag: "ok"})
 lease_before=:ets.lookup(:beam_lisp_vars,:bl_sdk_runtime_lease)
 owners_before=:ets.info(:beam_lisp_owner_index,:size)
 bindings_before=BeamLisp.Env.ns_defs("core")|>Map.new(fn {name,_}->{name,BeamLisp.Env.lookup({"core",name})} end)
 nil_compat=apply(probe,:assert_bootstrap_callable_materialization!,[])
 check.("actual-new-AOT-nil-compat6",nil_compat[:kind]==:"bootstrap-callable-materialization" and nil_compat[:passed]==6 and nil_compat[:failed]==0 and nil_compat[:"factory-executions"]==0)
 File.write!(home<>"/nil-compat-result.json",:json.encode(nil_compat))
 # Data-only component controls. These maps do not become SDK receipts or code.
 control=fn label,value->
  check.(label,value)
  rows=Process.get(:helper_controls,[])++[%{control: label,passed: true}]
  Process.put(:helper_controls,rows)
  persist.(%{helperControls: rows,nilCompatibility: nil_compat})
 end
 ns="component.kind230"
 declaration=fn kind->%{ns=>%{"identity"=>:public},:"callable-kinds"=>%{ns=>%{"identity"=>kind}}} end
 for value<-[nil,%{},%{ns=>%{"identity"=>:public}}] do
  control.("absent-final-kind-cannot-normalize",apply(probe,:"sdk_final_function?",[value,ns,"identity"])==false)
 end
 for kind<-[:function,:value,:macro,:class,:unavailable,nil] do
  control.("only-final-function-data-classifies",apply(probe,:"sdk_final_function?",[declaration.(kind),ns,"identity"])==(kind==:function))
 end
 control.("foreign-namespace-kind-cannot-normalize",apply(probe,:"sdk_final_function?",[declaration.(:function),"component.foreign230","identity"])==false)
 definitions=Map.take(BeamLisp.Env.ns_defs("core"),["identity"])
 check.("real-Core-identity-definition-present",map_size(definitions)==1)
 for value<-[nil,%{},%{"core"=>%{"identity"=>:public}}] do
  control.("recovery-or-privacy-only-does-not-rebind",apply(probe,:sdk_callable_rebindings,["core",definitions,value])==%{})
 end
 public_factory=apply(probe,:sdk_callable_factory,[ns,definitions,%{ns=>%{"identity"=>:public}}])
 private_factory=apply(probe,:sdk_callable_factory,[ns,definitions,%{ns=>%{"identity"=>:private}}])
 [public_pair]=public_factory[:body][:pairs]
 [private_pair]=private_factory[:body][:pairs]
 public_value=Enum.at(public_pair,1)
 private_value=Enum.at(private_pair,1)
 control.("public-callable-factory-is-native-external-IR",public_factory[:op]==:"defn-clause" and public_factory[:params]==[] and public_value[:op]==:remote and public_value[:mod]==:erlang and public_value[:fun]==:make_fun)
 control.("private-callable-factory-is-local-bridge-IR",private_value[:op]==:fn and length(private_value[:clauses])==1)
 walk=fn walk,node->
  cond do
   is_map(node) and node[:op] in [:lit,:plit]->[]
   is_map(node)->[node|Enum.flat_map(Map.values(node),&walk.(walk,&1))]
   is_list(node)->Enum.flat_map(node,&walk.(walk,&1))
   is_tuple(node)->node|>Tuple.to_list()|>Enum.flat_map(&walk.(walk,&1))
   true->[]
  end
 end
 shim=BeamLisp.Emit.module_for(ns)
 for kind<-[:function,:value,:macro,:unavailable,nil] do
  {initializer,companion,generated}=apply(probe,:build_init_ast,[ns,shim,definitions,[],%{},[],declaration.(kind)])
  nodes=walk.(walk,initializer)
  intern=Enum.find(nodes,fn node->node[:op]==:remote and node[:mod]==BeamLisp.Env and node[:fun]==:intern and Enum.at(node[:args],1)[:val]=="identity" end)
  value=Enum.at(intern[:args],2)
  expected_mod=if kind==:function,do: :maps,else: BeamLisp.Emit
  expected_fun=if kind==:function,do: :get,else: :fn_value
  control.("initializer-final-kind-selects-stable-or-original-value",value[:op]==:remote and value[:mod]==expected_mod and value[:fun]==expected_fun and companion==nil and generated==[])
  control.("initializer-data-has-no-canonical-AOT-self-route",not Enum.any?(nodes,fn node->node[:op]==:remote and node[:mod]==BeamLisp.AOT end))
 end
 bindings_after=BeamLisp.Env.ns_defs("core")|>Map.new(fn {name,_}->{name,BeamLisp.Env.lookup({"core",name})} end)
 control.("Core-bindings-unchanged",bindings_before==bindings_after)
 control.("SDK-lease-unchanged-and-absent",lease_before==[] and :ets.lookup(:beam_lisp_vars,:bl_sdk_runtime_lease)==lease_before)
 control.("native-owner-custody-unchanged",owners_before==0 and :ets.info(:beam_lisp_owner_index,:size)==owners_before)
 {_,0}=System.cmd("python3",[home<>"/preflight.py","--verify"])
 native.()
 result=Map.merge(observe.(),%{accepted: false,componentDiagnosticPassed: true,currentFloorAccepted: false,sdkAccepted: false,normalProducerSixCases80Accepted: false,scope: inputs["scope"],nilCompatibility: nil_compat,helperControls: Process.get(:helper_controls),helperControlCount: length(Process.get(:helper_controls)),nativeChecks: Process.get(:component_native_checks),factoryExecutions: 0,initializerExecutions: 0,generatedIRExecuted: false,probeModule: probe,probeSha256: Base.encode16(:crypto.hash(:sha256,bytes),case: :lower),probeMd5: Base.encode16(probe_md5,case: :lower)})
 File.write!(home<>"/probe-result.json",:json.encode(result))
 IO.inspect(Map.drop(result,[:helperControls]),label: "ACTUAL_INDEPENDENT_AOT_HELPER_DIAGNOSTIC")
 IO.puts("AOT_FINAL_KIND_SOURCE_ONLY_PROBE_FINISHED")
 System.halt(0)

rescue
 error->
  raw=if is_map(error),do: Map.get(error,:data),else: nil
  kind=if is_map(raw),do: Map.get(raw,:kind),else: nil
  diagnostic=if is_atom(kind) and not is_nil(kind),do: kind,else: :unclassified
  stack=Enum.take(__STACKTRACE__,12)|>Enum.map(fn {m,f,a,_}->%{module: m,function: f,arity: if(is_integer(a),do: a,else: length(a))} end)
  result=Map.merge(observe.(),%{accepted: false,mode: mode,errorClass: error.__struct__,earlyMatchObservation: if(is_struct(error,MatchError),do: safe_return.(error.term),else: nil),diagnostic: diagnostic,stack: stack,caseReports: Process.get(:case_reports,[]),fixtureReports: Process.get(:fixture_reports,%{}),sdkAccepted: false,nativeChecks: Process.get(:component_native_checks)})
  File.write!(home<>"/"<>mode<>"-result.json",:json.encode(result));IO.inspect(result,label: "ACTUAL_COMPONENT_FAILURE");System.halt(70)
catch
 kind,reason->
  code=case reason do {:component_check_failed,label}->label;_->"unclassified" end
  result=Map.merge(observe.(),%{accepted: false,mode: mode,errorKind: kind,code: code,caseReports: Process.get(:case_reports,[]),fixtureReports: Process.get(:fixture_reports,%{}),sdkAccepted: false,nativeChecks: Process.get(:component_native_checks)})
  File.write!(home<>"/"<>mode<>"-result.json",:json.encode(result));IO.inspect(result,label: "ACTUAL_COMPONENT_FAILURE");System.halt(70)
end
