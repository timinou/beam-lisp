#!/usr/bin/env python3
"""Read-only frozen controls, accepted floor and physical Source/native checks."""
from pathlib import Path
import hashlib,json,os,subprocess,sys
HERE=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def rows(root,values):
 for r in values:
  f=root/r['path'];s=f.stat()
  assert (sha(f),s.st_dev,s.st_ino,f.lstat().st_mode&0o777)==(r['sha256'],r['device'],r['inode'],r['mode']),'Physical input drift: '+r['path']
  assert ('linkTarget' in r)==f.is_symlink()
  if f.is_symlink():assert os.readlink(f)==r['linkTarget']
x=json.loads((HERE/'component-inputs.json').read_text());main=Path(x['main'])
for key in ['floorInputs','floorResult','floorLog']:assert sha(x[key])==x[key+'Sha256']
parent=json.loads(Path(x['floorResult']).read_text());assert parent['exitCode']==0 and parent.get('success',True) is True and not parent.get('receivedSignals',[])
for n,d in x['files'].items():assert sha(HERE/n)==d,'Frozen control drift: '+n
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=main,text=True).strip()==x['sourceCommit']
assert subprocess.check_output(['git','status','--porcelain','-z'],cwd=main).decode()==x['frozenGitStatus']
tracked=sorted(p for p in subprocess.check_output(['git','ls-files','-z'],cwd=main).decode().split('\0') if p)
assert tracked==[r['path'] for r in x['trackedMain']]
rows(main,x['trackedMain']);rows(main,x['sources']);rows(main,x['nativeAssets']);rows(main/'priv/bootstrap/seed',x['seed']);assert len(x['seed'])==104
assert sorted(str(p.relative_to(main/'priv/bootstrap/seed')) for p in (main/'priv/bootstrap/seed').rglob('*') if p.is_file())==[r['path'] for r in x['seed']]
actual={str(p.relative_to(main)) for p in (main/'priv').rglob('*') if p.is_file() and p.name.endswith(tuple(x['sourceExtensions']))};expected={r['path'] for r in x['sources'] if r['path'].startswith('priv/') and r['path'].endswith(tuple(x['sourceExtensions']))};assert actual==expected
if sys.argv[1:]!=['--verify']:
 assert sys.argv[1:]==['probe']
 assert not list((HERE/'probe-cache').iterdir()) and not list((HERE/'probe-native').iterdir())
 assert not list((HERE/'images/probe/lib/beam_lisp-0.1.0/ebin').iterdir())
 with (HERE/'probe-started.json').open('x') as f:json.dump({'inputsSha256':sha(HERE/'component-inputs.json'),'componentDiagnosticOnly':True,'nativeCacheInitialFiles':0},f)
print(json.dumps({'preflight':'PASS','VMsLaunched':0,'sourceCommit':x['sourceCommit'],'compilerKey':x['compilerKey']}))
