Application.load(:beam_lisp)
{:ok, deps} = :application.get_key(:beam_lisp, :applications)
Enum.each(deps, fn dep -> {:ok, _} = Application.ensure_all_started(dep) end)
:ok = BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
BeamLisp.AOT.boot()
root = System.fetch_env!("BL_PROBE_ROOT")
# Reuse the exact Compiler artifacts produced and hashed by native106.
# This is a diagnostic overlay, never a coherent-floor acceptance.
for module <- [BeamLisp.Ns.Compiler, BeamLisp.Ns.Body.Compiler, BeamLisp.Ns.Init.Compiler] do
 artifact = "/home/user/tmp/product-online-20261014/round2/compiler-metadata-native-127/compiler-beams/" <> Atom.to_string(module) <> ".beam"
 {:module, ^module} = :code.load_binary(module, String.to_charlist(artifact), File.read!(artifact))
 IO.inspect({module, Base.encode16(:crypto.hash(:sha256, File.read!(artifact)), case: :lower)}, label: "REUSED_NATIVE_COMPILER")
end
for module <- [BeamLisp.SourceGraph, BeamLisp.NamespaceInterface] do
 artifact = "/home/user/tmp/product-online-20261014/round2/constructor-context-117/host/" <> Atom.to_string(module) <> ".beam"
 {:module, ^module} = :code.load_binary(module, String.to_charlist(artifact), File.read!(artifact))
end
for {module, directory} <- [{BeamLisp.BuildPlan, "constructor-context-119/host"}, {BeamLisp.AOT, "constructor-reader-native-123/host"}, {:"Elixir.BeamLisp.Ns.Reader-node", "constructor-reader-native-123/reader-beams"}, {:"Elixir.BeamLisp.Ns.Body.Reader-node", "constructor-reader-native-123/reader-beams"}, {BeamLisp.Ns.Reader, "constructor-reader-native-123/reader-beams"}, {BeamLisp.Ns.Body.Reader, "constructor-reader-native-123/reader-beams"}, {BeamLisp.Ns.Init.Reader, "constructor-reader-native-123/reader-beams"}] do
 artifact = "/home/user/tmp/product-online-20261014/round2/" <> directory <> "/" <> Atom.to_string(module) <> ".beam"
 {:module, ^module} = :code.load_binary(module, String.to_charlist(artifact), File.read!(artifact))
 IO.inspect({module, Base.encode16(:crypto.hash(:sha256, File.read!(artifact)), case: :lower)}, label: "EXACT_NATIVE_ARTIFACT")
end
saved = BeamLisp.Env.capture()
try do
 IO.inspect(BeamLisp.AOT.compile_host_file(root <> "/aot.bl", module: BeamLisp.AOT, output_dir: root <> "/host", load?: true), label: "FRESH_NATIVE_AOT")
after
 BeamLisp.Env.bind(saved)
end
for kind <- [:thunk, :chain, :cursor], predicate <- ["vector?", "set?"] do
 counter = :atomics.new(1, [])
 effect = fn -> :atomics.add(counter, 1, 1); [2] end
 value = case kind do
  :thunk -> BeamLisp.LazySeq.new(effect)
  :chain -> BeamLisp.LazySeq.chain([1], effect)
  :cursor -> BeamLisp.LazySeq.input(Enum.to_list(1..40))
 end
 after_construction = :atomics.get(counter, 1)
 binding = BeamLisp.Env.fetch_exact!("core", predicate)
 result = BeamLisp.Ns.Rt.invoke(binding, [value])
 IO.inspect({kind, predicate, after_construction, :atomics.get(counter, 1), result, binding}, label: "ACTUAL_NATIVE_PREDICATE_EFFECT", limit: 25)
end
namespace = "vm.owner"
try do
 path = BeamLisp.Loader.source_path(namespace)
 IO.inspect(path, label: "ACTUAL_SELECTED_SDK_SOURCE")
 receipt = BeamLisp.Loader.without_initialization(fn ->
  BeamLisp.AOT.stage_sdk_dependency!(namespace, path, BeamLisp.Emit.module_for(namespace))
 end)
 IO.inspect(Map.take(receipt, [:ns, :source, :"source-digest"]), label: "ACTUAL_RECURSIVE_STAGED_UNIT")
rescue error ->
 IO.inspect({error, BeamLisp.ExInfo.ex_data(error), __STACKTRACE__}, label: "ACTUAL_SOURCE_FRONTIER", limit: :infinity, printable_limit: 3000)
 System.halt(1)
end
