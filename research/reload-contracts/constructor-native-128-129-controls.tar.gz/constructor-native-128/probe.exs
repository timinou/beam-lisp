Application.load(:beam_lisp)
{:ok, deps} = :application.get_key(:beam_lisp, :applications)
Enum.each(deps, fn dep -> {:ok, _} = Application.ensure_all_started(dep) end)
:ok = BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
BeamLisp.AOT.boot()
root = System.fetch_env!("BL_PROBE_ROOT")
# Reuse the exact Compiler artifacts produced and hashed by native106.
# This is a diagnostic overlay, never a coherent-floor acceptance.
for module <- [BeamLisp.Ns.Compiler, BeamLisp.Ns.Body.Compiler, BeamLisp.Ns.Init.Compiler] do
 artifact = "/home/user/tmp/product-online-20261014/round2/compiler-metadata-native-127/compiler-beams/" <> Atom.to_string(module) <> ".beam"
 {:module, ^module} = :code.load_binary(module, String.to_charlist(artifact), File.read!(artifact))
 IO.inspect({module, Base.encode16(:crypto.hash(:sha256, File.read!(artifact)), case: :lower)}, label: "REUSED_NATIVE_COMPILER")
end
for module <- [BeamLisp.SourceGraph, BeamLisp.NamespaceInterface] do
 artifact = "/home/user/tmp/product-online-20261014/round2/constructor-context-117/host/" <> Atom.to_string(module) <> ".beam"
 {:module, ^module} = :code.load_binary(module, String.to_charlist(artifact), File.read!(artifact))
end
for {module, directory} <- [{BeamLisp.BuildPlan, "constructor-context-119/host"}, {BeamLisp.AOT, "constructor-reader-native-123/host"}, {:"Elixir.BeamLisp.Ns.Reader-node", "constructor-reader-native-123/reader-beams"}, {:"Elixir.BeamLisp.Ns.Body.Reader-node", "constructor-reader-native-123/reader-beams"}, {BeamLisp.Ns.Reader, "constructor-reader-native-123/reader-beams"}, {BeamLisp.Ns.Body.Reader, "constructor-reader-native-123/reader-beams"}, {BeamLisp.Ns.Init.Reader, "constructor-reader-native-123/reader-beams"}] do
 artifact = "/home/user/tmp/product-online-20261014/round2/" <> directory <> "/" <> Atom.to_string(module) <> ".beam"
 {:module, ^module} = :code.load_binary(module, String.to_charlist(artifact), File.read!(artifact))
 IO.inspect({module, Base.encode16(:crypto.hash(:sha256, File.read!(artifact)), case: :lower)}, label: "EXACT_NATIVE_ARTIFACT")
end
saved = BeamLisp.Env.capture()
try do
 IO.inspect(BeamLisp.AOT.compile_host_file(root <> "/aot.bl", module: BeamLisp.AOT, output_dir: root <> "/host", load?: true), label: "FRESH_NATIVE_AOT")
after
 BeamLisp.Env.bind(saved)
end
fixtures = [{"recipe", "aot-constructor-recipe-test", ["interpreted-recipes-consume-finite-sequences-without-native-resources", "recipe-thunks-memoize-before-a-second-sequence-consumption", "private-recipe-shape-and-field-observations-refuse", "recipe-forgery-and-native-callbacks-never-gain-execution-authority", "finite-chain-and-cursor-materialization-never-invent-physical-cell-shapes", "nested-recipes-and-large-realized-prefixes-have-explicit-bounds", "finite-runtime-stack-guards-keep-the-selected-sorted-predicate-semantics", "finite-recipes-cannot-be-reinterpreted-as-ordinary-cons-tails", "opaque-observation-diagnostics-expose-only-fixed-native-target", "modeled-lazy-identity-matches-only-real-lazy-nodes", "source-core-reduce-uses-actual-compiled-wrapper-clauses", "native-fold-policy-is-closed-and-callback-output-remains-first-order", "compat-fold-never-invokes-a-mutable-runtime-predicate", "proved-capsule-vector-and-set-predicates-match-the-real-counterparts"], 66}, {"staging", "aot-sdk-constructor-staging-test", ["ordinary-compilation-does-not-have-sdk-constructor-authority", "ordinary-macro-kind-inspection-never-invokes-the-expander", "source-declaration-fold-uses-native-element-then-accumulator-order", "an-sdk-filename-with-different-source-refuses-before-effects", "actual-qualified-sdk-actor-source-compiles-without-provider-initialization", "trusted-compiler-runtime-does-not-borrow-a-mutable-core-callable"], 22}, {"ordered", "aot-ordered-staging-test", ["ordered-sdk-values-and-unnamed-actions-have-no-effects-until-normal-replay", "ordinary-sdk-clause-extension-is-collected-without-registering-before-replay", "loaded-and-pending-arbitrary-action-macros-refuse-before-their-expander-can-run", "ordinary-clause-extension-uses-definition-owned-registration-from-a-foreign-namespace", "loaded-foreign-macros-in-deferred-declarations-refuse-before-expansion"], 35}]
ok = Enum.reduce(fixtures, true, fn {label, namespace, names, expected}, previous ->
 file = root <> "/" <> label <> ".direct.bl"
 try do
  BeamLisp.Compiler.eval_string(File.read!(file), BeamLisp.Compiler.new_env(namespace), file)
  crashes = Enum.flat_map(names, fn name ->
   try do
    BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(namespace, name), [])
    []
   rescue error ->
    IO.inspect({label, name, error, BeamLisp.ExInfo.ex_data(error), __STACKTRACE__}, label: "CASE_CRASH", limit: 40)
    [name]
   end
  end)
  report = BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(namespace, "direct-report"), [])
  IO.inspect({label, report, crashes}, label: "NATIVE_ASSERTIONS", limit: :infinity)
  previous and crashes == [] and report[:assertions] == expected and report[:assertions] == report[:pass]
 rescue error ->
  IO.inspect({label, error, BeamLisp.ExInfo.ex_data(error), __STACKTRACE__}, label: "FILE_CRASH", limit: 40)
  false
 end
end)
System.halt(if ok, do: 0, else: 1)
