# Actual installed native floor plus ordinary public compiler fixture evaluation.
home=System.fetch_env!("BL_FAST_ROOT")
main=System.fetch_env!("BL_ROOT")
mode=System.fetch_env!("BL_FAST_MODE")
inputs=:json.decode(File.read!(home<>"/component-inputs.json"))
sha=fn p->Base.encode16(:crypto.hash(:sha256,File.read!(p)),case: :lower) end
Process.put(:component_native_checks,0)
check=fn label,value->
 if value==true,do: Process.put(:component_native_checks,Process.get(:component_native_checks)+1),else: throw({:component_check_failed,label})
end
persist=fn value->
 File.write!(home<>"/"<>mode<>"-progress.json.tmp",:json.encode(value))
 File.rename!(home<>"/"<>mode<>"-progress.json.tmp",home<>"/"<>mode<>"-progress.json")
end
safe_return=fn value->
 case value do
  :ok->%{tag: "ok"}
  {:staged,:compiler_key_mismatch}->%{tag: "staged",reason: "compiler_key_mismatch"}
  {:error,{:already_loaded,:beam_lisp}}->%{tag: "error",reason: "already_loaded_beam_lisp"}
  {:ok,items} when is_list(items)->%{tag: "ok",listCount: length(items)}
  {output,exit_code} when is_binary(output) and is_integer(exit_code)->%{tag: "system_cmd",exitCode: exit_code}
  {:error,_}->%{tag: "error",detail: "redacted"}
  value when is_tuple(value)->%{tag: "unclassified_tuple",arity: tuple_size(value)}
  _->%{tag: "unclassified",detail: "redacted"}
 end
end
breadcrumb=fn stage,status->
 row=%{stage: stage,status: status}
 rows=Process.get(:bootstrap_stages,[])++[row]
 Process.put(:bootstrap_stages,rows)
 File.write!(home<>"/probe-bootstrap-progress.json.tmp",:json.encode(%{stages: rows,currentFloorAccepted: false}))
 File.rename!(home<>"/probe-bootstrap-progress.json.tmp",home<>"/probe-bootstrap-progress.json")
 IO.inspect(row,label: "ACTUAL_COMPONENT_BOOTSTRAP_STAGE")
end
observe=fn ->%{bootstrapStages: Process.get(:bootstrap_stages,[]),bootstrapInstallObservation: Process.get(:bootstrap_install_observation)} end
try do
 breadcrumb.("physical-preflight-before",%{tag: "begin"})
 preflight_result=System.cmd("python3",[home<>"/preflight.py","--verify"])
 breadcrumb.("physical-preflight-after",safe_return.(preflight_result))
 check.("physical-preflight-exit0",elem(preflight_result,1)==0)
 breadcrumb.("application-load-before",%{tag: "begin"})
 app_load=Application.load(:beam_lisp)
 breadcrumb.("application-load-after",safe_return.(app_load))
 check.("actual-application-load",app_load==:ok or app_load=={:error,{:already_loaded,:beam_lisp}})
 dependencies=:application.get_key(:beam_lisp,:applications)
 breadcrumb.("application-dependencies",safe_return.(dependencies))
 check.("actual-application-dependency-list",match?({:ok,items} when is_list(items),dependencies))
 {:ok,deps}=dependencies
 Enum.each(deps,fn dep->
  started=Application.ensure_all_started(dep)
  breadcrumb.("dependency-start",safe_return.(started))
  check.("actual-dependency-start",match?({:ok,items} when is_list(items),started))
 end)
 breadcrumb.("bootstrap-install-before",%{tag: "begin"})
 installed=BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
 observed_install=safe_return.(installed)
 Process.put(:bootstrap_install_observation,observed_install)
 breadcrumb.("bootstrap-install-after",observed_install)
 # Only documented integrity-verified previous-generation bootstrap staging.
 check.("actual-bootstrap-install-supported-return",installed==:ok or installed=={:staged,:compiler_key_mismatch})
 breadcrumb.("actual-installed226-aot-boot-before",%{tag: "begin"})
 boot_result=BeamLisp.AOT.boot()
 breadcrumb.("actual-installed226-aot-boot-after",safe_return.(boot_result))
 check.("initial-sdk-lease-absent",not :ets.member(:beam_lisp_vars,:bl_sdk_runtime_lease))
 breadcrumb.("actual-seed-manifest-before",%{tag: "begin"})
 {:ok,[manifest]}=:file.consult(String.to_charlist(main<>"/priv/bootstrap/seed/manifest.term"))
 breadcrumb.("actual-seed-manifest-after",%{tag: "ok"})
 modules=Map.new(manifest["modules"])
 native=fn ->
  for module<-[BeamLisp.AOT,BeamLisp.AOTCache,BeamLisp.Env,BeamLisp.Emit,BeamLisp.CompilerData,BeamLisp.Ns.Compiler,BeamLisp.Ns.Core,BeamLisp.Ns.Rt] do
   {:module,^module}=Code.ensure_loaded(module)
   {^module,bytes,_}=:code.get_object_code(module)
   check.("actual-seed-object",Base.encode16(:crypto.hash(:sha256,bytes),case: :lower)==Map.fetch!(modules,Atom.to_string(module)<>".beam"))
   {:ok,{^module,md5}}=:beam_lib.md5(bytes)
   check.("actual-loaded-module-md5",md5==apply(module,:module_info,[:md5]))
  end
 end
 breadcrumb.("actual-eight-seed-object-proof-before",%{tag: "begin"})
 native.()
 breadcrumb.("actual-eight-seed-object-proof-after",%{tag: "ok",modules: 8})
 probe=BeamLisp.EnvSourceProbe234
 check.("fresh-independent-Env-probe",:code.is_loaded(probe)==false)
 source=home<>"/env.candidate.bl"
 check.("exact-reviewed-Env-source",sha.(source)==inputs["candidateSha256"])
 breadcrumb.("compile-independent-Env-before",%{tag: "begin"})
 {^probe,path}=BeamLisp.AOT.compile_host_file(source,[module: probe,output_dir: home<>"/probe-native",source_hash: inputs["candidateSha256"],load?: false])
 bytes=File.read!(path)
 {:ok,{^probe,probe_md5}}=:beam_lib.md5(bytes)
 {:module,^probe}=:code.load_binary(probe,String.to_charlist(path),bytes)
 check.("actual-independent-Env-MD5",apply(probe,:module_info,[:md5])==probe_md5)
 breadcrumb.("compile-independent-Env-after",%{tag: "ok"})
 native.()
 old_owner=Process.whereis(BeamLisp.Env)
 check.("old-actual-Env-owner",is_pid(old_owner) and :ets.info(:beam_lisp_vars,:owner)==old_owner)
 check.("no-running-beam-lisp-application",not Enum.any?(Application.started_applications(),fn {app,_,_}->app==:beam_lisp end))
 check.("old-native-owners-absent",:ets.info(:beam_lisp_owner_index,:size)==0)
 check.("old-SDK-lease-absent",not :ets.member(:beam_lisp_vars,:bl_sdk_runtime_lease))
 check.("no-old-supervisor-restart",Process.whereis(BeamLisp.Supervisor)==nil)
 old_tables=Enum.filter(:ets.all(),fn table->:ets.info(table,:owner)==old_owner end)
 check.("old-source-custody-empty",Enum.all?([:beam_lisp_source_extents,:beam_lisp_source_lease_domains],fn table->:ets.whereis(table)==:undefined or :ets.info(table,:size)==0 end))
 old_monitor=Process.monitor(old_owner)
 :ok=Agent.stop(old_owner)
 receive do {:DOWN,^old_monitor,:process,^old_owner,:normal}->:ok after 1000->throw({:component_check_failed,"old-Env-DOWN-not-observed"}) end
 check.("all-old-actual-Env-tables-dropped",Enum.all?(old_tables,fn table->:ets.info(table)==:undefined end))
 check.("old-Env-actually-stopped",not Process.alive?(old_owner) and Process.whereis(BeamLisp.Env)==nil)
 check.("old-native-tables-dropped",:ets.whereis(:beam_lisp_vars)==:undefined and :ets.whereis(:beam_lisp_owner_index)==:undefined)
 breadcrumb.("fresh-independent-Env-start-before",%{tag: "begin"})
 {:ok,owner}=apply(probe,:start_link,[[]])
 check.("actual-fresh-Env-start",Process.whereis(probe)==owner and owner!=old_owner)
 check.("fresh-command-table-initializer",apply(probe,:initialize_native_commands!,[])==:initialized)
 native_starts=apply(probe,:native_start_table_evidence!,[])
 check.("actual-start-table-evidence",is_list(native_starts) and length(native_starts)==3)
 tables=[:beam_lisp_vars,:beam_lisp_code_leases,:beam_lisp_owner_index,:beam_lisp_owner_revisions,
 :beam_lisp_source_extents,:beam_lisp_source_lease_domains,:beam_lisp_source_extent_heads,
 :beam_lisp_native_commands,:beam_lisp_native_command_frames,:beam_lisp_native_command_effects,
 :beam_lisp_server_starts,:beam_lisp_owner_transitions,:beam_lisp_owner_transition_heads,:beam_lisp_server_initializers,
 :beam_lisp_native_owned_starts,:beam_lisp_native_launches,:beam_lisp_native_start_code]
 evidence=Enum.map(tables,fn table->
  row=%{table: table,ownerActual: :ets.info(table,:owner)==owner,protection: :ets.info(table,:protection),type: :ets.info(table,:type),size: :ets.info(table,:size)}
  check.("actual-new-Env-table-custody",row.ownerActual)
  check.("actual-new-Env-table-protection",row.protection==cond do table in [:beam_lisp_vars,:beam_lisp_code_leases,:beam_lisp_owner_index,:beam_lisp_owner_revisions]->:public;table in [:beam_lisp_source_extent_heads,:beam_lisp_native_start_code]->:protected;true->:private end)
  row
 end)
 check.("initial-native-summary-inactive",:ets.lookup(:beam_lisp_source_extent_heads,:native_command_critical_cells_active)==[{:native_command_critical_cells_active,false}])
 for table<-[:beam_lisp_native_commands,:beam_lisp_native_command_frames,:beam_lisp_native_command_effects,:beam_lisp_source_extents,:beam_lisp_source_lease_domains,:beam_lisp_owner_index] do
  check.("fresh-private-custody-empty",:ets.info(table,:size)==0)
 end
 check.("fresh-Source-inactive",apply(probe,:source_execution_active?,[])==false)
 check.("fresh-decoder-native",apply(probe,:source_data_decode_required?,[])==false)
 check.("fresh-native-framework",apply(probe,:assert_native_framework_execution!,[])==nil)
 check.("fresh-no-SDK-lease",not :ets.member(:beam_lisp_vars,:bl_sdk_runtime_lease))
 check.("fresh-command-initializer-idempotent",apply(probe,:initialize_native_commands!,[])==:initialized)
 breadcrumb.("fresh-independent-Env-start-after",%{tag: "ok",tables: length(tables)})
 {_,0}=System.cmd("python3",[home<>"/preflight.py","--verify"])
 native.()
 :ok=Agent.stop(owner)
 check.("probe-owner-stopped",not Process.alive?(owner) and :ets.whereis(:beam_lisp_vars)==:undefined)
 result=Map.merge(observe.(),%{accepted: false,componentDiagnosticPassed: true,currentFloorAccepted: false,sdkAccepted: false,scope: inputs["scope"],nativeChecks: Process.get(:component_native_checks),tableEvidence: evidence,probeModule: probe,probeSha256: Base.encode16(:crypto.hash(:sha256,bytes),case: :lower),probeMd5: Base.encode16(probe_md5,case: :lower),canonicalModuleReplaced: false,externalTablesCreated: 0,actualIndependentEnvStart: true,temporaryOwnerStopped: true})
 File.write!(home<>"/probe-result.json",:json.encode(result))
 IO.inspect(result,label: "ACTUAL_INDEPENDENT_ENV_INITIALIZER_DIAGNOSTIC")
 IO.puts("ENV_SOURCE_ONLY_PROBE_FINISHED")
 System.halt(0)

rescue
 error->
  raw=if is_map(error),do: Map.get(error,:data),else: nil
  kind=if is_map(raw),do: Map.get(raw,:kind),else: nil
  diagnostic=if is_atom(kind) and not is_nil(kind),do: kind,else: :unclassified
  stack=Enum.take(__STACKTRACE__,12)|>Enum.map(fn {m,f,a,_}->%{module: m,function: f,arity: if(is_integer(a),do: a,else: length(a))} end)
  result=Map.merge(observe.(),%{accepted: false,mode: mode,errorClass: error.__struct__,earlyMatchObservation: if(is_struct(error,MatchError),do: safe_return.(error.term),else: nil),diagnostic: diagnostic,stack: stack,caseReports: Process.get(:case_reports,[]),fixtureReports: Process.get(:fixture_reports,%{}),sdkAccepted: false,nativeChecks: Process.get(:component_native_checks)})
  File.write!(home<>"/"<>mode<>"-result.json",:json.encode(result));IO.inspect(result,label: "ACTUAL_COMPONENT_FAILURE");System.halt(70)
catch
 kind,reason->
  code=case reason do {:component_check_failed,label}->label;_->"unclassified" end
  result=Map.merge(observe.(),%{accepted: false,mode: mode,errorKind: kind,code: code,caseReports: Process.get(:case_reports,[]),fixtureReports: Process.get(:fixture_reports,%{}),sdkAccepted: false,nativeChecks: Process.get(:component_native_checks)})
  File.write!(home<>"/"<>mode<>"-result.json",:json.encode(result));IO.inspect(result,label: "ACTUAL_COMPONENT_FAILURE");System.halt(70)
end
