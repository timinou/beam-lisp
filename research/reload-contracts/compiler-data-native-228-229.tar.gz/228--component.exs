# Actual installed native floor plus ordinary public compiler fixture evaluation.
home=System.fetch_env!("BL_FAST_ROOT")
main=System.fetch_env!("BL_ROOT")
mode=System.fetch_env!("BL_FAST_MODE")
inputs=:json.decode(File.read!(home<>"/component-inputs.json"))
sha=fn p->Base.encode16(:crypto.hash(:sha256,File.read!(p)),case: :lower) end
Process.put(:component_native_checks,0)
check=fn label,value->
 if value==true,do: Process.put(:component_native_checks,Process.get(:component_native_checks)+1),else: throw({:component_check_failed,label})
end
persist=fn value->
 File.write!(home<>"/"<>mode<>"-progress.json.tmp",:json.encode(value))
 File.rename!(home<>"/"<>mode<>"-progress.json.tmp",home<>"/"<>mode<>"-progress.json")
end
observe=fn ->
 counters=Map.new([{:constructorCompileCalls,{BeamLisp.AOT,:constructor_compile_sdk_unit!,2}},{:cacheRestoreCalls,{BeamLisp.AOT,:restore_sdk_staged_unit!,3}}],fn {key,mfa}->
  n=case :erlang.trace_info(mfa,:call_count) do {:call_count,value} when is_integer(value)->value;_->nil end
  {key,n}
 end)
 if is_pid(Process.get(:diagnostic_sampler)) do
  send(Process.get(:diagnostic_sampler),{:stop,Process.get(:diagnostic_sampler_phase_token),self()})
  receive do :diagnostic_sampler_stopped->:ok after 2000->:ok end
 end
 counters
end
try do
 {_,0}=System.cmd("python3",[home<>"/preflight.py","--verify"])
 Application.load(:beam_lisp)
 {:ok,deps}=:application.get_key(:beam_lisp,:applications)
 Enum.each(deps,fn dep->{:ok,_}=Application.ensure_all_started(dep) end)
 :ok=BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
 BeamLisp.AOT.boot()
 check.("initial-sdk-lease-absent",not :ets.member(:beam_lisp_vars,:bl_sdk_runtime_lease))
 {:ok,[manifest]}=:file.consult(String.to_charlist(main<>"/priv/bootstrap/seed/manifest.term"))
 modules=Map.new(manifest["modules"])
 native=fn ->
  for module<-[BeamLisp.AOT,BeamLisp.AOTCache,BeamLisp.Env,BeamLisp.Emit,BeamLisp.CompilerData,BeamLisp.Ns.Compiler,BeamLisp.Ns.Core,BeamLisp.Ns.Rt] do
   {:module,^module}=Code.ensure_loaded(module)
   {^module,bytes,_}=:code.get_object_code(module)
   check.("actual-seed-object",Base.encode16(:crypto.hash(:sha256,bytes),case: :lower)==Map.fetch!(modules,Atom.to_string(module)<>".beam"))
   {:ok,{^module,md5}}=:beam_lib.md5(bytes)
   check.("actual-loaded-module-md5",md5==apply(module,:module_info,[:md5]))
  end
 end
 native.()
 probe=BeamLisp.HostCompilerDataSourceProbe228
 check.("fresh-probe-atom-not-loaded",:code.is_loaded(probe)==false)
 source=home<>"/compiler-data.candidate.bl"
 check.("exact-candidate-source",sha.(source)==inputs["candidateSha256"])
 compiled=BeamLisp.AOT.compile_host_file(source,[module: probe,output_dir: home<>"/probe-native",source_hash: inputs["candidateSha256"],load?: false])
 {^probe,path}=compiled
 bytes=File.read!(path)
 {:ok,{^probe,probe_md5}}=:beam_lib.md5(bytes)
 {:module,^probe}=:code.load_binary(probe,String.to_charlist(path),bytes)
 check.("actual-probe-md5",apply(probe,:module_info,[:md5])==probe_md5)
 readiness=apply(probe,:assert_bootstrap_metadata_symbol_data!,[])
 check.("actual-readiness-checks",readiness==%{:"callback-executions"=>0,:"authority-granted"=>false,:kind=>:"bootstrap-metadata-symbol-data",:passed=>14,:failed=>0})
 File.write!(home<>"/readiness-result.json",:json.encode(readiness))
 callable_preflight=BeamLisp.AOT.assert_bootstrap_callable_materialization!()
 check.("actual-installed226-callable-readiness",callable_preflight[:kind]==:"bootstrap-callable-materialization" and callable_preflight[:passed]==6 and callable_preflight[:failed]==0 and callable_preflight[:"factory-executions"]==0)
 # Exact finite prefix loop length from the actual native encoder used by fixture.
 prefix_length=byte_size(:erlang.term_to_binary(%{key: {1,2,"payload"}}))
 check.("bounded-actual-ETF-prefix-loop",prefix_length>0 and prefix_length<=128)
 for role<-["firstOrder","closedEtf"] do
  fixture=inputs["fixtures"][role]
  check.("exact-original-fixture",sha.(home<>"/"<>fixture["original"])==fixture["sha256"])
  file=home<>"/"<>fixture["direct"]
  namespace=fixture["namespace"]
  BeamLisp.Compiler.eval_string(File.read!(file),BeamLisp.Compiler.new_env(namespace),file)
  report=fn ->BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(namespace,"direct-report"),[]) end
  for name<-fixture["functions"] do
   before=report.();Process.put(:case_returned,false)
   try do
    BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(namespace,name),[])
    Process.put(:case_returned,true)
   after
    current=report.();delta=Map.new([:assertions,:passed,:failed],fn k->{k,current[k]-before[k]} end)
    row=%{role: role,caseName: name,returned: Process.get(:case_returned),assertions: delta}
    Process.put(:case_reports,Process.get(:case_reports,[])++[row])
    Process.put(:fixture_reports,Map.put(Process.get(:fixture_reports,%{}),role,current))
    persist.(%{caseReports: Process.get(:case_reports),fixtureReports: Process.get(:fixture_reports),actualEtfPrefixLength: prefix_length})
    IO.inspect(row,label: "ACTUAL_PROBE_CASE_COUNTERS")
   end
  end
  actual=report.()
  expected=if role=="firstOrder",do: 105,else: 121+prefix_length
  check.("actual-fixture-assertions",actual==%{assertions: expected,passed: expected,failed: 0})
 end
 check.("actual-fourteen-cases",length(Process.get(:case_reports))==14)
 # Same-process warm decoder comparison only, using fixed trusted test data.
 payloads=[{"scalar",:existing},{"nested-map",%{key: {1,2,"payload"},nested: [%{a: [1,2,3]},%{b: true}]}},{"list-1024",Enum.to_list(1..1024)}]
 benchmark_rows=for {label,value}<-payloads,round<-1..4 do
  encoded=:erlang.term_to_binary(value)
  strategies=if rem(round,2)==1,do: ["plain-bif","guarded-decode"],else: ["guarded-decode","plain-bif"]
  for strategy<-strategies do
   decode=if strategy=="plain-bif",do: fn ->:erlang.binary_to_term(encoded,[:safe]) end,else: fn ->apply(probe,:decode_closed_etf!,[encoded]) end
   for _<-1..2,do: check.("actual-warm-decoder-roundtrip",decode.()==value)
   {:reductions,before_reductions}=:erlang.process_info(self(),:reductions)
   start=System.monotonic_time(:microsecond)
   last=Enum.reduce(1..100,nil,fn _,_->decode.() end)
   elapsed=System.monotonic_time(:microsecond)-start
   {:reductions,after_reductions}=:erlang.process_info(self(),:reductions)
   check.("actual-timed-decoder-roundtrip",last==value)
   %{payload: label,encodedBytes: byte_size(encoded),round: round,strategy: strategy,repeats: 100,warmupCalls: 2,elapsedUs: elapsed,reductions: after_reductions-before_reductions}
  end
 end|>List.flatten()
 benchmark=%{scope: "Same native process warm guard+decode versus plain safe BIF; fixed trusted component data only, not startup/SDK/application timings",acceptance: false,payloads: 3,pairedRoundsPerPayload: 4,samples: benchmark_rows}
 check.("bounded-paired-decoder-samples",length(benchmark_rows)==24)
 File.write!(home<>"/paired-decode-benchmark.json",:json.encode(benchmark))
 check.("no-sdk-lease-after-source-probe",not :ets.member(:beam_lisp_vars,:bl_sdk_runtime_lease))
 check.("no-admitted-owners-after-source-probe",:ets.info(:beam_lisp_owner_index,:size)==0)
 {_,0}=System.cmd("python3",[home<>"/preflight.py","--verify"])
 native.()
 result=%{accepted: false,componentDiagnosticPassed: true,currentFloorAccepted: false,sdkAccepted: false,pairedDecodeBenchmark: benchmark,readiness: readiness,installed226CallablePreflight: callable_preflight,assertions: Process.get(:fixture_reports),actualEtfPrefixLength: prefix_length,caseReports: Process.get(:case_reports),nativeChecks: Process.get(:component_native_checks),probeModule: probe,probeSha256: Base.encode16(:crypto.hash(:sha256,bytes),case: :lower),probeMd5: Base.encode16(probe_md5,case: :lower),scope: inputs["scope"]}
 File.write!(home<>"/probe-result.json",:json.encode(result))
 IO.inspect(Map.drop(result,[:caseReports,:pairedDecodeBenchmark]),label: "ACTUAL_SOURCE_ONLY_COMPILER_DATA_PROBE")
 IO.puts("COMPILER_DATA_SOURCE_ONLY_PROBE_FINISHED")
 System.halt(0)
rescue
 error->
  raw=if is_map(error),do: Map.get(error,:data),else: nil
  kind=if is_map(raw),do: Map.get(raw,:kind),else: nil
  diagnostic=if is_atom(kind),do: kind,else: :unclassified
  stack=Enum.take(__STACKTRACE__,12)|>Enum.map(fn {m,f,a,_}->%{module: m,function: f,arity: if(is_integer(a),do: a,else: length(a))} end)
  result=Map.merge(observe.(),%{accepted: false,mode: mode,errorClass: error.__struct__,diagnostic: diagnostic,stack: stack,caseReports: Process.get(:case_reports,[]),fixtureReports: Process.get(:fixture_reports,%{}),sdkAccepted: false,nativeChecks: Process.get(:component_native_checks)})
  File.write!(home<>"/"<>mode<>"-result.json",:json.encode(result));IO.inspect(result,label: "ACTUAL_COMPONENT_FAILURE");System.halt(70)
catch
 kind,reason->
  code=case reason do {:component_check_failed,label}->label;_->"unclassified" end
  result=Map.merge(observe.(),%{accepted: false,mode: mode,errorKind: kind,code: code,caseReports: Process.get(:case_reports,[]),fixtureReports: Process.get(:fixture_reports,%{}),sdkAccepted: false,nativeChecks: Process.get(:component_native_checks)})
  File.write!(home<>"/"<>mode<>"-result.json",:json.encode(result));IO.inspect(result,label: "ACTUAL_COMPONENT_FAILURE");System.halt(70)
end
