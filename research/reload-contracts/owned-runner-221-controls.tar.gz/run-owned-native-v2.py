#!/usr/bin/env python3
"""Run one owned bounded VM; preserve actual waiter and service outcomes separately."""
import argparse
import datetime
import fcntl
import hashlib
import json
import re
import signal
import subprocess
import time
from pathlib import Path

BASE = Path('/home/user/tmp/product-online-20261014/round2')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest() if path.exists() else None


def outcome(control, returncode):
    result = re.search(r'Finished with result:\s*(\S+)', control)
    value = result.group(1) if result else None
    return value, returncode == 0 and value == 'success'


def run():
    parser = argparse.ArgumentParser()
    parser.add_argument('--unit', required=True)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--script', type=Path, required=True)
    parser.add_argument('--seconds', type=int, required=True)
    args = parser.parse_args()
    script, root = args.script.resolve(), args.root.resolve()
    assert script.is_relative_to(BASE) and script.is_file()
    assert 0 < args.seconds <= 2700
    assert re.fullmatch(r'bl-[A-Za-z0-9-]+', args.unit)
    unit = args.unit + '.service'
    directory = script.parent
    log = directory / (args.unit + '.log')
    control = directory / (args.unit + '-control.log')
    receipt = directory / (args.unit + '-parent.json')
    journal = directory / (args.unit + '-journal.jsonl')
    assert not any(p.exists() for p in (log, control, receipt, journal))
    with (BASE / 'root-native-launch.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        existing = subprocess.run(['systemctl', '--user', 'show', unit,
                                   '--property=LoadState', '--value'],
                                  capture_output=True, text=True, timeout=15)
        assert existing.stdout.strip() in ('', 'not-found'), existing.stdout
        mem = subprocess.run([str(root / 'scripts/bl-mem')], capture_output=True,
                             text=True, check=True, timeout=30)
        (directory / (args.unit + '-memory-before.txt')).write_text(mem.stdout)
        print(mem.stdout, flush=True)
        command = ['systemd-run', '--user', '--collect', '--wait', '--unit=' + args.unit,
                   '--working-directory=' + str(root), '--property=MemoryMax=6G',
                   '--property=MemorySwapMax=0', '--property=RuntimeMaxSec=' + str(args.seconds) + 's',
                   '--property=TimeoutStopSec=15s', '--property=StandardOutput=append:' + str(log),
                   '--property=StandardError=inherit', str(script)]
        start = time.monotonic()
        data = {'unit': unit, 'command': command, 'scriptSha256': digest(script),
                'runnerSha256': digest(Path(__file__)),
                'startedUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                'state': 'launching', 'exitCode': None, 'success': False,
                'receivedSignals': []}

        def persist():
            # Every state is useful even if the parent itself is later killed.
            receipt.write_text(json.dumps(data, indent=2) + '\n')

        def interrupted(signum, frame):
            data['receivedSignals'].append(signum)
            persist()

        def stop_owned():
            # Never stop a reused unit name: require this launch's actual invocation.
            match = re.search(r'invocation ID:\s*([a-f0-9]{32})', control.read_text())
            if not match:
                return False
            shown = subprocess.run(['systemctl', '--user', 'show', unit,
                                    '--property=InvocationID', '--value'],
                                   capture_output=True, text=True, timeout=10)
            if shown.returncode == 0 and shown.stdout.strip() == match.group(1):
                subprocess.run(['systemctl', '--user', 'stop', '--no-block', unit],
                               capture_output=True, timeout=10)
                return True
            return False

        signal.signal(signal.SIGTERM, interrupted)
        signal.signal(signal.SIGINT, interrupted)
        persist()
        child = None
        try:
            with control.open('w') as stream:
                # The service waiter's termination must not kill its receipt writer.
                child = subprocess.Popen(command, stdout=stream, stderr=subprocess.STDOUT,
                                         start_new_session=True)
                data.update(state='running', waiterPID=child.pid)
                persist()
                stop_requested = False
                deadline = start + args.seconds + 45
                while child.poll() is None:
                    if data['receivedSignals'] or time.monotonic() >= deadline:
                        if not stop_requested:
                            data['ownedStopRequested'] = stop_owned()
                            stop_requested = True
                            deadline = time.monotonic() + 25
                        elif time.monotonic() >= deadline:
                            child.terminate()
                            try:
                                child.wait(timeout=5)
                            except subprocess.TimeoutExpired:
                                child.kill()
                            break
                    time.sleep(0.25)
                data['exitCode'] = child.wait(timeout=10)
        except BaseException as exc:
            data['parentError'] = type(exc).__name__ + ': ' + str(exc)
            stop_owned()
            if child is not None and child.poll() is None:
                child.terminate()
                try:
                    child.wait(timeout=20)
                except subprocess.TimeoutExpired:
                    child.kill()
                    child.wait(timeout=5)
            if child is not None:
                data['exitCode'] = child.returncode
        finally:
            capture = subprocess.run(['journalctl', '--user', '-u', unit, '-o', 'json',
                                      '--no-pager', '--since', data['startedUTC']],
                                     capture_output=True, text=True, timeout=20)
            journal.write_text(capture.stdout)
            data['journalCaptureExitCode'] = capture.returncode
            text = control.read_text() if control.exists() else ''
            service_result, accepted = outcome(text, data['exitCode'])
            invocation = re.search(r'invocation ID:\s*([a-f0-9]{32})', text)
            data.update(state='finished', serviceResult=service_result,
                        invocationID=invocation.group(1) if invocation else None,
                        success=accepted and not data['receivedSignals'] and
                                'parentError' not in data and capture.returncode == 0,
                        finishedUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                        wallSecondsParent=time.monotonic() - start,
                        controlSha256=digest(control), logSha256=digest(log),
                        journalSha256=digest(journal))
            persist()
            print(json.dumps(data), flush=True)
        return 0 if data['success'] else (data['exitCode'] if data['exitCode'] and data['exitCode'] > 0 else 1)


if __name__ == '__main__':
    raise SystemExit(run())
