# Root-only targeted coherent193 native component. No host overlay or SDK lease.
# Explicit ordinary header initialization is component setup, not CLI acceptance.
root=System.fetch_env!("BL_PROBE_ROOT")
main=System.fetch_env!("BL_ROOT")
sha=fn p->Base.encode16(:crypto.hash(:sha256,File.read!(p)),case: :lower) end
inputs=:json.decode(File.read!(root<>"/inputs.json"))
Enum.each(inputs["sources"],fn row->true=sha.(main<>"/"<>row["path"])==row["sha256"] end)
Enum.each(inputs["files"],fn {p,h}->true=sha.(root<>"/"<>p)==h end)
true=sha.(main<>"/priv/bootstrap/seed/manifest.term")==inputs["manifestSha256"]
Application.load(:beam_lisp)
{:ok,deps}=:application.get_key(:beam_lisp,:applications)
Enum.each(deps,fn d->{:ok,_}=Application.ensure_all_started(d) end)
:ok=BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
BeamLisp.AOT.boot()
false=:ets.member(:beam_lisp_vars,:bl_sdk_runtime_lease)
true=BeamLisp.AOTCache.current_compiler_key()==inputs["compilerKey"]
Enum.each([BeamLisp.AOT,BeamLisp.Env,BeamLisp.CompilerData],fn m->
 {^m,bytes,_}=:code.get_object_code(m)
 filename=Atom.to_string(m)<>".beam"
 true=Base.encode16(:crypto.hash(:sha256,bytes),case: :lower)==inputs["hostArtifacts"][filename]
 {:ok,{^m,md5}}=:beam_lib.md5(bytes)
 ^md5=apply(m,:module_info,[:md5])
end)
namespace="reload.collection-constructor"
source=BeamLisp.Loader.source_path(namespace)
content=BeamLisp.Loader.read_source(source)
true=sha.(source)==inputs["targetSourceSha256"]
forms=BeamLisp.Reader.read_string(content,source)
metadata=apply(BeamLisp.AOT,:capture_ns_decl,[%{},hd(forms)])[namespace]
requires=metadata[:requires]||[]
IO.inspect(%{namespace: namespace,requires: requires,setup: :ordinary_header_initialization_only},label: "TARGETED_COMPONENT_SETUP")
start=System.monotonic_time(:microsecond)
Enum.each(requires,fn n->BeamLisp.Loader.ensure_loaded(n) end)
false=:ets.member(:beam_lisp_vars,:bl_sdk_runtime_lease)
IO.inspect(%{namespace: namespace,microseconds: System.monotonic_time(:microsecond)-start},label: "TARGETED_COMPONENT_DEPENDENCIES_READY")
saved=BeamLisp.Env.capture()
start=System.monotonic_time(:microsecond)
result=try do
 artifacts=BeamLisp.AOT.compile_source(content,[{:file,source},{:output_dir,root<>"/output"},{:"stage-sdk?",true}])
 IO.inspect(%{namespace: namespace,artifacts: length(artifacts),microseconds: System.monotonic_time(:microsecond)-start},label: "ACTUAL_COLLECTION_TARGET_PASS")
 :pass
rescue error->
 data=BeamLisp.ExInfo.ex_data(error)
 safe=if is_map(data),do: Map.take(data,[:kind,:detail,:reason,:operation,:"constructor-operation",:"constructor-namespace",:"constructor-macro",:"constructor-call-stack"]),else: nil
 IO.inspect(%{namespace: namespace,error: error.__struct__,message: Exception.message(error),data: safe,microseconds: System.monotonic_time(:microsecond)-start},label: "ACTUAL_COLLECTION_TARGET_REFUSAL",limit: :infinity)
 IO.inspect(__STACKTRACE__,label: "ACTUAL_COLLECTION_TARGET_NATIVE_STACK",limit: 35)
 :refused
after BeamLisp.Env.bind(saved) end
false=:ets.member(:beam_lisp_vars,:bl_sdk_runtime_lease)
Enum.each(inputs["sources"],fn row->true=sha.(main<>"/"<>row["path"])==row["sha256"] end)
System.halt(if result==:pass,do: 0,else: 70)
