# Root-only exact196 native candidate replay. No recompilation or SDK lease.
root=System.fetch_env!("BL_PROBE_ROOT")
main=System.fetch_env!("BL_ROOT")
sha=fn p->Base.encode16(:crypto.hash(:sha256,File.read!(p)),case: :lower) end
inputs=:json.decode(File.read!(root<>"/inputs.json"))
Enum.each(inputs["sources"],fn row->true=sha.(main<>"/"<>row["path"])==row["sha256"] end)
Enum.each(inputs["files"],fn {p,h}->true=sha.(root<>"/"<>p)==h end)
Application.load(:beam_lisp)
{:ok,deps}=:application.get_key(:beam_lisp,:applications)
Enum.each(deps,fn d->{:ok,_}=Application.ensure_all_started(d) end)
:ok=BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
BeamLisp.AOT.boot()
false=:ets.member(:beam_lisp_vars,:bl_sdk_runtime_lease)
true=BeamLisp.AOTCache.current_compiler_key()==inputs["compilerKey"]
true=sha.(main<>"/priv/bootstrap/seed/manifest.term")==inputs["manifestSha256"]
path=root<>"/host/Elixir.BeamLisp.AOT.beam"
true=sha.(path)==inputs["artifactSha256"]
bytes=File.read!(path)
{:module,BeamLisp.AOT}=:code.load_binary(BeamLisp.AOT,String.to_charlist(path),bytes)
{:ok,{BeamLisp.AOT,md5}}=:beam_lib.md5(bytes)
^md5=apply(BeamLisp.AOT,:module_info,[:md5])
IO.inspect(%{artifactSha256: sha.(path),sourceSha256: inputs["candidateSourceSha256"],md5: Base.encode16(md5,case: :lower)},label: "EXACT_196_AOT_REPLAY")
namespace="reload.collection-constructor"
source=BeamLisp.Loader.source_path(namespace)
content=BeamLisp.Loader.read_source(source)
true=sha.(source)==inputs["targetSourceSha256"]
forms=BeamLisp.Reader.read_string(content,source)
requires=apply(BeamLisp.AOT,:capture_ns_decl,[%{},hd(forms)])[namespace][:requires]||[]
Enum.each(requires,fn n->BeamLisp.Loader.ensure_loaded(n) end)
false=:ets.member(:beam_lisp_vars,:bl_sdk_runtime_lease)
started=System.monotonic_time(:microsecond)
artifacts=BeamLisp.AOT.compile_source(content,[{:file,source},{:output_dir,root<>"/actual-output"},{:"stage-sdk?",true}])
true=length(artifacts)==2
expected_roles=MapSet.new([:"stable-body",:"mutable-forwarder"])
rows=Enum.map(artifacts,fn {module,file}->
 row=apply(BeamLisp.AOT,:source_sdk_receipt,[module])
 true=is_map(row)
 true=row[:"source-digest"]==:crypto.hash(:sha256,content)
 true=row[:"compiler-key"]==inputs["compilerKey"]
 true=row[:sha256]==:crypto.hash(:sha256,File.read!(file))
 true=row[:md5]==apply(module,:module_info,[:md5])
 %{module: module,role: row[:role],sha256: sha.(file)}
end)
true=MapSet.new(Enum.map(rows,&(&1.role)))==expected_roles
true=BeamLisp.AOT.sdk_unit_compiled?(namespace)
IO.inspect(%{namespace: namespace,artifacts: rows,completeCurrentUnitReceipt: true,microseconds: System.monotonic_time(:microsecond)-started},label: "ACTUAL_COLLECTION_UNIT_ROLES_AND_RECEIPT_PASS")
# Run unchanged25negative/budget controls, then exact permanent five actual
# physical Source assertions with corrected body/facade role/count expectation.
file=root<>"/empty-recipes.direct.bl"
ns="aot-constructor-empty-recipes-test"
BeamLisp.Compiler.eval_string(File.read!(file),BeamLisp.Compiler.new_env(ns),file)
tests=:json.decode(File.read!(root<>"/test-names.json"))
Enum.each(tests["names"],fn name->BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(ns,name),[]) end)
report=BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(ns,"direct-report"),[])
IO.inspect(report,label: "EMPTY_RECIPE_25_CONTROLS",limit: :infinity)
file=root<>"/actual-collection-five.direct.bl"
ns="core-letfn-actual-collection-five-test"
BeamLisp.Compiler.eval_string(File.read!(file),BeamLisp.Compiler.new_env(ns),file)
BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(ns,"actual-sdk-collection-unit-stages-with-current-physical-core"),[])
five=BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(ns,"direct-report"),[])
IO.inspect(five,label: "ACTUAL_PHYSICAL_COLLECTION_FIVE",limit: :infinity)
false=:ets.member(:beam_lisp_vars,:bl_sdk_runtime_lease)
Enum.each(inputs["sources"],fn row->true=sha.(main<>"/"<>row["path"])==row["sha256"] end)
# Additional unchanged closed-engine component regressions. Ordinary helper
# metadata is captured from actual Compiler output in THIS VM. No SDK lease,
# supplied app receipt, actor-positive fixture or child native VM is involved.
BeamLisp.Loader.ensure_loaded("data.first-order")
regressions=:json.decode(File.read!(root<>"/closed-regressions.json"))
regression_ok=Enum.reduce(regressions["fixtures"],true,fn fixture,previous->
 label=fixture["label"]
 if label=="machine" do
  BeamLisp.Loader.ensure_loaded("proc.tick")
  Enum.each(["proc.server","proc.tick"],fn selected->
   File.write!(root<>"/"<>selected<>".env-anf.term",:erlang.term_to_binary(BeamLisp.Env.ns_defs(selected)))
  end)
  System.put_env("BL_CONSTRUCTOR_METADATA_ROOT",root)
 end
 file=root<>"/"<>fixture["direct"]
 namespace=fixture["namespace"]
 start=System.monotonic_time(:microsecond)
 try do
  BeamLisp.Compiler.eval_string(File.read!(file),BeamLisp.Compiler.new_env(namespace),file)
  crashes=Enum.flat_map(fixture["names"],fn name->
   try do
    BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(namespace,name),[])
    []
   rescue error->
    IO.inspect(%{scope: label,name: name,error: error.__struct__,message: Exception.message(error),data: BeamLisp.ExInfo.ex_data(error)},label: "CLOSED_COMPONENT_CASE_CRASH",limit: 40)
    [name]
   end
  end)
  answer=BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(namespace,"direct-report"),[])
  IO.inspect(%{scope: label,expectedAssertions: fixture["expectedAssertions"],report: answer,crashes: crashes,microseconds: System.monotonic_time(:microsecond)-start},label: "CLOSED_COMPONENT_REGRESSIONS",limit: :infinity)
  false=:ets.member(:beam_lisp_vars,:bl_sdk_runtime_lease)
  previous and crashes==[] and answer[:assertions]==fixture["expectedAssertions"] and answer[:pass]==fixture["expectedAssertions"]
 rescue error->
  IO.inspect(%{scope: label,error: error.__struct__,message: Exception.message(error),data: BeamLisp.ExInfo.ex_data(error)},label: "CLOSED_COMPONENT_FILE_CRASH",limit: 40)
  false
 end
end)
System.delete_env("BL_CONSTRUCTOR_METADATA_ROOT")
false=:ets.member(:beam_lisp_vars,:bl_sdk_runtime_lease)
Enum.each(inputs["sources"],fn row->true=sha.(main<>"/"<>row["path"])==row["sha256"] end)
pass=report[:assertions]==25 and report[:pass]==25 and five[:assertions]==5 and five[:pass]==5 and regression_ok
IO.inspect(%{controls: 25,physicalSourceAssertions: 5,closedRegressionAssertions: 1043,totalAssertions: 1073,actualArtifactRoles: [:"stable-body",:"mutable-forwarder"],accepted: pass,ordinaryStartupAccepted: false},label: "EXACT_196_ARTIFACT_REPLAY_FINAL")
System.halt(if pass,do: 0,else: 70)
