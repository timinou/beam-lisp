# Root-only old193 vs fresh exact one-guard AOT native component. Never startup.
root=System.fetch_env!("BL_PROBE_ROOT")
main=System.fetch_env!("BL_ROOT")
sha=fn p->Base.encode16(:crypto.hash(:sha256,File.read!(p)),case: :lower) end
inputs=:json.decode(File.read!(root<>"/inputs.json"))
Enum.each(inputs["sources"],fn row->true=sha.(main<>"/"<>row["path"])==row["sha256"] end)
Enum.each(inputs["files"],fn {p,h}->true=sha.(root<>"/"<>p)==h end)
Application.load(:beam_lisp)
{:ok,deps}=:application.get_key(:beam_lisp,:applications)
Enum.each(deps,fn d->{:ok,_}=Application.ensure_all_started(d) end)
:ok=BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
BeamLisp.AOT.boot()
false=:ets.member(:beam_lisp_vars,:bl_sdk_runtime_lease)
true=BeamLisp.AOTCache.current_compiler_key()==inputs["compilerKey"]
true=sha.(main<>"/priv/bootstrap/seed/manifest.term")==inputs["manifestSha256"]
namespace="reload.collection-constructor"
source=BeamLisp.Loader.source_path(namespace)
content=BeamLisp.Loader.read_source(source)
true=sha.(source)==inputs["targetSourceSha256"]
forms=BeamLisp.Reader.read_string(content,source)
requires=apply(BeamLisp.AOT,:capture_ns_decl,[%{},hd(forms)])[namespace][:requires]||[]
start=System.monotonic_time(:microsecond)
Enum.each(requires,fn n->BeamLisp.Loader.ensure_loaded(n) end)
false=:ets.member(:beam_lisp_vars,:bl_sdk_runtime_lease)
IO.inspect(%{requires: requires,microseconds: System.monotonic_time(:microsecond)-start,componentOnly: true},label: "EXPLICIT_ORDINARY_HEADER_SETUP")
# Exactly one observation step replaces a walk only when zero recipes exist.
# This isolated counter state grants no SDK/class/source/execution authority.
observe=fn ->
 key={:empty_recipe_observation,make_ref()}
 Process.put(key,%{remaining: 100000,recipes: %{}})
 try do
  value=BeamLisp.Vector.new(Enum.to_list(1..8192))
  false=apply(BeamLisp.AOT,:constructor_recipe_present!,[value,%{:"counter-frame"=>key}])
  100000-Process.get(key).remaining
 after Process.delete(key) end
end
compile_target=fn label->
 token=BeamLisp.Env.capture()
 start=System.monotonic_time(:microsecond)
 try do
  artifacts=BeamLisp.AOT.compile_source(content,[{:file,source},{:output_dir,root<>"/output-"<>label},{:"stage-sdk?",true}])
  result=%{label: label,status: :pass,namespace: namespace,artifacts: length(artifacts),microseconds: System.monotonic_time(:microsecond)-start}
  IO.inspect(result,label: "ACTUAL_COLLECTION_COMPONENT_RESULT")
  result
 rescue error->
  data=BeamLisp.ExInfo.ex_data(error)
  safe=if is_map(data),do: Map.take(data,[:kind,:detail,:reason,:operation,:"constructor-operation",:"constructor-namespace",:"constructor-macro",:"constructor-call-stack"]),else: nil
  result=%{label: label,status: :refused,namespace: namespace,error: error.__struct__,data: safe,microseconds: System.monotonic_time(:microsecond)-start}
  IO.inspect(result,label: "ACTUAL_COLLECTION_COMPONENT_REFUSAL",limit: :infinity)
  result
 after BeamLisp.Env.bind(token) end
end
baseline_observation=observe.()
baseline=compile_target.("baseline193")
false=:ets.member(:beam_lisp_vars,:bl_sdk_runtime_lease)
start=System.monotonic_time(:microsecond)
{BeamLisp.AOT,path}=BeamLisp.AOT.compile_host_file(root<>"/aot.candidate.bl",[{:module,BeamLisp.AOT},{:output_dir,root<>"/host"},{:source_hash,inputs["candidateSha256"]},{:load?,false}])
bytes=File.read!(path)
{:module,BeamLisp.AOT}=:code.load_binary(BeamLisp.AOT,String.to_charlist(path),bytes)
{:ok,{BeamLisp.AOT,md5}}=:beam_lib.md5(bytes)
^md5=apply(BeamLisp.AOT,:module_info,[:md5])
IO.inspect(%{sourceSha256: inputs["candidateSha256"],artifactSha256: sha.(path),md5: Base.encode16(md5,case: :lower),microseconds: System.monotonic_time(:microsecond)-start},label: "FRESH_ONE_GUARD_AOT_NATIVE_COMPONENT")
candidate_observation=observe.()
IO.inspect(%{scope: :same_immutable8192_vector_private_empty_table_observation_steps,baseline: baseline_observation,candidate: candidate_observation},label: "EXACT_EMPTY_TABLE_COUNTER_COMPARISON")
true=baseline_observation>candidate_observation
true=candidate_observation==1
candidate=compile_target.("candidate")
false=:ets.member(:beam_lisp_vars,:bl_sdk_runtime_lease)
file=root<>"/empty-recipes.direct.bl"
ns="aot-constructor-empty-recipes-test"
BeamLisp.Compiler.eval_string(File.read!(file),BeamLisp.Compiler.new_env(ns),file)
tests=:json.decode(File.read!(root<>"/test-names.json"))
Enum.each(tests["names"],fn name->BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(ns,name),[]) end)
report=BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(ns,"direct-report"),[])
IO.inspect(report,label: "EMPTY_RECIPE_PERMANENT_25_CONTROLS",limit: :infinity)
false=:ets.member(:beam_lisp_vars,:bl_sdk_runtime_lease)
Enum.each(inputs["sources"],fn row->true=sha.(main<>"/"<>row["path"])==row["sha256"] end)
pass=report[:assertions]==25 and report[:pass]==25 and candidate.status==:pass and candidate.artifacts==3 and baseline.status==:refused and baseline.data[:kind]==:"constructor-machine-refused" and baseline.data[:detail]==:"step-budget"
IO.inspect(%{component: :one_guard_empty_recipe_observation,baseline: baseline.status,candidate: candidate.status,controls: 25,accepted: pass,ordinaryStartupAccepted: false},label: "EMPTY_RECIPE_COMPONENT_FINAL")
System.halt(if pass,do: 0,else: 70)
