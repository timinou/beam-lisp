#!/bin/bash
set -euo pipefail
unset BEAM_LISP_EBIN BEAM_LISP_PATH BL_ROOT BL_EBIN BL_BIN BL_BUILD_ID BL_BOOT_REEXECED BL_CONSTRUCTOR_METADATA_ROOT BL_KERNEL_SOURCE_UNDER_TEST BL_REGENERATE_SCRIPT_UNDER_TEST
python3 /home/user/tmp/product-online-20261014/round2/post-floor226-fast-regression-native/preflight.py regression
export BL_FAST_ROOT=/home/user/tmp/product-online-20261014/round2/post-floor226-fast-regression-native
export BL_FAST_MODE=regression
export BL_DIAGNOSTIC=/home/user/tmp/product-online-20261014/round2/post-floor226-fast-regression-native/component.exs
export TMPDIR=/home/user/tmp/product-online-20261014/round2/post-floor226-fast-regression-native/tmp
export BEAM_LISP_AOT_CACHE_DIR=/home/user/tmp/product-online-20261014/round2/post-floor226-fast-regression-native/regression-cache
export BL_DAEMON=off
export BL_AUTOBUILD=off
export BEAM_LISP_EBIN=/home/user/tmp/product-online-20261014/round2/post-floor226-fast-regression-native/images/regression/lib/beam_lisp-0.1.0/ebin
export BL_SEED_SNAPSHOT_BENCHMARK_RECEIPT=/home/user/tmp/product-online-20261014/round2/post-floor226-fast-regression-native/paired-benchmark.json
cd /home/user/code/undefine/beam-lisp
exec /home/user/tmp/product-online-20261014/round2/post-floor226-fast-regression-native/source-wrapper
