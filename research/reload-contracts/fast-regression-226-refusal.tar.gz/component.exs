# Actual installed native floor plus ordinary public compiler fixture evaluation.
home=System.fetch_env!("BL_FAST_ROOT")
main=System.fetch_env!("BL_ROOT")
mode=System.fetch_env!("BL_FAST_MODE")
inputs=:json.decode(File.read!(home<>"/component-inputs.json"))
sha=fn p->Base.encode16(:crypto.hash(:sha256,File.read!(p)),case: :lower) end
Process.put(:component_native_checks,0)
check=fn label,value->
 if value==true,do: Process.put(:component_native_checks,Process.get(:component_native_checks)+1),else: throw({:component_check_failed,label})
end
persist=fn value->
 File.write!(home<>"/"<>mode<>"-progress.json.tmp",:json.encode(value))
 File.rename!(home<>"/"<>mode<>"-progress.json.tmp",home<>"/"<>mode<>"-progress.json")
end
observe=fn ->
 counters=Map.new([{:constructorCompileCalls,{BeamLisp.AOT,:constructor_compile_sdk_unit!,2}},{:cacheRestoreCalls,{BeamLisp.AOT,:restore_sdk_staged_unit!,3}}],fn {key,mfa}->
  n=case :erlang.trace_info(mfa,:call_count) do {:call_count,value} when is_integer(value)->value;_->nil end
  {key,n}
 end)
 if is_pid(Process.get(:diagnostic_sampler)) do
  send(Process.get(:diagnostic_sampler),{:stop,Process.get(:diagnostic_sampler_phase_token),self()})
  receive do :diagnostic_sampler_stopped->:ok after 2000->:ok end
 end
 counters
end
try do
 {_,0}=System.cmd("python3",[home<>"/preflight.py","--verify"])
 Application.load(:beam_lisp)
 {:ok,deps}=:application.get_key(:beam_lisp,:applications)
 Enum.each(deps,fn dep->{:ok,_}=Application.ensure_all_started(dep) end)
 :ok=BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
 BeamLisp.AOT.boot()
 check.("actual-compiler-key",BeamLisp.AOTCache.current_compiler_key()==inputs["compilerKey"])
 check.("actual-build-key",BeamLisp.AOTCache.build_key()==inputs["buildKey"])
 check.("initial-sdk-lease-absent",not :ets.member(:beam_lisp_vars,:bl_sdk_runtime_lease))
 {:ok,[manifest]}=:file.consult(String.to_charlist(main<>"/priv/bootstrap/seed/manifest.term"))
 modules=Map.new(manifest["modules"])
 native=fn ->
  for module<-[BeamLisp.AOT,BeamLisp.AOTCache,BeamLisp.Env,BeamLisp.Emit,BeamLisp.CompilerData,BeamLisp.Ns.Compiler,BeamLisp.Ns.Core,BeamLisp.Ns.Rt] do
   {:module,^module}=Code.ensure_loaded(module)
   {^module,bytes,_}=:code.get_object_code(module)
   check.("actual-seed-object",Base.encode16(:crypto.hash(:sha256,bytes),case: :lower)==Map.fetch!(modules,Atom.to_string(module)<>".beam"))
   {:ok,{^module,md5}}=:beam_lib.md5(bytes)
   check.("actual-loaded-module-md5",md5==apply(module,:module_info,[:md5]))
  end
 end
 native.()
 # Read-only diagnostic: native attribute shape is not SDK declaration authority.
 declaration_observation=for {module,expected_namespace}<-[{BeamLisp.Ns.Core,"core"},{BeamLisp.Ns.Rt,"rt"}] do
  {^module,bytes,_}=:code.get_object_code(module)
  {:ok,{^module,chunks}}=:beam_lib.chunks(bytes,[:attributes])
  attrs=Keyword.fetch!(chunks,:attributes)
  raw=Keyword.get(attrs,:bl_sdk_declarations,:attribute_absent)
  descriptor=case raw do [value]->value;value->value end
  kinds=[:public,:private,:value,:macro,:unavailable]
  shape=case descriptor do
   {1,namespace,entries} when is_binary(namespace) and is_map(entries)->
    byte_size(namespace)>0 and byte_size(namespace)<=512 and map_size(entries)<=8192 and
     Enum.all?(entries,fn {binding,kind}->is_binary(binding) and byte_size(binding)>0 and byte_size(binding)<=512 and kind in kinds end)
   _->false
  end
  status=cond do descriptor==:attribute_absent->:absent;descriptor==nil->:nil;shape->:valid_shape;true->:malformed end
  {namespace_matches,entry_count,counts}=if shape do
   {1,namespace,entries}=descriptor
   {namespace==expected_namespace,map_size(entries),Map.new(kinds,fn kind->{kind,Enum.count(entries,fn {_,value}->value==kind end)} end)}
  else
   {false,0,Map.new(kinds,fn kind->{kind,0} end)}
  end
  reviewed_keys=[:bl_sdk_declarations,:bl_aot_artifact_version,:bl_aot_artifact_role,:bl_unit_source_digest,:bl_declaration_owner]
  %{module: module,attributeKeysPresent: Enum.filter(reviewed_keys,&Keyword.has_key?(attrs,&1)),otherAttributeCount: Enum.count(attrs,fn {key,_}->key not in reviewed_keys end),descriptorStatus: status,namespaceMatchesExpected: namespace_matches,declarationCount: entry_count,kindCounts: counts,authorityGranted: false}
 end
 File.write!(home<>"/"<>mode<>"-boot-declaration-observation.json",:json.encode(%{scope: "Actual installed Core/Rt attribute shape only; no declaration payload and no SDK authority",modules: declaration_observation}))
 IO.inspect(declaration_observation,label: "ACTUAL_BOOT_DECLARATION_ATTRIBUTE_STATUS")
 compile_mfa={BeamLisp.AOT,:constructor_compile_sdk_unit!,2}
 restore_mfa={BeamLisp.AOT,:restore_sdk_staged_unit!,3}
 check.("actual-constructor-counter",:erlang.trace_pattern(compile_mfa,true,[:local,:call_count])==1)
 check.("actual-restore-counter",:erlang.trace_pattern(restore_mfa,true,[:local,:call_count])==1)
 Process.put(:diagnostic_sampler_context,%{home: home,mode: mode,owner: self(),compileMfa: compile_mfa,restoreMfa: restore_mfa,settings: inputs["sampler"]})
 Code.eval_file(home<>"/sampler.exs")
 result=case mode do
  "regression"->
   for role<-["metadata","privacy","snapshot","materializer"] do
    fixture=inputs["fixtures"][role]
    check.("exact-original-fixture",sha.(home<>"/"<>fixture["original"])==fixture["sha256"])
    file=home<>"/"<>fixture["direct"]
    BeamLisp.Compiler.eval_string(File.read!(file),BeamLisp.Compiler.new_env(fixture["namespace"]),file)
    report=fn ->BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(fixture["namespace"],"direct-report"),[]) end
    for name<-fixture["functions"] do
     before=report.();start=System.monotonic_time(:microsecond)
     send(Process.get(:diagnostic_sampler),{:phase,Process.get(:diagnostic_sampler_phase_token),role,name})
     Process.put(:case_returned,false)
     try do
      BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(fixture["namespace"],name),[])
      Process.put(:case_returned,true)
     after
      current=report.();delta=Map.new([:assertions,:passed,:failed],fn k->{k,current[k]-before[k]} end)
      row=%{role: role,caseName: name,returned: Process.get(:case_returned),assertions: delta,elapsedUs: System.monotonic_time(:microsecond)-start}
      Process.put(:case_reports,Process.get(:case_reports,[])++[row])
      Process.put(:fixture_reports,Map.put(Process.get(:fixture_reports,%{}),role,current))
      persist.(%{caseReports: Process.get(:case_reports),fixtureReports: Process.get(:fixture_reports)})
      IO.inspect(row,label: "ACTUAL_COMPONENT_CASE_COUNTERS")
     end
    end
    r=report.();n=fixture["expectedAssertions"]
    check.("exact-native-fixture-assertions",r[:assertions]==n and r[:passed]==n and r[:failed]==0)
   end
   check.("exact-native-case-count",length(Process.get(:case_reports))==inputs["expectedCases"])
   total=Enum.reduce(Process.get(:fixture_reports),0,fn {_,r},n->n+r[:assertions] end)
   check.("exact-native-total-assertions",total==201)
   %{accepted: true,acceptanceRole: "native-component-regressions-only",coreAssertions: total,assertions: Process.get(:fixture_reports),caseReports: Process.get(:case_reports),benchmark: false}
  "benchmark"->
   file=home<>"/benchmark-original.bl"
   check.("exact-paired-benchmark-source",sha.(file)==inputs["benchmark"]["sha256"])
   BeamLisp.Compiler.eval_string(File.read!(file),BeamLisp.Compiler.new_env("sdk-seed-snapshot-benchmark"),file)
   receipt=:json.decode(File.read!(home<>"/paired-benchmark.json"))
   check.("actual-paired-samples",length(receipt["samples"])==8 and receipt["sdkLeaseUnchanged"]==true and receipt["acceptance"]==false)
   for row<-receipt["samples"] do
    check.("actual-manifest-call-count",row["dependencyLookups"]==512 and row["actualManifestCalls"]==if(row["strategy"]=="scoped",do: 2,else: 512))
   end
   %{accepted: false,benchmarkCompleted: true,benchmark: true,benchmarkReceipt: receipt}
 end
 check.("final-sdk-lease-absent",not :ets.member(:beam_lisp_vars,:bl_sdk_runtime_lease))
 {_,0}=System.cmd("python3",[home<>"/preflight.py","--verify"])
 native.()
 result=Map.merge(result,Map.merge(observe.(),%{mode: mode,sdkAccepted: false,automaticColdWarmAccepted: false,normalCLIOrProductAccepted: false,nativeChecks: Process.get(:component_native_checks),scope: inputs["scope"]}))
 File.write!(home<>"/"<>mode<>"-result.json",:json.encode(result))
 IO.inspect(Map.drop(result,[:caseReports,:benchmarkReceipt]),label: "POST_FLOOR225_COMPONENT_RESULT")
 IO.puts(if(mode=="regression",do: "FAST_REGRESSION_201_FINISHED",else: "PAIRED_NATIVE_MANIFEST_BENCHMARK_FINISHED"))
 System.halt(0)
rescue
 error->
  raw=if is_map(error),do: Map.get(error,:data),else: nil
  kind=if is_map(raw),do: Map.get(raw,:kind),else: nil
  diagnostic=if is_atom(kind),do: kind,else: :unclassified
  stack=Enum.take(__STACKTRACE__,12)|>Enum.map(fn {m,f,a,_}->%{module: m,function: f,arity: if(is_integer(a),do: a,else: length(a))} end)
  result=Map.merge(observe.(),%{accepted: false,mode: mode,errorClass: error.__struct__,diagnostic: diagnostic,stack: stack,caseReports: Process.get(:case_reports,[]),fixtureReports: Process.get(:fixture_reports,%{}),sdkAccepted: false,nativeChecks: Process.get(:component_native_checks)})
  File.write!(home<>"/"<>mode<>"-result.json",:json.encode(result));IO.inspect(result,label: "ACTUAL_COMPONENT_FAILURE");System.halt(70)
catch
 kind,reason->
  code=case reason do {:component_check_failed,label}->label;_->"unclassified" end
  result=Map.merge(observe.(),%{accepted: false,mode: mode,errorKind: kind,code: code,caseReports: Process.get(:case_reports,[]),fixtureReports: Process.get(:fixture_reports,%{}),sdkAccepted: false,nativeChecks: Process.get(:component_native_checks)})
  File.write!(home<>"/"<>mode<>"-result.json",:json.encode(result));IO.inspect(result,label: "ACTUAL_COMPONENT_FAILURE");System.halt(70)
end
