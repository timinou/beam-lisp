#!/usr/bin/env python3
"""Read-only frozen controls, accepted floor and physical Source/native checks."""
from pathlib import Path
import hashlib,json,os,subprocess,sys
HERE=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def rows(root,values):
 for r in values:
  f=root/r['path'];s=f.stat()
  assert (sha(f),s.st_dev,s.st_ino,f.lstat().st_mode&0o777)==(r['sha256'],r['device'],r['inode'],r['mode']),'Physical input drift: '+r['path']
  assert ('linkTarget' in r)==f.is_symlink()
  if f.is_symlink():assert os.readlink(f)==r['linkTarget']
x=json.loads((HERE/'component-inputs.json').read_text());main=Path(x['main'])
for key in ['floorInputs','floorResult','floorLog']:assert sha(x[key])==x[key+'Sha256']
parent=json.loads(Path(x['floorResult']).read_text());assert parent['exitCode']==0 and parent.get('success',True) is True and not parent.get('receivedSignals',[])
for n,d in x['files'].items():assert sha(HERE/n)==d,'Frozen control drift: '+n
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=main,text=True).strip()==x['sourceCommit']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=main)
tracked=sorted(p for p in subprocess.check_output(['git','ls-files','-z'],cwd=main).decode().split('\0') if p)
assert tracked==[r['path'] for r in x['trackedMain']]
rows(main,x['trackedMain']);rows(main,x['sources']);rows(main,x['nativeAssets']);rows(main/'priv/bootstrap/seed',x['seed']);assert len(x['seed'])==104
assert sorted(str(p.relative_to(main/'priv/bootstrap/seed')) for p in (main/'priv/bootstrap/seed').rglob('*') if p.is_file())==[r['path'] for r in x['seed']]
actual={str(p.relative_to(main)) for p in (main/'priv').rglob('*') if p.is_file() and p.name.endswith(tuple(x['sourceExtensions']))};expected={r['path'] for r in x['sources'] if r['path'].startswith('priv/') and r['path'].endswith(tuple(x['sourceExtensions']))};assert actual==expected
if sys.argv[1:]!=['--verify']:
 assert len(sys.argv)==2 and sys.argv[1] in ['regression','benchmark'];mode=sys.argv[1]
 if mode=='benchmark':
  result=json.loads((HERE/'regression-result.json').read_text());assert result['accepted'] is True and result['coreAssertions']==201 and result['sdkAccepted'] is False
  receipts=list(HERE.glob('*regression*-parent.json'));assert len(receipts)==1,'Actual successful Root-owned regression parent required before paired benchmark'
  r=json.loads(receipts[0].read_text());assert r['exitCode']==0 and r['success'] is True and not r.get('receivedSignals',[])
  assert r['command'][-1]==str(HERE/'regression.sh') and r['scriptSha256']==sha(HERE/'regression.sh')
  logs=[v.removeprefix('--property=StandardOutput=append:') for v in r['command'] if v.startswith('--property=StandardOutput=append:')];assert len(logs)==1 and r['logSha256']==sha(logs[0])
  assert Path(logs[0]).read_text().splitlines()[-1]=='FAST_REGRESSION_201_FINISHED'
 assert not list((HERE/(mode+'-cache')).iterdir()),'Fresh empty component cache required'
 assert not list((HERE/'images'/mode/'lib/beam_lisp-0.1.0/ebin').iterdir()),'Fresh native image required'
 with (HERE/(mode+'-started.json')).open('x') as f:json.dump({'mode':mode,'inputsSha256':sha(HERE/'component-inputs.json'),'cacheInitialFiles':0,'sdkAccepted':False},f)
print(json.dumps({'preflight':'PASS','VMsLaunched':0,'sourceCommit':x['sourceCommit'],'compilerKey':x['compilerKey']}))
