Application.load(:beam_lisp)
{:ok, deps} = :application.get_key(:beam_lisp, :applications)
Enum.each(deps, fn dep -> {:ok, _} = Application.ensure_all_started(dep) end)
:ok = BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
BeamLisp.AOT.boot()
root = System.fetch_env!("BL_PROBE_ROOT")
# Reuse the exact Compiler artifacts produced and hashed by native106.
# This is a diagnostic overlay, never a coherent-floor acceptance.
for module <- [BeamLisp.Ns.Compiler, BeamLisp.Ns.Body.Compiler, BeamLisp.Ns.Init.Compiler] do
 artifact = "/home/user/tmp/product-online-20261014/round2/compiler-metadata-native-127/compiler-beams/" <> Atom.to_string(module) <> ".beam"
 {:module, ^module} = :code.load_binary(module, String.to_charlist(artifact), File.read!(artifact))
 IO.inspect({module, Base.encode16(:crypto.hash(:sha256, File.read!(artifact)), case: :lower)}, label: "REUSED_NATIVE_COMPILER")
end
for module <- [BeamLisp.SourceGraph, BeamLisp.NamespaceInterface] do
 artifact = "/home/user/tmp/product-online-20261014/round2/constructor-context-117/host/" <> Atom.to_string(module) <> ".beam"
 {:module, ^module} = :code.load_binary(module, String.to_charlist(artifact), File.read!(artifact))
end
for {module, directory} <- [{BeamLisp.BuildPlan, "constructor-context-119/host"}, {BeamLisp.AOT, "constructor-reader-native-123/host"}, {:"Elixir.BeamLisp.Ns.Reader-node", "constructor-reader-native-123/reader-beams"}, {:"Elixir.BeamLisp.Ns.Body.Reader-node", "constructor-reader-native-123/reader-beams"}, {BeamLisp.Ns.Reader, "constructor-reader-native-123/reader-beams"}, {BeamLisp.Ns.Body.Reader, "constructor-reader-native-123/reader-beams"}, {BeamLisp.Ns.Init.Reader, "constructor-reader-native-123/reader-beams"}] do
 artifact = "/home/user/tmp/product-online-20261014/round2/" <> directory <> "/" <> Atom.to_string(module) <> ".beam"
 {:module, ^module} = :code.load_binary(module, String.to_charlist(artifact), File.read!(artifact))
 IO.inspect({module, Base.encode16(:crypto.hash(:sha256, File.read!(artifact)), case: :lower)}, label: "EXACT_NATIVE_ARTIFACT")
end
for module <- [BeamLisp.CompilerData, BeamLisp.AOT] do
 artifact = "/home/user/tmp/product-online-20261014/round2/constructor-integrated-native-144/host/" <> Atom.to_string(module) <> ".beam"
 {:module, ^module} = :code.load_binary(module, String.to_charlist(artifact), File.read!(artifact))
 IO.inspect({module, Base.encode16(:crypto.hash(:sha256, File.read!(artifact)), case: :lower)}, label: "REUSED_NATIVE_144_ARTIFACT")
end
# Diagnostic only. Trace arities and caller MFAs, never arguments/return values.
# https://www.erlang.org/doc/apps/erts/match_spec.html
# https://www.erlang.org/doc/apps/kernel/trace.html
for mod <- [BeamLisp.Env, BeamLisp.Refs, BeamLisp.Server, BeamLisp.Supervisor,
            BeamLisp.CompilerData, BeamLisp.AOT, BeamLisp.LazyMemo, BeamLisp.LazySeq] do
  path = :code.which(mod)
  digest = if is_list(path) and File.regular?(List.to_string(path)),
    do: Base.encode16(:crypto.hash(:sha256, File.read!(List.to_string(path))), case: :lower), else: nil
  IO.inspect({mod, mod.module_info(:md5), digest}, label: "ACTUAL_MODULE_IDENTITY")
end
snapshot = fn ->
  stats = BeamLisp.LazyMemo.stats()
  numeric = if is_map(stats), do: Map.new(Enum.filter(stats, fn {_k,v} -> is_number(v) or is_boolean(v) end)), else: stats
  %{memo: numeric, retained: BeamLisp.LazyMemo.retained_bytes(),
    reserved: BeamLisp.LazyMemo.reserved_bytes(),
    collector: BeamLisp.LazyMemo.collector_status(),
    memory: :erlang.memory(:total)}
end
IO.inspect(snapshot.(), label: "BASELINE_COUNTERS", limit: :infinity)
tracer = spawn(fn ->
  loop = fn loop, counts, total, dropped ->
    receive do
      {:trace, tracee, :call, {m,f,a}, caller} when is_integer(a) ->
        key = {{m,f,a}, caller}
        full = total >= 20000 or (map_size(counts) >= 256 and not Map.has_key?(counts,key))
        if full, do: :erlang.trace(tracee, false, [:call])
        next = if full, do: counts, else: Map.update(counts,key,1,&(&1+1))
        loop.(loop,next,total+1,dropped or full)
      {:snapshot, from, ref} ->
        rows = Enum.map(counts, fn {k,v} -> {k,v} end) |> Enum.sort_by(&elem(&1,1), :desc)
        send(from,{ref,%{events: total, truncated: dropped, callers: rows}})
        loop.(loop,counts,total,dropped)
      :stop -> :ok
      _ -> loop.(loop,counts,total,dropped)
    end
  end
  loop.(loop,%{},0,false)
end)
patterns = [{BeamLisp.LazyMemo,:new,3}, {BeamLisp.LazySeq,:new,1},
            {BeamLisp.LazySeq,:chain,2}, {BeamLisp.LazySeq,:input,1},
            {BeamLisp.Ns.Body.Rt,:"lazy-map",:_},
            {BeamLisp.Ns.Body.Rt,:"lazy-filter",:_},
            {BeamLisp.Ns.Body.Core,:chunked,:_}]
for mfa <- patterns do
  IO.inspect({mfa,:erlang.trace_pattern(mfa,[{:_,[],[{:message,{:caller}}]}],[:local])}, label: "TRACE_PATTERN")
end
run = fn label, action, deadline ->
  IO.inspect({label,snapshot.()}, label: "PROFILE_START", limit: :infinity)
  started = System.monotonic_time(:millisecond)
  parent = self()
  {pid,ref} = spawn_monitor(fn ->
    :erlang.trace(self(),true,[:call,:arity,{:tracer,tracer}])
    result = try do
      {:ok,action.()}
    rescue error ->
      data = BeamLisp.ExInfo.ex_data(error)
      safe = if is_map(data), do: Map.take(data,[:kind,:reason]), else: nil
      {:error,error.__struct__,safe}
    catch kind,_ -> {:caught,kind}
    end
    send(parent,{:profile_result,self(),result})
    receive do :ack -> :ok after 5000 -> :ok end
  end)
  outcome = receive do
    {:profile_result,^pid,result} ->
      delivered = :erlang.trace_delivered(pid)
      receive do {:trace_delivered,^pid,^delivered} -> :ok after 2000 -> :ok end
      send(pid,:ack)
      receive do {:DOWN,^ref,:process,^pid,reason} -> {result,reason} after 5000 -> :missing_down end
    {:DOWN,^ref,:process,^pid,reason} -> {:unexpected_down,reason}
  after deadline ->
    Process.exit(pid,:kill)
    receive do {:DOWN,^ref,:process,^pid,:killed} -> :ok after 5000 -> :ok end
    :deadline
  end
  :erlang.garbage_collect()
  Process.sleep(50)
  trace_ref = make_ref()
  send(tracer,{:snapshot,self(),trace_ref})
  trace = receive do {^trace_ref,trace} -> trace after 2000 -> :missing_trace end
  IO.inspect({label,%{elapsed_ms: System.monotonic_time(:millisecond)-started,
                    result: outcome, counters: snapshot.(), trace: trace}},
             label: "PROFILE_RESULT", limit: :infinity)
end
try do
  run.("validate-eager-vector8192",fn ->
    value = BeamLisp.Vector.new(Enum.to_list(1..8192))
    {us,result} = :timer.tc(fn -> BeamLisp.CompilerData.check_first_order!(value) end)
    %{us: us, size: BeamLisp.Vector.count(result)}
  end,60000)
  run.("canonical-set-reserved-member",fn ->
    value = BeamLisp.Set.new([:__struct__])
    members = Map.fetch!(Map.fetch!(value,:members),:map)
    result = try do BeamLisp.CompilerData.check_first_order!(value); :accepted
             rescue e -> {:refused,Map.take(BeamLisp.ExInfo.ex_data(e),[:kind,:reason])} end
    %{result: result, native_membership_value: Map.fetch!(members,:__struct__)}
  end,10000)
  run.("capsule-negative-raw-put",fn ->
    frame = {:constructor_machine_frame,make_ref()}
    capsule = %{:"constructor-frame" => frame, :"constructor-id" => 1, __struct__: BeamLisp.LazySeq}
    proof = %{:"recipe-frame" => frame, callables: %{}, recipes: %{1 => %{kind: :thunk}}}
    for {key,value} <- [{:"constructor-frame",make_ref()},{:"constructor-id",2},{:extra,:field}] do
      try do BeamLisp.CompilerData.constructor_data_cost!(Map.put(capsule,key,value),proof); :unexpected_accept
      rescue e -> Map.take(BeamLisp.ExInfo.ex_data(e),[:kind,:reason]) end
    end
  end,10000)
  run.("metadata-and-captured-fun-hashing",fn ->
    {metadata_us,metadata} = :timer.tc(fn ->
      BeamLisp.AOT.constructor_metadata(%{"core" => BeamLisp.Env.ns_defs("core")},%{})
    end)
    small = fn x -> {x,:small} end
    large = fn x -> {x,metadata} end
    measure = fn f ->
      table = %{f => true}
      {hash_us,hashsum} = :timer.tc(fn -> Enum.reduce(1..100,0,fn _,a -> a+:erlang.phash2(f) end) end)
      {lookup_us,ok} = :timer.tc(fn -> Enum.all?(1..100,fn _ -> Map.has_key?(table,f) end) end)
      %{hash_us: hash_us, lookup_us: lookup_us, hash_checksum: hashsum, correct: ok,
        flat_words: :erts_debug.flat_size(f)}
    end
    %{metadata_us: metadata_us, globals: map_size(metadata.globals), remotes: map_size(metadata.remotes),
      small: measure.(small), large: measure.(large)}
  end,60000)
  run.("compile-stream-fixture",fn ->
    file = root <> "/stream.direct.bl"
    BeamLisp.Compiler.eval_string(File.read!(file),BeamLisp.Compiler.new_env("aot-derived-stream-test"),file)
    :compiled
  end,60000)
  for name <- ["completed-cells-and-full-folds-memoize-the-producer",
               "short-fold-and-concat-boundary-do-not-run-unused-producers",
               "direct-source-reduce-uses-the-same-demanded-chunk-as-native-reduce"] do
    run.(name,fn ->
      BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!("aot-derived-stream-test",name),[])
      report = BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!("aot-derived-stream-test","direct-report"),[])
      Map.take(report,[:pass,:assertions])
    end,60000)
  end
after
  for mfa <- patterns, do: :erlang.trace_pattern(mfa,false,[:local])
  send(tracer,:stop)
end
IO.puts("PROFILE_COMPLETED_DIAGNOSTIC_ONLY")
