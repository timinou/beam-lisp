root=System.fetch_env!("BL_PROBE_ROOT")
x=:json.decode(File.read!(root<>"/inputs.json"))
sha=fn bytes -> Base.encode16(:crypto.hash(:sha256,bytes),case: :lower) end
false=:ets.member(:beam_lisp_vars,:bl_sdk_runtime_lease)
0=:ets.info(:beam_lisp_owner_index,:size)
owner=Process.whereis(BeamLisp.Env)
Enum.each(x["official"]["tables"],fn row ->
 table=String.to_existing_atom(row["name"])
 true=:ets.info(table,:owner)==owner
 true=Atom.to_string(:ets.info(table,:protection))==row["protection"]
 true=Atom.to_string(:ets.info(table,:type))==row["type"]
end)
false=BeamLisp.Env.native_command_critical_active?()
Enum.each(x["failed249"]["hosts"],fn row ->
 if row["module"] != "Elixir.BeamLisp.LazyMemo" do
  module=String.to_existing_atom(row["module"])
  actualWhich=:code.which(module)
  actualPath=if is_list(actualWhich),do: List.to_string(actualWhich),else: Atom.to_string(actualWhich)
  bytes=File.read!(row["copy"])
  {:ok,{^module,md5}}=:beam_lib.md5(bytes)
  loadedMD5=module.module_info(:md5)
  fileSHA=sha.(bytes)
  IO.inspect(%{module: row["module"],actualWhich: actualPath,expectedWhich: row["copy"],whichMatches: actualPath == row["copy"],fileSHA: fileSHA,shaMatches: fileSHA == row["artifact"]["sha256"],fileMD5: Base.encode16(md5,case: :lower),loadedMD5: Base.encode16(loadedMD5,case: :lower),md5Matches: md5 == loadedMD5},label: "ACTUAL_LOADED_HOST_PATH_MD5_OBSERVATION")
  true=actualPath == row["copy"]
  true=fileSHA == row["artifact"]["sha256"]
  true=md5 == loadedMD5
 end
end)
IO.inspect(%{tables: 17,loadedHosts: 15,sourceCurrentCoreDefinitions: map_size(BeamLisp.Env.ns_defs("core")),sdkLease: false},label: "ACTUAL_FRESH_NATIVE_DIAGNOSTIC_CONTEXT")
# Run the original committed test bodies and unchanged genuine adapters.
Code.eval_file(root<>"/unit-native-preflight.exs")
proof=:json.decode(File.read!(root<>"/unit-preflight.json"))
true=proof["tests"] == 8 and proof["assertions"] == 53 and proof["failed"] == 0
false=:ets.member(:beam_lisp_vars,:bl_sdk_runtime_lease)
0=:ets.info(:beam_lisp_owner_index,:size)
result=%{diagnosticCompleted: true,acceptedAsFloor: false,acceptedAsSDK: false,sdkLeaseFabricated: false,sourceCommit: x["sourceCommit"],compilerKey: x["compilerKey"],inputSha256: sha.(File.read!(root<>"/inputs.json")),hostsValidatedBeforeLoad: 16,currentNativeHostsLoaded: 15,actualEnvOwnedTables: 17,originalFixtureSource: true,originalTestRTNamespaceRuns: true,seedPublished: false,tests: proof["tests"],assertions: proof["assertions"],failed: proof["failed"],testGroups: %{seed: proof["seed"],bootstrap: proof["bootstrap"]}}
File.write!(root<>"/diagnostic-result.json",:json.encode(result))
{_,0}=System.cmd("python3",[root<>"/preflight.py","after","0"])
IO.puts("FAST_SEED_UNIT_TESTS_8_53_FINISHED_NOT_FLOOR_ACCEPTANCE")
System.halt(0)
