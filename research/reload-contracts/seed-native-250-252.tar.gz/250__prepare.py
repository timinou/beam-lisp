#!/usr/bin/env python3
"""HOME-only fast diagnostic freeze. No native launch, Main mutation or floor acceptance."""
from pathlib import Path
import argparse,json,os,shutil
import controls as c
H=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args()
assert not c.git('status','--porcelain')
observed=c.failed249();recovery=c.recovery();transition=c.native_transition();historical=c.accepted226(False);incomplete=c.incomplete243();official=c.official_contract()
out=a.output.resolve();assert out.is_relative_to(c.R2) and not out.exists();out.mkdir(mode=0o700)
for name in ['controls.py','prepare.py','preflight.py','component.exs','adapter.exs','diagnostic.exs','run.sh','PLAN.org']:shutil.copyfile(H/name,out/name)
for name in ['fresh-hosts','ebin','aot-cache','tmp']:(out/name).mkdir()
for row in observed['hosts']:
 dest=out/'fresh-hosts'/row['file'];shutil.copyfile(row['artifact']['path'],dest);assert c.sha(dest)==row['artifact']['sha256'];row['copy']=str(dest)
for row in observed['cache']:
 src=c.FAILED249/'aot-cache'/row['path'];dest=out/'aot-cache'/row['path'];dest.parent.mkdir(parents=True,exist_ok=True)
 fd=os.open(src,os.O_RDONLY|os.O_NOFOLLOW)
 with os.fdopen(fd,'rb') as inp,dest.open('xb') as target:shutil.copyfileobj(inp,target,1048576)
 assert c.sha(dest)==row['sha256']
assert c.cache_files(out/'aot-cache')==observed['cache']
original=c.MAIN/'scripts/regenerate-seed.bl';derived,proof=c.derive_fast(original.read_text(),observed['hosts'],out/'adapter.exs');(out/'diagnostic-regenerate.bl').write_text(derived)
launcher=(c.MAIN/'bin/bl').read_text();root_seam='ROOT=$(CDPATH=\'\' cd "$(dirname "$0")/.." && pwd -P)';exec_seam='exec elixir $PA -e \'BeamLisp.Launcher.main()\' -- "$@"'
assert launcher.count(root_seam)==launcher.count(exec_seam)==1
(out/'source-bootstrap-wrapper').write_text(launcher.replace(root_seam,'ROOT='+str(c.SUBSTRATE)).replace(exec_seam,'exec elixir $PA -e \'Code.eval_file(System.fetch_env!("BL_DIAGNOSTIC"))\' -- "$@"'))
compiler,build,codegen=c.keys();observed_base={**observed,'hosts':[{k:v for k,v in r.items() if k!='copy'} for r in observed['hosts']]};assert c.failed249()==observed_base
x={'state':'FROZEN_DIAGNOSTIC_NATIVE_UNRUN','acceptedAsFloor':False,'acceptedAsSDK':False,'sourceCommit':c.git('rev-parse','HEAD').decode().strip(),'compilerKey':compiler,'buildKey':build,'codegenDigest':codegen,'failed249':observed,'recovery':recovery,'nativeTransition':transition,'historical226':historical,'incomplete243':incomplete,'official':official,'derivation':{'original':c.dependency(original),**proof},'tracked':[c.record(c.MAIN/n,c.MAIN) for n in c.tracked_paths()],'sources':[c.record(c.MAIN/n,c.MAIN) for n in c.physical_source_paths()],'nativeAssets':[c.record(c.MAIN/n,c.MAIN) for n in c.native_paths()],'initialSeed':[c.record(f,c.MAIN) for f in (c.MAIN/'priv/bootstrap/seed').iterdir() if f.is_file()],'files':{f.name:c.sha(f) for f in out.iterdir() if f.is_file()},'VMsLaunched':0,'scope':'Actual249 untrusted Source-produced16Hosts revalidated before15loads; genuine193; actual17table init; normal13canonicalAOTrestore; trustedNative originalfixture diagnostics only; no70Host/seed/check/install or SDK/floor acceptance'}
(out/'inputs.json').write_text(json.dumps(x,indent=2)+'\n');(out/'inputs.sha256').write_text(c.sha(out/'inputs.json')+'  inputs.json\n')
for name in ['run.sh','source-bootstrap-wrapper','prepare.py','preflight.py']:(out/name).chmod(0o700)
print(json.dumps({'ready':str(out),'inputsSha256':c.sha(out/'inputs.json'),'sourceCommit':x['sourceCommit'],'compilerKey':compiler,'buildKey':build,'diagnosticOnly':True,'native':'UNRUN'}))
