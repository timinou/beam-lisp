"""Finite read-only floor controls. No BL/Elixir, native launch or Main mutation."""
from pathlib import Path
import hashlib,json,os,re,stat,subprocess,tarfile
R2=Path('/home/user/tmp/product-online-20261014/round2')
MAIN=Path('/home/user/code/undefine/beam-lisp')
FLOOR=R2/'coherent-floor-226-ready'
SUBSTRATE=R2/'coherent-floor-225-ready/substrate'
SEED_COMMIT='dc03f68a6c13434ded169a4106ba2595ccc94561'
NATIVE_TRANSITION=R2/'fjall-source-decoder233/native-transition237.json'
NATIVE_TRANSITION_SHA='3cc27f8527862a24f0966998e421590ef1a040e133df2b6c91b9aa7b0a84cec7'
ENV_ARCHIVE_SHA='98c2b3dbecc7d0bd426f859ba98c9fc4f601d8750f93d221fa780116248bf096'
ENV_MANIFEST_SHA='36115fd813012680fab8f195a9e58b39367d35bfa6d689aa63eb44bb767cc4d2'
SOURCE_EXTENSIONS=('.bl','.bl.md','.bl.org','.clj','.cljc','.rs','.ex','.exs','.py','.sh','.js','.mjs','.c','.h')
SKIP={'.git','.bl','build','_build','deps','node_modules','target','__pycache__'}
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  while b:=f.read(1048576):h.update(b)
 return h.hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=MAIN)
def record(path,base):
 path=Path(path);s=path.stat();l=path.lstat()
 assert stat.S_ISREG(s.st_mode),'Nonregular input: '+str(path)
 r={'path':str(path.relative_to(base)),'sha256':sha(path),'mode':l.st_mode&0o777,'device':s.st_dev,'inode':s.st_ino,'bytes':s.st_size}
 if path.is_symlink():r.update(linkTarget=os.readlink(path),linkDevice=l.st_dev,linkInode=l.st_ino,resolvedPath=str(path.resolve()))
 return r
def verify_rows(base,rows):
 for r in rows:assert record(Path(base)/r['path'],Path(base))==r,'Physical input drift: '+r['path']
def seed_paths(base):
 files=sorted(p for p in Path(base).rglob('*') if p.is_file() or p.is_symlink())
 assert len(files)==104 and all(p.is_file() and not p.is_symlink() for p in files),'Exactly104 regular seed files required'
 return files
def physical_source_paths():
 paths=set()
 for base in ['priv','lib','native','scripts','bin','test','examples','research','docs','!tasks']:
  root=MAIN/base
  if not root.exists():continue
  for parent,dirs,files in os.walk(root,followlinks=False):
   dirs[:]=sorted(d for d in dirs if d not in SKIP)
   for name in files:
    p=Path(parent)/name
    if name.endswith(SOURCE_EXTENSIONS) or name in ['Cargo.toml','Cargo.lock','build.rs'] or base=='bin':paths.add(str(p.relative_to(MAIN)))
 return sorted(paths|{'env.bl'})
def tracked_paths():return sorted(n for n in git('ls-files','-z').decode().split('\0') if n and not n.startswith('priv/bootstrap/seed/'))
def native_paths():return sorted(str(p.relative_to(MAIN)) for p in (MAIN/'priv/native').rglob('*') if p.is_file() or p.is_symlink())
def dependency(path):return {'path':str(path),'sha256':sha(path)}
def verify_dependency(d):assert sha(d['path'])==d['sha256'],'Dependency drift: '+d['path']
def accepted226(require_installed=True):
 names={'inputs':'inputs.json','parent':'bl-coherent-floor-226-parent.json','script':'command.sh','log':'bl-coherent-floor-226.log','journal':'bl-coherent-floor-226-journal.jsonl'}
 p=json.loads((FLOOR/names['parent']).read_text())
 assert p['exitCode']==0 and p['success'] is True and p['serviceResult']=='success' and p['receivedSignals']==[]
 assert p['scriptSha256']==sha(FLOOR/names['script']) and p['logSha256']==sha(FLOOR/names['log']) and p['journalSha256']==sha(FLOOR/names['journal'])
 assert 'FINAL_COHERENT_FLOOR_BUILD_CHECK_INSTALL_FINISHED' in (FLOOR/names['log']).read_text()
 frozen=json.loads((FLOOR/'inputs.json').read_text())
 assert frozen['expected_compiler_key']=='ac9000d6393852f5352bc786a6f60f1bb8efef2aba7052ea701990a56d5e06a0'
 rows=[{'path':str(f.relative_to(FLOOR/'seed')),'sha256':sha(f)} for f in seed_paths(FLOOR/'seed')]
 assert sha(FLOOR/'seed/manifest.term')=='e5954b86c68cf5b3abede62263acdbb6fcce7c6aa16a21c173d65ee2d2a28af5'
 current=MAIN/'priv/bootstrap/seed'
 if require_installed:assert [str(p.relative_to(current)) for p in seed_paths(current)]==[r['path'] for r in rows]
 for r in rows:
  if require_installed:assert sha(current/r['path'])==r['sha256'],'Installed seed is not actual accepted226'
  assert hashlib.sha256(git('show',SEED_COMMIT+':priv/bootstrap/seed/'+r['path'])).hexdigest()==r['sha256'],'Committed accepted226 seed mismatch'
 assert subprocess.run(['git','merge-base','--is-ancestor',SEED_COMMIT,'HEAD'],cwd=MAIN).returncode==0
 return {'directory':str(FLOOR),'dependencies':{k:dependency(FLOOR/n) for k,n in names.items()},'installedSeedCommit':SEED_COMMIT,'seed':rows,'compilerKey':frozen['expected_compiler_key'],'claim':'Actual accepted226 historical parent + committed104 seed; uninstalled historical input evidence, not current Source acceptance'}
def historical_env235():
 base=MAIN/'research/reload-contracts';archive=base/'env-native-234-235.tar.gz';manifest=base/'env-native-234-235-manifest.json';receipt=base/'env-native-234-235.json'
 assert sha(archive)==ENV_ARCHIVE_SHA and sha(manifest)==ENV_MANIFEST_SHA
 manifest_data=json.loads(manifest.read_text());index={r['path']:r for r in manifest_data['files']}
 with tarfile.open(archive,'r:gz') as t:
  members=t.getmembers();assert len(members)==len(index)==28 and sum(m.size for m in members)<16*1024*1024
  data={}
  for member in members:
   assert member.isfile() and '/' not in member.name and member.name in index
   raw=t.extractfile(member).read();assert len(raw)==index[member.name]['bytes'] and hashlib.sha256(raw).hexdigest()==index[member.name]['sha256'];data[member.name]=raw
 p=json.loads(data['235-bl-env-source-probe235-parent.json']);r=json.loads(data['235-probe-result.json'])
 assert p['exitCode']==0 and p['success'] is True and p['serviceResult']=='success' and p['receivedSignals']==[]
 for field,name in [('scriptSha256','235-probe.sh'),('logSha256','235-bl-env-source-probe235.log'),('journalSha256','235-bl-env-source-probe235-journal.jsonl')]:assert p[field]==hashlib.sha256(data[name]).hexdigest()
 assert r['componentDiagnosticPassed'] is True and r['nativeChecks']==128 and r['externalTablesCreated']==0 and r['canonicalModuleReplaced'] is False and r['temporaryOwnerStopped'] is True
 assert len(r['tableEvidence'])==17 and all(x['ownerActual'] for x in r['tableEvidence'])
 assert {kind:sum(v['protection']==kind for v in r['tableEvidence']) for kind in ['private','protected','public']}=={'private':11,'protected':2,'public':4}
 return {'archive':dependency(archive),'manifest':dependency(manifest),'receipt':dependency(receipt),'nativeChecks':128,'tables':17,'candidateSha256':hashlib.sha256(data['235-env.candidate.bl']).hexdigest(),'claim':'Historical independent Env initializer proof only; final current Env/SDK still UNRUN'}
def recovery():
 dep=json.loads((FLOOR/'substrate-dependency.json').read_text());spec=json.loads((FLOOR/'substrate-inputs.json').read_text());frozen=json.loads((FLOOR/'substrate-tree.json').read_text())
 assert dep['directory']==str(SUBSTRATE) and spec['substrateCommit']=='08324189e82d51275bdfbb39a76076ee9879dcb4'
 assert sha(dep['attemptInputs'])==dep['attemptInputsSha256'] and sha(dep['inventoryFile'])==dep['inventorySha256']
 assert sha(SUBSTRATE/'priv/bootstrap/seed/manifest.term')==spec['expectedManifestSha256']
 paths=sorted(p for p in SUBSTRATE.rglob('*') if (p.is_file() or p.is_symlink()) and p.relative_to(SUBSTRATE).parts[0] not in ['build','.bl'])
 actual=[]
 for p in paths:
  r={'path':str(p.relative_to(SUBSTRATE)),'kind':'symlink' if p.is_symlink() else 'file','mode':p.lstat().st_mode&0o777,'sha256':sha(p)}
  if p.is_symlink():r['target']=os.readlink(p)
  actual.append(r)
 assert actual==[{k:v for k,v in r.items() if k!='bytes'} for r in frozen],'Genuine recovery193 tree drift'
 return {'directory':str(SUBSTRATE),'commit':spec['substrateCommit'],'dependencies':[dependency(FLOOR/n) for n in ['substrate-inputs.json','substrate-tree.json','substrate-dependency.json']]+[dependency(dep['attemptInputs']),dependency(dep['inventoryFile'])],'physicalTree':[record(p,SUBSTRATE) for p in paths],'assets':spec['assets'],'runtimeStagingExcluded':['build','.bl'],'claim':'One unchanged genuine193 physical recovery; no Source copy/worktree/ref/SDK lease'}
def native_transition(path=NATIVE_TRANSITION):
 path=Path(path);assert sha(path)==NATIVE_TRANSITION_SHA,'Require exact Root-reviewed237 receipt'
 r=json.loads(path.read_text());assert r['schema']=='beam-lisp.native-asset-transition/v1' and r['artifactPath']=='priv/native/datom_fjall.so'
 for key in ['parent','journal']:assert sha(r[key+'Path'])==r[key+'Sha256']
 p=json.loads(Path(r['parentPath']).read_text());assert p['parentExitCode']==0 and p['serviceResult']=='success' and p['swapBytes']==0 and p['command']==['cargo','build','--release','--locked','--offline']
 assert p['artifactSha256']==r['newSha256']==sha(r['compiledArtifactPath'])==sha(MAIN/r['artifactPath'])
 assert (MAIN/r['artifactPath']).stat().st_ino==r['newInode']!=r['oldInode'] and (MAIN/r['artifactPath']).stat().st_size==p['artifactBytes']
 assert sha(SUBSTRATE/r['artifactPath'])==r['oldSha256']
 assert all(r[k] is True for k in ['componentCases17Passed','recoverySubstrateUnchanged','atomicDifferentInodeInstall'])
 assert sha(MAIN/r['componentRecord'])==r['componentRecordSha256']
 journal=[json.loads(line) for line in Path(r['journalPath']).read_text().splitlines()]
 start=[int(row['__REALTIME_TIMESTAMP']) for row in journal if row.get('USER_INVOCATION_ID')==p['invocationID'] and row.get('USER_UNIT')==p['unit'] and row.get('MESSAGE','').startswith('Started ')]
 assert len(start)==1 and any(row.get('_SYSTEMD_INVOCATION_ID')==p['invocationID'] for row in journal)
 for s in r['sourceInputs']:
  assert s['mtimeBeforeObservedServiceStart'] is True and s['matchesTrackedSource'] is True
  f=MAIN/s['path'];assert sha(f)==s['sha256']==hashlib.sha256(git('show',r['sourceCommitObserved']+':'+s['path'])).hexdigest()
  assert f.stat().st_mtime_ns<=start[0]*1000,'Rust source postdates observed actual237 service start'
 for a in json.loads((FLOOR/'substrate-inputs.json').read_text())['assets']:
  assert sha(SUBSTRATE/a['path'])==a['sha256']
  assert sha(MAIN/a['path'])==(r['newSha256'] if a['path']==r['artifactPath'] else a['sha256']),'Only exact237 Fjall may differ from recovery native assets'
 return {'receipt':dependency(path),'proof':r,'dependencies':[dependency(r['parentPath']),dependency(r['journalPath']),dependency(MAIN/r['componentRecord'])],'claim':'Actual Rust component/release bytes only; not BL floor/SDK/ordinary acceptance'}
def keys():
 leaves=['aot','atom_guard','compiler_data','source_graph','ns_interface','build_plan','record','emit','optimize','link','tiers'];names=['AOT','AtomGuard','CompilerData','SourceGraph','NamespaceInterface','BuildPlan','Record','Emit','Optimize','Link','Tiers'];parts=[b'codegen']
 for leaf,name in zip(leaves,names):parts.extend([(MAIN/'priv/host'/f'{leaf}.bl').read_bytes(),('Elixir.BeamLisp.'+name).encode()])
 digest=lambda xs:hashlib.sha256(b'\0'.join(xs)).hexdigest();codegen=digest(parts)
 tier=sorted(list((MAIN/'priv/boot').rglob('*.bl'))+list((MAIN/'priv/self').rglob('*.bl')))
 compiler=digest([b'elixir:1.20.4',b'otp:29',b'aot_backend:core',('codegen-source:'+codegen).encode()]+[f.read_bytes() for f in tier]);build=digest([compiler.encode()]+[f.read_bytes() for f in sorted((MAIN/'priv/build').rglob('*.bl'))])
 return compiler,build,codegen
HOST_LEAVES=['env','loader','record','refs','lazy_memo','compiler_data','source_graph','ns_interface','build_plan','compiler','aot_cache','aot','server','supervisor','bootstrap','application']
def review_paths():return sorted({*['priv/host/'+n+'.bl' for n in HOST_LEAVES+['atom_guard','emit','optimize','link','tiers']],*['priv/boot/'+str(p.relative_to(MAIN/'priv/boot')) for p in (MAIN/'priv/boot').rglob('*.bl')],*['priv/self/'+str(p.relative_to(MAIN/'priv/self')) for p in (MAIN/'priv/self').rglob('*.bl')],*['priv/build/'+str(p.relative_to(MAIN/'priv/build')) for p in (MAIN/'priv/build').rglob('*.bl')],'scripts/regenerate-seed.bl','scripts/install-seed.bl','env.bl','bin/bl','bin/bl-stage-hosts','test/bl/seed_unit_members_test.bl','test/bl/bootstrap_unit_members_test.bl','priv/std/test.bl'})
def official_contract():
 script=(MAIN/'scripts/regenerate-seed.bl').read_text();hosts=re.findall(r'\["([\w_]+)\.bl" :Elixir\.BeamLisp\.[\w]+\]',script)
 assert hosts==HOST_LEAVES and len(hosts)==16,'Official coupled Host list changed; review required'
 assert 'native-only? (= module :Elixir.BeamLisp.LazyMemo)' in script
 assert all(x in script for x in ['(BeamLisp.Env/initialize_native_commands!)','(BeamLisp.Env/native_start_table_evidence!)','(BeamLisp.AOT/assert_bootstrap_callable_materialization!)','(BeamLisp.AOT/assert_bootstrap_macro_partition!)','(BeamLisp.CompilerData/assert_bootstrap_metadata_symbol_data!)',':private 11 :protected 2 :public 4',':manifest-last'])
 tables=re.findall(r'\[:(beam_lisp_\w+) :(public|private|protected) :(set|ordered_set)\]',script)
 assert len(tables)==17 and len({t[0] for t in tables})==17
 source=(MAIN/'priv/std/reload/generation.bl').read_text();start=source.index('(defn prepare!');end=source.find('\n(defn ',start+10);part=source[start:end if end!=-1 else None]
 exports=sorted(set((name,int(arity)) for name,arity in re.findall(r'function_exported :Elixir\.BeamLisp\.Env :([^\s()]+) (\d+)',part)))
 abi_start=script.index('(doseq [[name arity] [[:initialize_native_commands!');abi_end=script.index('(when-not (erlang/function_exported',abi_start)
 command_exports=sorted(set((name,int(arity)) for name,arity in re.findall(r'\[:([^\s()]+) (\d+)\]',script[abi_start:abi_end])))
 assert len(command_exports)>=22 and ('initialize_native_commands!',0) in command_exports
 assert ('check_source_invocation1!',2) in exports and ('check_source_invocation2!',3) in exports
 return {'hostEmitted':16,'hostLoaded':15,'emitOnly':['Elixir.BeamLisp.LazyMemo'],'hosts':hosts,'tables':[{'name':a,'protection':b,'type':c} for a,b,c in tables],'private':11,'protected':2,'public':4,'projectAssertions':15,'callablePreflightChecks':6,'metadataSymbolPreflightChecks':14,'macroPartitionPreflightChecks':11,'expectedBootUnits':13,'currentSourceEnvExports':exports,'currentNativeCommandExports':command_exports,'publication':'Official seed/check + independent actual shim unit-member/emitted byte closure; manifest-last dynamic complete output; historical226104 uninstalled and installed243104 quarantined; no restamping'}

def output_seed(root):
 # Supplementary inventory after the OFFICIAL Native consult/key/source judge.
 # This reads the generated canonical manifest's module-hash pairs, never evals.
 root=Path(root);raw=(root/'manifest.term').read_text()
 modules=re.findall(r'<<"([^"/]+\.beam)">>\s*=>\s*<<"([0-9a-f]{64})">>',raw)
 assert modules and len(modules)==len(dict(modules))
 app=re.search(r'<<"app">>\s*=>\s*#\{<<"file">>\s*=>\s*<<"([^"/]+)">>,\s*<<"sha256">>\s*=>\s*<<"([0-9a-f]{64})">>',raw)
 assert app and app.group(1)=='beam_lisp.app'
 declared=dict(modules);declared[app.group(1)]=app.group(2)
 assert 1<len(declared)<4096 and all(re.fullmatch(r'[A-Za-z0-9_.-]+',name) for name in declared)
 files=sorted(p for p in root.iterdir())
 assert [p.name for p in files]==sorted([*declared,'manifest.term'])
 assert all(p.is_file() and not p.is_symlink() for p in files)
 for name,digest in declared.items():assert sha(root/name)==digest,'Manifest artifact mismatch: '+name
 keys={name:re.search(r'<<"'+name+r'">>\s*=>\s*<<"([0-9a-f]{64})">>',raw).group(1) for name in ['compiler_key','build_key']}
 return {'files':[{'path':p.name,'sha256':sha(p),'bytes':p.stat().st_size,'mode':p.stat().st_mode&0o777} for p in files],'count':len(files),'manifestSha256':sha(root/'manifest.term'),'keys':keys,'judge':'Official Native seed/check + install-seed consult/key/source validator, then supplementary byte/inventory checks'}

INCOMPLETE243=R2/'coherent-floor-243-ready'
INCOMPLETE_RECEIPT=MAIN/'research/reload-contracts/coherent-floor-243-incomplete-closure.json'
def candidate_files(root):
 root=Path(root);assert root.is_dir() and not root.is_symlink()
 rows=[]
 for f in sorted(root.iterdir()):
  if f.suffix!='.beam' and f.name!='beam_lisp.app':continue
  assert f.is_file() and not f.is_symlink() and re.fullmatch('[A-Za-z0-9_.-]+',f.name)
  s=f.stat();assert 0<s.st_size<=256*1024*1024
  if f.suffix=='.beam':
   with f.open('rb') as stream:h=stream.read(12)
   assert h[:4]==b'FOR1' and h[8:]==b'BEAM' and int.from_bytes(h[4:8],'big')+8==s.st_size
  rows.append({'path':f.name,'sha256':sha(f),'bytes':s.st_size})
 assert 0<len(rows)<4096
 return rows
def cache_files(root):
 root=Path(root);assert root.is_dir() and not root.is_symlink();rows=[];total=0
 for parent,dirs,files in os.walk(root,followlinks=False):
  assert all(not (Path(parent)/d).is_symlink() for d in dirs)
  for name in files:
   f=Path(parent)/name;s=f.lstat();assert stat.S_ISREG(s.st_mode) and not f.is_symlink() and 0<s.st_size<=256*1024*1024
   total+=s.st_size;assert total<=2*1024*1024*1024 and len(rows)<8192
   if f.suffix=='.beam':
    with f.open('rb') as stream:h=stream.read(12)
    assert h[:4]==b'FOR1' and h[8:]==b'BEAM' and int.from_bytes(h[4:8],'big')+8==s.st_size
   rows.append({'path':str(f.relative_to(root)),'sha256':sha(f),'bytes':s.st_size})
 assert any(Path(r['path']).name=='manifest.term' for r in rows)
 return sorted(rows,key=lambda r:r['path'])
def incomplete243(require_installed=True):
 root=INCOMPLETE243;receipt=json.loads(INCOMPLETE_RECEIPT.read_text());parent=json.loads((root/'bl-coherent-floor-243-parent.json').read_text());publication=json.loads((root/'publication.json').read_text());frozen=json.loads((root/'inputs.json').read_text())
 assert receipt['currentFloorAccepted'] is False and receipt['sdkAccepted'] is False and receipt['parentExitCode']==0
 assert parent['exitCode']==0 and parent['success'] is True and parent['serviceResult']=='success' and parent['receivedSignals']==[]
 for field,name in [('scriptSha256','command.sh'),('logSha256','bl-coherent-floor-243.log'),('journalSha256','bl-coherent-floor-243-journal.jsonl')]:assert parent[field]==sha(root/name)
 assert (root/'bl-coherent-floor-243.log').read_text().rstrip().endswith('FINAL_COHERENT_FLOOR_BUILD_CHECK_INSTALL_FINISHED')
 assert publication['inputsSha256']==sha(root/'inputs.json') and publication['sourceCommit']==frozen['source_commit']==receipt['sourceCommit']
 output=output_seed(root/'seed');assert output==publication['outputSeed'] and output['manifestSha256']==receipt['actualManifestSha256'] and output['count']==receipt['actualOutputFiles']
 emitted=candidate_files(root/'ebin');seeded={r['path'] for r in output['files']};missing=[r for r in emitted if r['path'] not in seeded]
 assert missing==[{'path':r['file'],'sha256':r['sha256'],'bytes':r['actualEmittedBytes']} for r in receipt['missingActualEmittedCompanions']]
 assert keys()[0]==frozen['expected_compiler_key'],'Compiler Source key changed; require new recovery/cache review'
 if require_installed:
  assert output_seed(MAIN/'priv/bootstrap/seed')==output,'Installed input must be exact quarantined243 output'
  for r in output['files']:assert hashlib.sha256(git('show','HEAD:priv/bootstrap/seed/'+r['path'])).hexdigest()==r['sha256'],'Quarantined input not committed'
 return {'state':receipt['state'],'acceptedAsFloor':False,'acceptedAsSDK':False,'nativeProducerParentExitCode':0,'emittedUnitClosureComplete':False,'receipt':dependency(INCOMPLETE_RECEIPT),'dependencies':[dependency(root/n) for n in ['inputs.json','publication.json','command.sh','bl-coherent-floor-243-parent.json','bl-coherent-floor-243.log','bl-coherent-floor-243-journal.jsonl']],'compilerKey':frozen['expected_compiler_key'],'buildKey':frozen['expected_build_key'],'outputSeed':output,'emittedCandidates':emitted,'missingEmittedCompanions':missing,'builderMetadata':[dependency(root/'ebin'/n) for n in ['build.log','compile.beam_lisp']],'aotCache':cache_files(root/'aot-cache'),'authority':'QUARANTINED producer output and untrusted compile candidates ONLY; historical226 proof and genuine193 recovery remain separate'}
def emitted_output_closure(ebin,seed):
 emitted=candidate_files(ebin);published={r['path']:r for r in output_seed(seed)['files']}
 for row in emitted:
  assert row['path'] in published and all(row[k]==published[row['path']][k] for k in ['sha256','bytes']),'Actual emitted artifact omitted/different in publication: '+row['path']
 return [r for r in emitted if r['path'].endswith('.beam')]

def derive_regeneration(original,adapter_path):
 seam='  (let [seeded (BeamLisp.Ns.Rt/invoke (BeamLisp.Env/fetch_exact! "seed" "run")'
 assert original.count(seam)==1,'Exact after13/before70 native test seam must be reviewed'
 insertion='  ;; Root-authorized temporary actual committed fixture preflight:8/53.\n  (erlang/apply :Elixir.Code :eval_file (list '+json.dumps(str(adapter_path))+'))\n'
 derived=original.replace(seam,insertion+seam,1)
 assert derived.count(insertion)==1 and derived.replace(insertion,'',1)==original,'Derivation must be exactly one insertion'
 return derived,insertion

FAILED249=R2/'coherent-floor-249-ready'
HOST_MODULES=['Env','Loader','Record','Refs','LazyMemo','CompilerData','SourceGraph','NamespaceInterface','BuildPlan','Compiler','AOTCache','AOT','Server','Supervisor','Bootstrap','Application']
def failed249():
 root=FAILED249;p=json.loads((root/'bl-coherent-floor-249-parent.json').read_text());x=json.loads((root/'inputs.json').read_text())
 assert p['exitCode']==1 and p['success'] is False and p['receivedSignals']==[],'Require actual failed249, never accepted as floor'
 for key,name in [('scriptSha256','command.sh'),('logSha256','bl-coherent-floor-249.log'),('journalSha256','bl-coherent-floor-249-journal.jsonl')]:assert sha(root/name)==p[key]
 assert not (root/'publication.json').exists(),'249 unexpectedly published; review scope'
 fixture='test/bl/seed_unit_members_test.bl'
 assert physical_source_paths()==[r['path'] for r in x['sources']],'Unexpected Source path addition/removal since249'
 oldrow=next(r for r in x['sources'] if r['path']==fixture)
 verify_rows(MAIN,[r for r in x['sources'] if r['path']!=fixture]);verify_rows(MAIN,x['native_assets'])
 oldraw=git('show',x['source_commit']+':'+fixture);newraw=git('show','HEAD:'+fixture)
 assert hashlib.sha256(oldraw).hexdigest()==oldrow['sha256']
 current=record(MAIN/fixture,MAIN);assert hashlib.sha256(newraw).hexdigest()==current['sha256']
 oldmode=git('ls-tree',x['source_commit'],'--',fixture).decode().split()[0]
 newmode=git('ls-tree','HEAD','--',fixture).decode().split()[0]
 assert oldmode==newmode=='100644' and current['mode']==oldrow['mode'] and not (MAIN/fixture).is_symlink()
 fixture_delta={'path':fixture,'oldSourceCommit':x['source_commit'],'newSourceCommit':git('rev-parse','HEAD').decode().strip(),'old':oldrow,'current':current,'gitMode':newmode,'scope':'Only committed public fixture input normalization changed; no runtime Source/key changes'}
 assert keys()==(x['expected_compiler_key'],x['expected_build_key'],x['codegen_digest'])
 hosts=[]
 for leaf,name in zip(HOST_LEAVES,HOST_MODULES):
  file=root/'fresh-hosts'/('Elixir.BeamLisp.'+name+'.beam')
  hosts.append({'module':'Elixir.BeamLisp.'+name,'file':file.name,'artifact':dependency(file),'source':dependency(MAIN/'priv/host'/(leaf+'.bl'))})
 return {'acceptedAsFloor':False,'acceptedAsSDK':False,'parentExitCode':1,'dependencies':[dependency(root/n) for n in ['inputs.json','command.sh','bl-coherent-floor-249-parent.json','bl-coherent-floor-249.log','bl-coherent-floor-249-journal.jsonl']],'hosts':hosts,'cache':cache_files(root/'aot-cache'),'fixtureSuccessor':fixture_delta,'compilerKey':x['expected_compiler_key'],'buildKey':x['expected_build_key']}
def derive_fast(original,hosts,adapter):
 start=original.index(' (let [compiled\n       (BeamLisp.Env/with_ns original-ns')
 end=original.index('  (doseq [result compiled]',start)
 removed=original[start:end]
 replacement=' (let [compiled\n       ['+'\n        '.join('(tuple :'+r['module']+' '+json.dumps(r['copy'])+')' for r in hosts)+']]\n'
 stage1=original[:start]+replacement+original[end:]
 seam='  (let [seeded (BeamLisp.Ns.Rt/invoke (BeamLisp.Env/fetch_exact! "seed" "run")'
 assert stage1.count(seam)==1
 insertion='  ;; Explicit diagnostic only: stop before seed70/check/install.\n  (erlang/apply :Elixir.Code :eval_file (list '+json.dumps(str(adapter))+'))\n  (erlang/halt 70)\n'
 derived=stage1.replace(seam,insertion+seam,1)
 assert derived.replace(insertion,'',1).replace(replacement,removed,1)==original
 return derived,{'hostEmissionReplacementCount':1,'after13InsertionCount':1,'inverseBytesIdentical':True,'removedSha256':hashlib.sha256(removed.encode()).hexdigest(),'replacementSha256':hashlib.sha256(replacement.encode()).hexdigest(),'insertionSha256':hashlib.sha256(insertion.encode()).hexdigest()}
