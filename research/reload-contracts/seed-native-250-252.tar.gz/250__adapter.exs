root=System.fetch_env!("BL_PROBE_ROOT")
x=:json.decode(File.read!(root<>"/inputs.json"))
sha=fn bytes -> Base.encode16(:crypto.hash(:sha256,bytes),case: :lower) end
false=:ets.member(:beam_lisp_vars,:bl_sdk_runtime_lease)
0=:ets.info(:beam_lisp_owner_index,:size)
owner=Process.whereis(BeamLisp.Env)
Enum.each(x["official"]["tables"],fn row ->
 table=String.to_existing_atom(row["name"])
 true=:ets.info(table,:owner)==owner
 true=Atom.to_string(:ets.info(table,:protection))==row["protection"]
 true=Atom.to_string(:ets.info(table,:type))==row["type"]
end)
false=BeamLisp.Env.native_command_critical_active?()
Enum.each(x["failed249"]["hosts"],fn row ->
 if row["module"] != "Elixir.BeamLisp.LazyMemo" do
  module=String.to_existing_atom(row["module"])
  {^module,bytes,_}=:code.get_object_code(module)
  true=sha.(bytes)==row["artifact"]["sha256"]
  {:ok,{^module,md5}}=:beam_lib.md5(bytes);true=md5 == module.module_info(:md5)
 end
end)
IO.inspect(%{tables: 17,loadedHosts: 15,sourceCurrentCoreDefinitions: map_size(BeamLisp.Env.ns_defs("core")),sdkLease: false},label: "ACTUAL_FRESH_NATIVE_DIAGNOSTIC_CONTEXT")
System.put_env("BL_SEED_UNIT_MEMBERS_TEST_EBIN",root<>"/ebin")
main="/home/user/code/undefine/beam-lisp"
library=main<>"/priv/std/test.bl"
BeamLisp.Env.with_ns("core",fn -> BeamLisp.Compiler.eval_string(File.read!(library),BeamLisp.Compiler.new_env("core"),library) end)
test=main<>"/test/bl/seed_unit_members_test.bl"
BeamLisp.TestRT.declarations(fn -> BeamLisp.Compiler.eval_string(File.read!(test),BeamLisp.Compiler.new_env("test.seed-unit-members"),test) end)
# Root-authorized trusted Native calls to ORIGINAL PRIVATE test helpers only.
# Source caller admission is untouched; diagnostic reports actual public-fixture errors.
Code.eval_file(root<>"/diagnostic.exs")
false=:ets.member(:beam_lisp_vars,:bl_sdk_runtime_lease)
0=:ets.info(:beam_lisp_owner_index,:size)
result=%{diagnosticCompleted: true,acceptedAsFloor: false,acceptedAsSDK: false,sdkLeaseFabricated: false,sourceCommit: x["sourceCommit"],compilerKey: x["compilerKey"],inputSha256: sha.(File.read!(root<>"/inputs.json")),hostsValidatedBeforeLoad: 16,currentNativeHostsLoaded: 15,actualEnvOwnedTables: 17,originalFixtureSource: true,privateCallsTrustedNativeOnly: true,seedPublished: false}
File.write!(root<>"/diagnostic-result.json",:json.encode(result))
{_,0}=System.cmd("python3",[root<>"/preflight.py","after","0"])
IO.puts("FAST_SEED_REWRITE_DIAGNOSTIC_FINISHED_NOT_ACCEPTANCE")
System.halt(0)
