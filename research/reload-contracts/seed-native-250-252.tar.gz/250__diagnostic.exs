# Trusted Native diagnostic only. Invoke AFTER genuine current hosts + boot13
# are loaded and the ORIGINAL fixture has been loaded with TestRT.declarations.
# No test Source override, Source execution, SDK lease or floor authority.
namespace = "test.seed-unit-members"
false = :ets.member(:beam_lisp_vars, :bl_sdk_runtime_lease)
fixture = BeamLisp.Env.fetch_exact!(namespace, "fixture")
raw = BeamLisp.Env.fetch_exact!(namespace, "raw-attributes")
rewritten = BeamLisp.Env.fetch_exact!(namespace, "rewritten")
capture = fn label, action ->
  try do
    result = action.()
    IO.inspect(result, label: label, limit: 100, printable_limit: 2048)
    {:ok, result}
  rescue
    error ->
      frames = Enum.map(__STACKTRACE__, fn
        {m, f, a, location} ->
          arity = if is_list(a), do: length(a), else: a
          %{module: m, function: f, arity: arity, location: location}
      end)
      IO.inspect(%{exception: error.__struct__, message: Exception.message(error), frames: frames},
        label: label <> "_ERROR", limit: :infinity)
      {:error, error.__struct__}
  catch
    kind, reason ->
      IO.inspect(%{kind: kind, reason: reason, frames: __STACKTRACE__}, label: label <> "_THROW", limit: 30)
      {:caught, kind}
  end
end
BeamLisp.Ns.Rt.invoke(fixture, [fn f ->
  shim = BeamLisp.Ns.Rt.get(f, :shim)
  beams = BeamLisp.Ns.Rt.get(f, :beams)
  {^shim, bytes} = Enum.find(beams, fn {m, _} -> m == shim end)
  {:ok, {^shim, chunks}} = :beam_lib.chunks(bytes, [:attributes])
  attributes = Keyword.fetch!(chunks, :attributes)
  IO.inspect(%{shim: shim, beamBytes: byte_size(bytes),
    rows: Enum.map(attributes, fn row ->
      %{tuple: is_tuple(row), row: row}
    end)}, label: "ACTUAL_ORIGINAL_BEAM_ATTRIBUTES", limit: 100, printable_limit: 2048)
  capture.("ORIGINAL_RAW_ATTRIBUTES", fn -> BeamLisp.Ns.Rt.invoke(raw, [bytes]) end)
  capture.("ORIGINAL_REWRITTEN_NIL_MEMBERS", fn ->
    {module, output} = BeamLisp.Ns.Rt.invoke(rewritten, [bytes, shim, :bl_aot_unit_members, nil])
    %{module: module, beamBytes: byte_size(output)}
  end)
  # Build the same descriptor independently from ORIGINAL attribute tuples to
  # separate helper failure from the public descriptor/lowerer path.
  attrs = attributes
    |> Enum.filter(fn {key, _} -> String.starts_with?(Atom.to_string(key), "bl_") end)
    |> Enum.map(fn {key, value} ->
      {key, if(is_list(value) and length(value) == 1, do: hd(value), else: value)}
    end)
  attrs = [{:bl_aot_unit_members, nil} | Enum.reject(attrs, fn {key, _} -> key == :bl_aot_unit_members end)]
  descriptor = capture.("ACTUAL_PUBLIC_DESCRIPTOR", fn -> BeamLisp.Emit.descriptor_for(shim, [], attrs) end)
  case descriptor do
    {:ok, desc} -> capture.("ACTUAL_PUBLIC_DESCRIPTOR_COMPILE", fn ->
      {module, output} = BeamLisp.Emit.compile_descriptor(desc)
      %{module: module, beamBytes: byte_size(output)}
    end)
    _ -> :ok
  end
  :diagnosed
end])
false = :ets.member(:beam_lisp_vars, :bl_sdk_runtime_lease)
IO.puts("SEED_REWRITE_NATIVE_DIAGNOSTIC_FINISHED_NOT_ACCEPTANCE")
