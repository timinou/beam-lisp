root=System.fetch_env!("BL_PROBE_ROOT")
{_,0}=System.cmd("python3",[root<>"/preflight.py"])
x=:json.decode(File.read!(root<>"/inputs.json"))
Application.load(:beam_lisp)
{:ok,deps}=:application.get_key(:beam_lisp,:applications)
Enum.each(deps,fn d -> {:ok,_}=Application.ensure_all_started(d) end)
:ok=BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
BeamLisp.AOT.boot()
false=:ets.member(:beam_lisp_vars,:bl_sdk_runtime_lease)
0=:ets.info(:beam_lisp_owner_index,:size)
sha=fn bytes -> Base.encode16(:crypto.hash(:sha256,bytes),case: :lower) end
attribute=fn attrs,key -> case Keyword.get(attrs,key) do [v] -> v;v -> v end end
# Inspect all genuine249 produced bytes BEFORE loading any replacement.
Enum.each(x["failed249"]["hosts"],fn row ->
 bytes=File.read!(row["copy"]);true=sha.(bytes)==row["artifact"]["sha256"]
 {:ok,{module,[attributes: attrs]}}=:beam_lib.chunks(bytes,[:attributes])
 true=Atom.to_string(module)==row["module"]
 true=attribute.(attrs,:bl_source_hash)==row["source"]["sha256"]
 true=attribute.(attrs,:bl_compiler_key)==x["compilerKey"]
 true=sha.(File.read!(row["source"]["path"]))==row["source"]["sha256"]
 {:ok,{^module,_}}=:beam_lib.md5(bytes)
end)
IO.puts("ACTUAL_249_HOST_BYTES_MODULE_SOURCE_KEY_VALIDATED_16_UNTRUSTED")
System.put_env("BL_ROOT","/home/user/code/undefine/beam-lisp")
true=Code.prepend_path("/home/user/code/undefine/beam-lisp/.bl/lib/beam_lisp-0.1.0/ebin")
BeamLisp.Env.add_search_path("/home/user/code/undefine/beam-lisp/priv/build")
BeamLisp.AOTCache.reset_keys()
true=BeamLisp.AOTCache.current_compiler_key()==x["compilerKey"]
true=BeamLisp.AOTCache.current_build_key()==x["buildKey"]
file=root<>"/diagnostic-regenerate.bl"
# Explicit diagnostic derivation: Source-verified249Host list replaces emission;
# normal current15load/17table init/13canonicalrestore remains real unchanged logic.
BeamLisp.Compiler.eval_string(File.read!(file),BeamLisp.Compiler.new_env("tooling.regenerate-seed"),file)
raise "diagnostic_stop_seam_not_reached"
