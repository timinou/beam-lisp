#!/bin/bash
set -euo pipefail
root=$(CDPATH='' cd "$(dirname "$0")" && pwd -P)
unset BEAM_LISP_EBIN BEAM_LISP_PATH BL_ROOT BL_EBIN BL_BIN BL_BUILD_ID BL_BOOT_REEXECED BL_CONSTRUCTOR_METADATA_ROOT BL_KERNEL_SOURCE_UNDER_TEST BL_BOOTSTRAP_INSTALL
export BL_PROBE_ROOT="$root" BL_DIAGNOSTIC="$root/component.exs" BL_BOOTSTRAP_OUTPUT="$root" TMPDIR="$root/tmp" BEAM_LISP_AOT_CACHE_DIR="$root/aot-cache"
cd /home/user/code/undefine/beam-lisp
python3 "$root/preflight.py"
"$root/source-bootstrap-wrapper"
