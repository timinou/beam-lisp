#!/usr/bin/env python3
from pathlib import Path
import json,sys
import controls as c
H=Path(__file__).resolve().parent;x=json.loads((H/'inputs.json').read_text())
assert c.git('rev-parse','HEAD').decode().strip()==x['sourceCommit'] and not c.git('status','--porcelain')
assert (H/'inputs.sha256').read_text()==c.sha(H/'inputs.json')+'  inputs.json\n'
for name,digest in x['files'].items():assert c.sha(H/name)==digest
for field in ['tracked','sources','nativeAssets','initialSeed']:c.verify_rows(c.MAIN,x[field])
assert c.tracked_paths()==[r['path'] for r in x['tracked']] and c.physical_source_paths()==[r['path'] for r in x['sources']] and c.native_paths()==[r['path'] for r in x['nativeAssets']]
assert c.keys()==(x['compilerKey'],x['buildKey'],x['codegenDigest'])
expected={**x['failed249'],'hosts':[{k:v for k,v in r.items() if k!='copy'} for r in x['failed249']['hosts']]};assert c.failed249()==expected
for row in x['failed249']['hosts']:assert c.sha(row['copy'])==row['artifact']['sha256']
c.verify_rows(c.SUBSTRATE,x['recovery']['physicalTree']);assert c.native_transition()==x['nativeTransition']
assert c.accepted226(False)==x['historical226'] and c.incomplete243()==x['incomplete243']
derived,proof=c.derive_fast(Path(x['derivation']['original']['path']).read_text(),x['failed249']['hosts'],H/'adapter.exs');assert derived==(H/'diagnostic-regenerate.bl').read_text() and all(x['derivation'][k]==v for k,v in proof.items())
if len(sys.argv)>1 and sys.argv[1]=='after':
 assert sys.argv[2]=='0'
 result=json.loads((H/'diagnostic-result.json').read_text());assert result['diagnosticCompleted'] is True and result['acceptedAsFloor'] is False and result['acceptedAsSDK'] is False and result['sdkLeaseFabricated'] is False
 assert not (H/'seed').exists() and not (H/'publication.json').exists(),'Diagnostic must not publish a floor'
else:
 assert not (H/'diagnostic-result.json').exists() and not list((H/'ebin').iterdir())
 assert c.cache_files(H/'aot-cache')==x['failed249']['cache']
print(json.dumps({'controlsPassed':True,'diagnosticOnly':True,'after':len(sys.argv)>1}))
