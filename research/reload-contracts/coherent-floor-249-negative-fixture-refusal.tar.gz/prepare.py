#!/usr/bin/env python3
"""Root-only freeze of a NEW final floor attempt. No VM or Main/Source mutation."""
from pathlib import Path
import argparse,json,os,shutil,subprocess
import controls as c
HERE=Path(__file__).resolve().parent
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--check-prerequisites',action='store_true');p.add_argument('--write-review-example',type=Path);p.add_argument('--reviewed-source',type=Path);p.add_argument('--native-transition',type=Path,default=c.NATIVE_TRANSITION);p.add_argument('--boot-candidates',type=Path);p.add_argument('--aot-candidates',type=Path);p.add_argument('--output',type=Path);a=p.parse_args()
if a.write_review_example:
 x={'scope':'Observed current Source; Root must review after all pending semantic changes before freeze','sourceCommit':c.git('rev-parse','HEAD').decode().strip(),'sha256':{n:c.sha(c.MAIN/n) for n in c.review_paths()}}
 assert not a.write_review_example.exists();a.write_review_example.write_text(json.dumps(x,indent=2)+'\n');print(json.dumps({'reviewObservationOnly':str(a.write_review_example),'files':len(x['sha256'])}));raise SystemExit
accepted=c.accepted226(require_installed=False);incomplete=c.incomplete243();env=c.historical_env235();recovery=c.recovery();native=c.native_transition(a.native_transition);official=c.official_contract()
if a.check_prerequisites:
 print(json.dumps({'state':'UNFROZEN; no VM','acceptedInputSeedFiles':104,'historicalEnvChecks':128,'recoveryFiles':len(recovery['physicalTree']),'nativeTransition':native['proof']['newSha256'],'official':official,'pendingRootSourceReview':True,'installedCheckpointAccepted':False,'quarantined243ClosureComplete':False}));raise SystemExit
assert ':bl_aot_unit_members' in (c.MAIN/'priv/build/seed.bl').read_text(),'Reviewed actual-unit seed Source fix must land before freeze'
assert a.output and a.reviewed_source,'Require NEW --output and Root --reviewed-source'
assert not c.git('status','--porcelain'),'Root must finish/commit all semantic Source and evidence before freezing'
output=a.output.resolve();assert output.is_relative_to(c.R2) and not output.exists() and output!=HERE,'Preserve every prior frozen attempt/template'
review=json.loads(a.reviewed_source.read_text());assert review['sourceCommit']==c.git('rev-parse','HEAD').decode().strip()
assert sorted(review['sha256'])==c.review_paths(),'Complete official Host+boot+self+build+scripts/launcher Source review required'
assert all(c.sha(c.MAIN/n)==digest for n,digest in review['sha256'].items())
compiler,build,codegen=c.keys();output.mkdir(mode=0o700)
for name in ['controls.py','prepare.py','preflight.py','probe.exs','command.sh','project.direct.bl','PLAN.org','verify-unit-closure.exs','seed-unit-native-preflight.exs','bootstrap-unit-native-preflight.exs','unit-native-preflight.exs']:
 shutil.copyfile(HERE/name,output/name)
for name in ['prepare.py','preflight.py','command.sh']:(output/name).chmod(0o700)
shutil.copyfile(a.reviewed_source,output/'reviewed-source.json')
original=c.MAIN/'scripts/regenerate-seed.bl';derived,insertion=c.derive_regeneration(original.read_text(),output/'unit-native-preflight.exs')
(output/'regenerate-with-unit-preflight.bl').write_text(derived)
derivation={'scope':'Root-authorized temporary one-insertion test instrumentation; production seed/run/check/install logic unchanged; NOT unchanged official-script execution','original':c.dependency(original),'derived':c.dependency(output/'regenerate-with-unit-preflight.bl'),'adapter':c.dependency(output/'unit-native-preflight.exs'),'seedAdapter':c.dependency(output/'seed-unit-native-preflight.exs'),'bootstrapAdapter':c.dependency(output/'bootstrap-unit-native-preflight.exs'),'fixture':c.dependency(c.MAIN/'test/bl/seed_unit_members_test.bl'),'bootstrapFixture':c.dependency(c.MAIN/'test/bl/bootstrap_unit_members_test.bl'),'testLibrary':c.dependency(c.MAIN/'priv/std/test.bl'),'insertionSha256':__import__('hashlib').sha256(insertion.encode()).hexdigest(),'insertionCount':1,'sourceBytesOutsideInsertionIdentical':True,'position':'after13boot cache restore/compile before70Host seed/run','expectedTests':8,'expectedRuntimeAssertions':53}
launcher=(c.MAIN/'bin/bl').read_text();root_seam='ROOT=$(CDPATH=\'\' cd "$(dirname "$0")/.." && pwd -P)';exec_seam='exec elixir $PA -e \'BeamLisp.Launcher.main()\' -- "$@"'
assert launcher.count(root_seam)==launcher.count(exec_seam)==1
wrapper=launcher.replace(root_seam,'ROOT='+str(c.SUBSTRATE)).replace(exec_seam,'exec elixir $PA -e \'Code.eval_file(System.fetch_env!("BL_DIAGNOSTIC"))\' -- "$@"')
(output/'source-bootstrap-wrapper').write_text(wrapper);(output/'source-bootstrap-wrapper').chmod(0o700)
for name in ['ebin','tmp','aot-cache']:(output/name).mkdir()
cache=[];aot_cache=[]
if a.boot_candidates:
 assert a.boot_candidates.resolve()==(c.INCOMPLETE243/'ebin').resolve(),'Only actual243 compiled output candidates permitted'
 for row in c.candidate_files(a.boot_candidates):
  f=a.boot_candidates/row['path'];dest=output/'ebin'/f.name;shutil.copyfile(f,dest);assert c.sha(dest)==row['sha256']
  cache.append({'path':'ebin/'+f.name,'sha256':c.sha(dest),'source':str(f),'scope':'UNTRUSTED incomplete243 compiled bytes; official fresh Source/key/cache checks must validate'})
 # Deliberately omit build.log/compile.beam_lisp: their fresh? path alone does not
 # run canonical AOT cache validation. Genuine metadata hashes remain evidence.
if a.aot_candidates:
 assert a.aot_candidates.resolve()==(c.INCOMPLETE243/'aot-cache').resolve(),'Only actual243 cache candidates permitted'
 aot_cache=c.cache_files(a.aot_candidates)
 for row in aot_cache:
  src=a.aot_candidates/row['path'];dest=output/'aot-cache'/row['path'];dest.parent.mkdir(parents=True,exist_ok=True)
  fd=os.open(src,os.O_RDONLY|os.O_NOFOLLOW)
  with os.fdopen(fd,'rb') as inp,dest.open('xb') as target:shutil.copyfileobj(inp,target,1048576)
  assert c.sha(dest)==row['sha256']
 assert c.cache_files(output/'aot-cache')==aot_cache and c.cache_files(a.aot_candidates)==aot_cache
tracked=c.tracked_paths();sources=c.physical_source_paths();assets=c.native_paths()
control_names=['controls.py','prepare.py','preflight.py','probe.exs','command.sh','project.direct.bl','PLAN.org','reviewed-source.json','source-bootstrap-wrapper','verify-unit-closure.exs','seed-unit-native-preflight.exs','bootstrap-unit-native-preflight.exs','unit-native-preflight.exs','regenerate-with-unit-preflight.bl']
x={'scope':'Root-only final coherent Source floor via genuine193 recovery; actual226 input seed; new native table/Source/command ABI and current official preflights. No SDK/ordinary/product authority claimed','source_commit':review['sourceCommit'],'runtime':{'elixir':'1.20.4','otp':'29','backend':'core'},'expected_compiler_key':compiler,'expected_build_key':build,'codegen_digest':codegen,'accepted_parent':accepted,'accepted_seed':accepted['seed'],'prior_incomplete_floor':incomplete,'initial_installed_seed':[c.record(c.MAIN/'priv/bootstrap/seed'/r['path'],c.MAIN) for r in incomplete['outputSeed']['files']],'historical_env235':env,'substrate_directory':str(c.SUBSTRATE),'substrate_commit':recovery['commit'],'recovery':recovery,'native_transition':native,'official_contract':official,'reviewed_source':review,'tracked_inputs':[c.record(c.MAIN/n,c.MAIN) for n in tracked],'sources':[c.record(c.MAIN/n,c.MAIN) for n in sources],'native_assets':[c.record(c.MAIN/n,c.MAIN) for n in assets],'files':{n:c.sha(output/n) for n in control_names},'boot_cache':cache,'aot_cache_candidates':aot_cache,'regeneration_derivation':derivation,'project_assertions':15,'seed_unit_preflight':{'cases':8,'runtimeAssertions':53,'native':'UNRUN'},'launch_budget':{'memoryMax':'6G','memorySwapMax':0,'runtimeMaxSec':2700},'inputSeedCount':104,'historicalAcceptedSeedCount':104,'inputSeedAccepted':False,'inputSeedCheckpoint':'quarantined243; actual226 historical seed remains uninstalled','outputSeedCount':'DYNAMIC complete actual shim unit-member closure plus emitted artifact membership; native UNRUN','subsequent_gates':'Current SDK/lifetime/command/Source privacy, normal CLI, large data and product are separate UNRUN gates'}
(output/'inputs.json').write_text(json.dumps(x,indent=2)+'\n')
print(json.dumps({'ready':str(output),'inputsSha256':c.sha(output/'inputs.json'),'SourceCommit':x['source_commit'],'compilerKey':compiler,'buildKey':build,'trackedInputs':len(tracked),'physicalSources':len(sources),'nativeAssets':len(assets),'outputSeedCount':'dynamic','native':'UNRUN'}))
