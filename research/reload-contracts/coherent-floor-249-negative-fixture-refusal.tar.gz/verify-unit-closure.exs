# Read-only actual emitted BEAM attributes. No module load/init, SDK lease or owner.
root=System.fetch_env!("BL_PROBE_ROOT")
sha=fn bytes -> Base.encode16(:crypto.hash(:sha256,bytes),case: :lower) end
{:ok,[manifest]}=:file.consult(String.to_charlist(root<>"/seed/manifest.term"))
entries=manifest["modules"]
true=is_map(entries) and map_size(entries)>0 and map_size(entries)<4096
attribute=fn attrs,key -> case Keyword.get(attrs,key) do [value] -> value;value -> value end end
objects=Map.new(entries,fn {file,digest} ->
 true=is_binary(file) and String.valid?(file) and byte_size(file)<=255 and file not in [".",".."] and String.ends_with?(file,".beam") and not String.contains?(file,["/","\\",<<0>>])
 bytes=File.read!(root<>"/seed/"<>file);true=sha.(bytes)==digest
 {:ok,{module,[attributes: attrs]}}=:beam_lib.chunks(bytes,[:attributes])
 true=Atom.to_string(module)<>".beam"==file
 {file,%{module: module,attributes: attrs,sha256: digest,bytes: byte_size(bytes)}}
end)
closures=Enum.flat_map(objects,fn {file,row} ->
 if attribute.(row.attributes,:bl_aot_artifact_role)==:"mutable-forwarder" do
  {:members,members}=attribute.(row.attributes,:bl_aot_unit_members)
  true=is_list(members) and length(members)<=8192 and Enum.all?(members,&is_atom/1)
  true=length(Enum.uniq(members))==length(members)
  files=Enum.map(members,fn member ->
   name=Atom.to_string(member)<>".beam"
   proof=Map.fetch!(objects,name)
   true=proof.module==member
   true=attribute.(proof.attributes,:bl_unit_source_digest)==attribute.(row.attributes,:bl_unit_source_digest)
   true=attribute.(proof.attributes,:bl_compiler_key)==attribute.(row.attributes,:bl_compiler_key)
   name
  end)
  [%{shim: file,members: Enum.sort(files)}]
 else [] end
end)|>Enum.sort_by(& &1.shim)
true=length(closures)>0 and length(closures)<=1024
%{emittedUnitClosureComplete: true,unitMemberClosure: closures,shimCount: length(closures),memberReferences: Enum.sum(Enum.map(closures,fn row -> length(row.members) end)),factoryExecutions: 0,sdkLeaseFabricated: false}
