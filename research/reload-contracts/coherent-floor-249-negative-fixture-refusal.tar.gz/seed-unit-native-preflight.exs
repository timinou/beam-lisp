# Root integrates after real13boot compile and BEFORE seed/run's70host compile.
# Uses the committed fixture and real current compiler. No SDK receipt/lease grant.
main = "/home/user/code/undefine/beam-lisp"
test = main <> "/test/bl/seed_unit_members_test.bl"
namespace = "test.seed-unit-members"
false = :ets.member(:beam_lisp_vars, :bl_sdk_runtime_lease)
library = main <> "/priv/std/test.bl"
BeamLisp.Env.with_ns("core", fn ->
  BeamLisp.Compiler.eval_string(File.read!(library), BeamLisp.Compiler.new_env("core"), library)
end)
BeamLisp.TestRT.declarations(fn ->
  BeamLisp.Compiler.eval_string(File.read!(test), BeamLisp.Compiler.new_env(namespace), test)
end)
result = BeamLisp.TestRT.run_ns(namespace)
IO.inspect(result, label: "ACTUAL_BOOT_UNIT_MEMBERSHIP_PREFLIGHT")
true = result[:tests] == 5 and result[:pass] == 41 and result[:fail] == 0 and result[:error] == 0
false = :ets.member(:beam_lisp_vars, :bl_sdk_runtime_lease)
IO.puts("BOOT_UNIT_MEMBERSHIP_PREFLIGHT_5_CASES_41_ASSERTIONS_FINISHED")
