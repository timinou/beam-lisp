# Root-only after real13boot compilation, before70host seed compilation.
# Root supplies the actual producer output ebin, never Main/build by assumption.
main = "/home/user/code/undefine/beam-lisp"
namespace = "test.bootstrap-unit-members"
test = main <> "/test/bl/bootstrap_unit_members_test.bl"
true = File.dir?(System.fetch_env!("BL_SEED_UNIT_MEMBERS_TEST_EBIN"))
false = :ets.member(:beam_lisp_vars, :bl_sdk_runtime_lease)
BeamLisp.TestRT.declarations(fn ->
  BeamLisp.Compiler.eval_string(File.read!(test), BeamLisp.Compiler.new_env(namespace), test)
end)
result = BeamLisp.TestRT.run_ns(namespace)
IO.inspect(result, label: "ACTUAL_BOOTSTRAP_UNIT_CLOSURE_PREFLIGHT")
true = result[:tests] == 3 and result[:pass] == 12 and result[:fail] == 0 and result[:error] == 0
false = :ets.member(:beam_lisp_vars, :bl_sdk_runtime_lease)
IO.puts("BOOTSTRAP_UNIT_CLOSURE_PREFLIGHT_3_CASES_12_ASSERTIONS_FINISHED")
