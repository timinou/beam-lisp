# One explicitly authorized after13/before70 hook; both adapters byte-exact.
root=System.fetch_env!("BL_PROBE_ROOT")
System.put_env("BL_SEED_UNIT_MEMBERS_TEST_EBIN",root<>"/ebin")
{_,seed_bindings}=Code.eval_file(root<>"/seed-unit-native-preflight.exs")
{_,bootstrap_bindings}=Code.eval_file(root<>"/bootstrap-unit-native-preflight.exs")
seed=Map.take(Keyword.fetch!(seed_bindings,:result),[:tests,:pass,:fail,:error])
bootstrap=Map.take(Keyword.fetch!(bootstrap_bindings,:result),[:tests,:pass,:fail,:error])
proof=%{seed: seed,bootstrap: bootstrap,tests: seed.tests+bootstrap.tests,assertions: seed.pass+bootstrap.pass,failed: seed.fail+bootstrap.fail+seed.error+bootstrap.error,sdkLeaseFabricated: false}
true=proof.tests==8 and proof.assertions==53 and proof.failed==0
File.write!(root<>"/unit-preflight.json",:json.encode(proof))
IO.puts("BOOT_UNIT_PREFLIGHT_8_CASES_53_ASSERTIONS_FINISHED")
