# Native diagnostics13 + ordinary private-macro Core regressions20.
# The five physical candidate-Core SDK assertions remain deferred to its floor.
root=System.fetch_env!("BL_PROBE_ROOT")
main=System.fetch_env!("BL_ROOT")
sha=fn p->Base.encode16(:crypto.hash(:sha256,File.read!(p)),case: :lower) end
inputs=:json.decode(File.read!(root<>"/inputs.json"))
Enum.each(inputs["files"],fn {p,d}->true=sha.(root<>"/"<>p)==d end)
Enum.each(inputs["mainSources"],fn {p,d}->true=sha.(main<>"/"<>p)==d end)
Application.load(:beam_lisp)
{:ok,deps}=:application.get_key(:beam_lisp,:applications)
Enum.each(deps,fn d->{:ok,_}=Application.ensure_all_started(d) end)
:ok=BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
BeamLisp.AOT.boot()
false=:ets.member(:beam_lisp_vars,:bl_sdk_runtime_lease)
{BeamLisp.AOT,path}=BeamLisp.AOT.compile_host_file(root<>"/aot.candidate.bl",module: BeamLisp.AOT,output_dir: root<>"/host",load?: false)
bytes=File.read!(path)
{:module,BeamLisp.AOT}=:code.load_binary(BeamLisp.AOT,String.to_charlist(path),bytes)
{:ok,{BeamLisp.AOT,md5}}=:beam_lib.md5(bytes)
^md5=apply(BeamLisp.AOT,:module_info,[:md5])
IO.inspect(%{source: inputs["candidateSha256"],artifact: sha.(path),md5: Base.encode16(md5,case: :lower)},label: "DIAGNOSTICS_ACTUAL_NATIVE_IDENTITY")
results=Enum.map(inputs["fixtures"],fn fixture ->
 previous=BeamLisp.Env.capture()
 private=BeamLisp.Env.fork(:global)
 try do BeamLisp.Env.with_env(private,fn ->
  if fixture["namespace"]=="core-letfn-construction-test" do
   # Normal private macro evaluation only; never an SDK constructor receipt.
   BeamLisp.Compiler.eval_string(File.read!(root<>"/letfn.candidate.bl"),BeamLisp.Compiler.new_env("core"),"candidate-letfn-component")
  end
  file=root<>"/"<>fixture["file"]
  BeamLisp.Compiler.eval_string(File.read!(file),BeamLisp.Compiler.new_env(fixture["namespace"]),file)
  crashes=Enum.flat_map(fixture["functions"],fn name ->
   before=System.monotonic_time(:microsecond)
   try do
    BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(fixture["namespace"],name),[])
    IO.inspect(%{namespace: fixture["namespace"],name: name,microseconds: System.monotonic_time(:microsecond)-before},label: "DIAGNOSTIC_COMPONENT_CASE_COMPLETED");[]
   rescue e -> IO.inspect({fixture["namespace"],name,e,BeamLisp.ExInfo.ex_data(e),__STACKTRACE__},label: "DIAGNOSTIC_COMPONENT_CASE_CRASH",limit: 35);[name] end
  end)
  report=BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(fixture["namespace"],"direct-report"),[])
  IO.inspect(%{namespace: fixture["namespace"],report: report,deferred: fixture["deferredFunctions"]},label: "DIAGNOSTIC_COMPONENT_ASSERTIONS",limit: :infinity)
  crashes==[] and report[:assertions]==fixture["expectedAssertions"] and report[:pass]==fixture["expectedAssertions"]
 end) after BeamLisp.Env.destroy(private);BeamLisp.Env.bind(previous) end
end)
false=:ets.member(:beam_lisp_vars,:bl_sdk_runtime_lease)
Enum.each(inputs["mainSources"],fn {p,d}->true=sha.(main<>"/"<>p)==d end)
System.halt(if Enum.all?(results),do: 0,else: 1)
