#!/usr/bin/env bash
set -euo pipefail
root=/home/user/tmp/product-online-20261014/round2/constructor-diagnostics-native-191
export BL_PROBE_ROOT="$root" BL_DIAGNOSTIC="$root/probe.exs" TMPDIR="$root/tmp" BEAM_LISP_AOT_CACHE_DIR="$root/aot-cache" BL_DAEMON=off BL_AUTOBUILD=off
unset BEAM_LISP_EBIN BEAM_LISP_PATH BL_ROOT BL_EBIN BL_BIN BL_BUILD_ID BL_BOOT_REEXECED BL_CONSTRUCTOR_METADATA_ROOT BL_KERNEL_SOURCE_UNDER_TEST
cd /home/user/code/undefine/beam-lisp
"$root/source-wrapper"
