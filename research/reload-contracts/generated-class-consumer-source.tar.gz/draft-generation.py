from pathlib import Path
import hashlib
beam=Path('/home/user/code/undefine/beam-lisp');out=Path(__file__).parent
p=beam/'priv/std/reload/generation.bl';s=p.read_text();(out/'generation-base.sha256').write_text(hashlib.sha256(s.encode()).hexdigest()+'\n')
s=s.replace('      (and (= namespace "BeamLisp") (contains? #{"eval" "eval_string" "load_file"} name))','      (and (= namespace "BeamLisp.Record")\n           (contains? #{"define" "define_type" "register" "create_module"\n                        "publish_declaration!" "replay_declaration!" "publish_class!"} name))\n      (and (= namespace "BeamLisp") (contains? #{"eval" "eval_string" "load_file"} name))',1)
s=s.replace('[reload.declaration :as declaration]','[reload.declaration :as declaration] [reload.generated-class :as generated-class]',1)
s=s.replace('      (and (= namespace "BeamLisp") (contains? #{"eval" "eval_string" "load_file"} name))', '      (and (= namespace "BeamLisp.Multi") (= "extend_type" name))\n      (and (= namespace "BeamLisp") (contains? #{"eval" "eval_string" "load_file"} name))',1)
s=s.replace('#{"def" "defn" "defn-" "defmacro" "defserver"}', '#{"def" "defn" "defn-" "defmacro" "defserver" "defrecord" "deftype"}')
s=s.replace('''forms (BeamLisp.Reader/read_string source) seen (atom #{}) declared (atom #{})''','''forms (BeamLisp.Reader/read_string source) seen (atom #{}) declared (atom #{}) classes (:generated-classes planned)''',1)
needle='''            (if (= "declare" head)'''
replacement='''            (if (= "extend-type" head)
             (let [compiled (compile-exact planned form env)
                   namespaces (set (concat (vals (:mapping planned)) (:stable-namespaces planned)))
                   implementations (generated-class/extension! compiled @classes namespaces
                                      #(check-anf! planned %))
                   methods (evaluate-exact! (generated-class/capture-extension compiled implementations))]
              (swap! value-modules into (executable-values methods)))
            (if (= "declare" head)'''
assert needle in s;s=s.replace(needle,replacement,1)
s=s.replace('#{"defn" "defn-" "defmacro" "def" "defserver"}', '#{"defn" "defn-" "defmacro" "def" "defserver" "defrecord" "deftype"}',1)
needle='''                   compiled (compile-exact planned form env)]'''
replacement='''                   compiled (compile-exact planned form env)
                   class (when (contains? #{"defrecord" "deftype"} head)
                           (generated-class/class! compiled name definition
                             (if (= "defrecord" head) :record :deftype)
                             (set (concat (vals (:mapping planned)) (:stable-namespaces planned)))
                             #(check-anf! planned %)))]'''
assert needle in s;s=s.replace(needle,replacement,1)
needle='''               (when (= head "defserver") (swap! value-modules conj value))'''
replacement=needle+'''
               (when class
                (when-not (= (:module class) value)
                 (refuse! :unmanaged-class-descriptor {:namespace name}))
                (swap! classes conj value)
                (swap! value-modules into (concat [value]
                    (mapcat executable-values (generated-class/method-values! class)))))'''
assert needle in s;s=s.replace(needle,replacement,1)
needle='''               (definition! expanded (inc depth))))))))]'''
assert needle in s;s=s.replace(needle,'''               (definition! expanded (inc depth)))))))))]''',1)
s=s.replace(':module-inventory-cache (atom {:entries {} :hits 0 :scans 0}))', ':module-inventory-cache (atom {:entries {} :hits 0 :scans 0})\n                          :generated-classes (atom #{}))',1)
(out/'generation.bl').write_text(s)
