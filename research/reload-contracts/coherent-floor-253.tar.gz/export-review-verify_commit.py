#!/usr/bin/env python3
"""Read-only byte verification of Root's exact committed seed/evidence descendant."""
from pathlib import Path
import argparse,json,re,subprocess,sys
import export as e
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--attempt',type=Path,required=True);p.add_argument('--export',dest='export_dir',type=Path,required=True);p.add_argument('--commit',required=True);p.add_argument('--evidence-prefix',default='research/reload-contracts');p.add_argument('--allow-document',action='append',default=[]);a=p.parse_args()
assert re.fullmatch('[0-9a-f]{40}',a.commit)
root=a.attempt.resolve();out=a.export_dir.resolve();assert root.is_relative_to(e.HOME_TMP) and out.is_relative_to(e.HOME_TMP)
c=e.load(root/'controls.py','committed_floor_controls');x=e.read(root/'inputs.json');receipt=e.read(out/'coherent-floor-253.json');publication=e.read(root/'publication.json');assert c.git('rev-parse','HEAD').decode().strip()==a.commit and not c.git('status','--porcelain')
assert subprocess.run(['git','merge-base','--is-ancestor',x['source_commit'],a.commit],cwd=e.MAIN,stdout=subprocess.DEVNULL).returncode==0
assert receipt['inputsSha256']==e.sha(e.raw(root/'inputs.json')) and receipt['sourceCommit']==x['source_commit']
assert c.keys()==(x['expected_compiler_key'],x['expected_build_key'],x['codegen_digest'])
c.verify_rows(c.MAIN,x['sources']);c.verify_rows(c.MAIN,x['native_assets']);assert c.physical_source_paths()==[r['path'] for r in x['sources']] and c.native_paths()==[r['path'] for r in x['native_assets']]
allowed=set(a.allow_document)
for rel in allowed:
 assert rel.startswith(('!tasks/','docs/','research/')) and rel.endswith(('.org','.md','.json','.sha256','.txt')) and not rel.endswith(c.SOURCE_EXTENSIONS)
evidence={str(Path(a.evidence_prefix)/n):n for n in ['coherent-floor-253.tar.gz','coherent-floor-253-manifest.json','coherent-floor-253.json']};assert all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in evidence)
for rel,leaf in evidence.items():assert c.git('show',a.commit+':'+rel)==e.raw(out/leaf),'Committed evidence byte mismatch: '+rel
seed=receipt['outputSeedFiles'];assert len(seed)==receipt['counts']['outputSeedFiles'] and publication['outputSeed']['files']==seed
for row in seed:
 rel='priv/bootstrap/seed/'+row['path'];assert e.sha(c.git('show',a.commit+':'+rel))==row['sha256'] and e.sha(e.raw(c.MAIN/rel))==row['sha256'],'Committed/installed seed mismatch: '+rel
changed=set(filter(None,c.git('diff','--name-only','-z',x['source_commit'],a.commit).decode().split('\0')))
assert all(n.startswith('priv/bootstrap/seed/') or n in evidence or n in allowed for n in changed),'Unreviewed descendant change'
# Check all old tracked identities outside explicitly reviewed evidence/doc paths.
c.verify_rows(c.MAIN,[r for r in x['tracked_inputs'] if r['path'] not in allowed and r['path'] not in evidence])
old={r['path'] for r in x['tracked_inputs']};current=set(c.tracked_paths());assert (old^current)<=allowed|set(evidence),'Unexpected tracked path addition/removal'
assert c.output_seed(root/'seed')==publication['outputSeed']==c.output_seed(c.MAIN/'priv/bootstrap/seed')
print(json.dumps({'commit':a.commit,'committedEvidenceByteExact':3,'committedSeedFiles':len(seed),'sourceNativeAndKeysUnchanged':True,'SDKAccepted':False,'readOnly':True}))
