#!/usr/bin/env python3
"""HOME-only flat completed-floor export. Never starts native code or mutates Main."""
from pathlib import Path
import argparse,hashlib,importlib.util,io,json,os,re,subprocess,sys,tarfile
sys.dont_write_bytecode=True
MAIN=Path('/home/user/code/undefine/beam-lisp');HOME_TMP=Path.home()/'tmp'
MAX_FILE=16*1024*1024;MAX_RAW=48*1024*1024;MAX_FILES=128
MARKER='FINAL_COHERENT_FLOOR_BUILD_CHECK_INSTALL_FINISHED'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def raw(path):
 p=Path(path);assert p.is_file() and not p.is_symlink() and p.stat().st_size<=MAX_FILE,'Finite regular file required: '+str(p)
 return p.read_bytes()
def read(path):return json.loads(raw(path))
def load(path,name):
 spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
def complete(pub,inputs):
 assert pub['inputsSha256']==inputs['_sha'] and pub['sourceCommit']==inputs['source_commit'] and pub['noSeedRestamping'] is True
 assert pub['emittedUnitClosureComplete'] is True
 output=pub['outputSeed'];published={r['path']:r for r in output['files']}
 assert len(published)==len(output['files'])==output['count'] and 2<output['count']<4096
 assert output['keys']=={'compiler_key':inputs['expected_compiler_key'],'build_key':inputs['expected_build_key']}
 emitted=pub['emittedBootArtifacts'];assert 0<len(emitted)<4096 and len({r['path'] for r in emitted})==len(emitted)
 for row in emitted:
  assert row['path'].endswith('.beam') and row['path'] in published
  assert all(row[k]==published[row['path']][k] for k in ['sha256','bytes'])
 closure=pub['nativeUnitMemberClosure'];assert closure['emittedUnitClosureComplete'] is True and closure['factoryExecutions']==0 and closure['sdkLeaseFabricated'] is False
 units=closure['unitMemberClosure'];assert 0<len(units)<=1024 and closure['shimCount']==len(units) and len({r['shim'] for r in units})==len(units)
 assert closure['memberReferences']==sum(len(u['members']) for u in units)
 for unit in units:
  assert unit['shim'] in published and len(unit['members'])<=8192 and len(set(unit['members']))==len(unit['members'])
  assert all(n in published for n in unit['members'])
 assert {u['shim'] for u in units}|{n for u in units for n in u['members']}=={r['path'] for r in emitted},'Entire actual emitted boot inventory must equal declared native-unit closure'
 pre=pub['bootstrapUnitPreflight'];assert pre['tests']==8 and pre['assertions']==53 and pre['failed']==0 and pre['sdkLeaseFabricated'] is False
 for name,cases,count in [('seed',5,41),('bootstrap',3,12)]:
  g=pre[name];assert g=={'tests':cases,'pass':count,'fail':0,'error':0}
 assert pub['priorIncompleteFloor']['acceptedAsFloor'] is False and pub['priorIncompleteFloor']['emittedUnitClosureComplete'] is False
 return {'outputSeedFiles':output['count'],'emittedBootArtifacts':len(emitted),'nativeShims':len(units),'unitMemberReferences':closure['memberReferences'],'cases':pre['tests'],'assertions':pre['assertions'],'failed':pre['failed']}
def parent_proof(root,path):
 p=read(path);assert p['state']=='finished' and type(p['exitCode']) is int and p['exitCode']==0 and p['success'] is True and p['serviceResult']=='success' and p['receivedSignals']==[] and p['journalCaptureExitCode']==0
 unit=p['unit'].removesuffix('.service');command=p['command'];assert command[-1]==str(root/'command.sh')
 assert '--working-directory='+str(MAIN) in command and '--property=MemoryMax=6G' in command and '--property=MemorySwapMax=0' in command
 limits=[n for n in command if n.startswith('--property=RuntimeMaxSec=')];assert len(limits)==1 and re.fullmatch(r'--property=RuntimeMaxSec=[1-9][0-9]*s',limits[0]) and int(limits[0].split('=')[-1][:-1])<=2700
 paths={'script':root/'command.sh','log':root/(unit+'.log'),'journal':root/(unit+'-journal.jsonl'),'control':root/(unit+'-control.log')}
 for key,file in paths.items():assert sha(raw(file))==p[key+'Sha256']
 assert raw(paths['log']).decode().rstrip().endswith(MARKER),'Actual final finished marker required'
 assert re.fullmatch('[0-9a-f]{32}',p['invocationID'])
 rows=[json.loads(line) for line in raw(paths['journal']).decode().splitlines()]
 assert any(r.get('USER_INVOCATION_ID')==p['invocationID'] and r.get('USER_UNIT')==p['unit'] for r in rows)
 service_rows=[r for r in rows if r.get('_SYSTEMD_USER_UNIT')==p['unit']]
 assert all(r.get('_SYSTEMD_INVOCATION_ID')==p['invocationID'] for r in service_rows),'Any actual service-process journal row must match invocation'
 assert p['invocationObservedBy']=='actual unit ExecStart and working-directory match'
 return p,paths
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--attempt',type=Path,required=True);p.add_argument('--parent',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
 root=a.attempt.resolve();out=a.output.resolve();assert root.is_relative_to(HOME_TMP) and out.is_relative_to(HOME_TMP) and not out.exists() and out!=root
 assert a.parent.resolve().parent==root
 x=read(root/'inputs.json');x['_sha']=sha(raw(root/'inputs.json'));parent,paths=parent_proof(root,a.parent)
 runner=HOME_TMP/'product-online-20261014/round2/run-owned-native-v3.py';assert sha(raw(runner))==parent['runnerSha256'],'Actual owned runner bytes changed since run'
 pub=read(root/'publication.json');counts=complete(pub,x)
 assert Path(pub['emittedBootDirectory'])==root/'ebin' and Path(pub['nativeUnitMemberClosurePath'])==root/'unit-closure.json'
 assert sha(raw(root/'unit-closure.json'))==pub['nativeUnitMemberClosureSha256'] and read(root/'unit-closure.json')==pub['nativeUnitMemberClosure']
 assert sha(raw(root/'unit-preflight.json'))==pub['bootstrapUnitPreflightSha256'] and read(root/'unit-preflight.json')==pub['bootstrapUnitPreflight']
 # Existing exact frozen Python postflight rechecks tracked/physical Source/native,
 # genuine193 recovery,237 asset, controls, installed seed+all emitted object bytes.
 # It is Python only; require publication preexisting and unchanged afterwards.
 publication_bytes=raw(root/'publication.json')
 check=subprocess.run([sys.executable,str(root/'preflight.py'),'--post-publication'],capture_output=True,check=True)
 assert raw(root/'publication.json')==publication_bytes
 c=load(root/'controls.py','floor_export_controls')
 assert c.output_seed(root/'seed')==pub['outputSeed']==c.output_seed(MAIN/'priv/bootstrap/seed')
 assert c.emitted_output_closure(root/'ebin',root/'seed')==pub['emittedBootArtifacts']
 payload={}
 def add(name,path):
  assert '/' not in name and '\\' not in name and name not in payload and not name.endswith(('.tar.gz','.tar','.tgz','.zip','.gz','.bz2','.xz','.beam','.so'))
  payload[name]=raw(path)
 for name in ['inputs.json','publication.json','unit-closure.json','unit-preflight.json',*x['files']]:add(name,root/name)
 add(a.parent.name,a.parent)
 for key,file in paths.items():
  if file.name not in payload:add(file.name,file)
 add('actual-owned-runner-v3.py',runner)
 for leaf in ['export.py','verify_commit.py','test_export.py']:
  add('export-review-'+leaf,Path(__file__).resolve().parent/leaf)
 memory=root/(parent['unit'].removesuffix('.service')+'-memory-before.txt')
 if memory.exists():add(memory.name,memory)
 dependency_manifest={'scope':'References and inventories only; no recoveredSource/build/cache/native payload copied','recovery':x['recovery'],'historicalAccepted226':x['accepted_parent'],'quarantined243':x['prior_incomplete_floor'],'nativeTransition237':x['native_transition']}
 payload['dependency-inventory.json']=(json.dumps(dependency_manifest,indent=2)+'\n').encode()
 payload['export-postflight.json']=(json.dumps({'pythonPostflightExit':check.returncode,'stdoutSha256':sha(check.stdout),'stderrSha256':sha(check.stderr),'publicationUnchanged':True,'counts':counts},indent=2)+'\n').encode()
 assert len(payload)<=MAX_FILES and sum(len(v) for v in payload.values())<=MAX_RAW and all(len(v)<=MAX_FILE for v in payload.values())
 guard_path=MAIN/'scripts/check-public-evidence.py';guard=load(guard_path,'floor_public_evidence_guard')
 # Same actual public guard, unchanged budgets. Never creates Git refs/objects.
 budget=guard.Budget()
 for name,data in payload.items():guard.scan_bytes(data,name,budget)
 out.mkdir(mode=0o700)
 archive=out/'coherent-floor-253.tar.gz'
 with archive.open('xb') as target:
  import gzip
  with gzip.GzipFile(fileobj=target,mode='wb',mtime=0,filename='') as compressed:
   with tarfile.open(fileobj=compressed,mode='w',format=tarfile.USTAR_FORMAT) as t:
    for name,data in sorted(payload.items()):
     info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o600;info.mtime=0;t.addfile(info,io.BytesIO(data))
 guard.scan_bytes(raw(archive),archive.name)
 with tarfile.open(archive,'r:gz') as t:
  members=t.getmembers();assert len(members)==len(payload)
  for member in members:assert member.isfile() and t.extractfile(member).read()==payload[member.name]
 manifest={'scope':'Flat actual complete producer controls; no SDK/product acceptance, images, caches, nested archives or private application Source','archive':archive.name,'archiveSha256':sha(raw(archive)),'rawBytes':sum(len(v) for v in payload.values()),'members':[{'path':n,'sha256':sha(v),'bytes':len(v)} for n,v in sorted(payload.items())],'publicGuardSha256':sha(raw(guard_path)),'publicGuardPassed':True,'originalFilesUnchanged':True}
 (out/'coherent-floor-253-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 receipt={'scope':'Actual complete compiler/Source producer publication; SDK/ordinary/product gates remain separate','sourceCommit':x['source_commit'],'compilerKey':x['expected_compiler_key'],'buildKey':x['expected_build_key'],'inputsSha256':x['_sha'],'manifestSha256':pub['outputSeed']['manifestSha256'],'counts':counts,'producerParentExitCode':parent['exitCode'],'serviceResult':parent['serviceResult'],'invocationID':parent['invocationID'],'producerWallSeconds':parent['wallSecondsParent'],'wallScope':'Entire owned regeneration pipeline; not ordinary startup/navigation/SDK-stage benchmark','sourceAndNativePostflightPassed':True,'nativeUnitMemberClosureComplete':True,'outputSeedFiles':pub['outputSeed']['files'],'noSeedRestamping':True,'sdkAccepted':False,'ordinaryAccepted':False,'productAccepted':False,'rootReviewAndCommitRequired':True,'archiveSha256':manifest['archiveSha256'],'flatManifestSha256':sha(raw(out/'coherent-floor-253-manifest.json')),'publicGuardPassed':True,'cleanup':'Finite exported controls must be committed and byte-verified before any consumed scratch cleanup; retain installed seed, emittedBootDirectory for packaging fixtures, original243 cache and225 recovery until Root releases dependencies'}
 (out/'coherent-floor-253.json').write_text(json.dumps(receipt,indent=2)+'\n')
 for name in ['coherent-floor-253-manifest.json','coherent-floor-253.json']:guard.scan_bytes(raw(out/name),name)
 print(json.dumps({'export':str(out),'archiveSha256':manifest['archiveSha256'],'flatMembers':len(payload),'counts':counts,'producerComplete':True,'SDKAccepted':False}))
if __name__=='__main__':main()
