#!/usr/bin/env python3
"""Synthetic closed-data validation only. No native/artifact authority is fabricated."""
import ast,copy,unittest
from pathlib import Path
import export as e
class Controls(unittest.TestCase):
 def setUp(self):
  self.x={'_sha':'input','source_commit':'source','expected_compiler_key':'compiler','expected_build_key':'build'}
  files=[{'path':n,'sha256':n,'bytes':1} for n in ['Shim.beam','Body.beam','Macro.beam','beam_lisp.app','manifest.term']]
  self.p={'inputsSha256':'input','sourceCommit':'source','noSeedRestamping':True,'emittedUnitClosureComplete':True,'outputSeed':{'files':files,'count':len(files),'keys':{'compiler_key':'compiler','build_key':'build'}},'emittedBootArtifacts':files[:3],'nativeUnitMemberClosure':{'emittedUnitClosureComplete':True,'factoryExecutions':0,'sdkLeaseFabricated':False,'unitMemberClosure':[{'shim':'Shim.beam','members':['Body.beam','Macro.beam']}],'shimCount':1,'memberReferences':2},'bootstrapUnitPreflight':{'tests':8,'assertions':53,'failed':0,'sdkLeaseFabricated':False,'seed':{'tests':5,'pass':41,'fail':0,'error':0},'bootstrap':{'tests':3,'pass':12,'fail':0,'error':0}},'priorIncompleteFloor':{'acceptedAsFloor':False,'emittedUnitClosureComplete':False}}
 def rejects(self):
  with self.assertRaises(AssertionError):e.complete(self.p,self.x)
 def test_python_parse(self):ast.parse(Path(e.__file__).read_text())
 def test_dynamic_complete_inventory(self):
  self.assertEqual(e.complete(self.p,self.x)['outputSeedFiles'],5)
  self.p['outputSeed']['files'].append({'path':'Host.beam','sha256':'host','bytes':1});self.p['outputSeed']['count']+=1
  self.assertEqual(e.complete(self.p,self.x)['outputSeedFiles'],6)
 def test_value_only_shim_empty_members(self):
  row={'path':'ValueOnly.beam','sha256':'value','bytes':1};self.p['outputSeed']['files'].append(row);self.p['outputSeed']['count']+=1;self.p['emittedBootArtifacts'].append(row);self.p['nativeUnitMemberClosure']['unitMemberClosure'].append({'shim':'ValueOnly.beam','members':[]});self.p['nativeUnitMemberClosure']['shimCount']+=1
  self.assertEqual(e.complete(self.p,self.x)['nativeShims'],2)
 def test_known_incomplete_refused(self):self.p['emittedUnitClosureComplete']=False;self.rejects()
 def test_missing_macro_in_manifest_refused(self):self.p['outputSeed']['files'].pop(2);self.p['outputSeed']['count']-=1;self.rejects()
 def test_undeclared_emitted_macro_refused(self):self.p['nativeUnitMemberClosure']['unitMemberClosure'][0]['members'].pop();self.p['nativeUnitMemberClosure']['memberReferences']-=1;self.rejects()
 def test_wrong_member_hash_refused(self):self.p['emittedBootArtifacts']=copy.deepcopy(self.p['emittedBootArtifacts']);self.p['emittedBootArtifacts'][2]['sha256']='wrong';self.rejects()
 def test_duplicate_member_refused(self):self.p['nativeUnitMemberClosure']['unitMemberClosure'][0]['members'].append('Body.beam');self.p['nativeUnitMemberClosure']['memberReferences']+=1;self.rejects()
 def test_actual_input_mismatch_refused(self):self.p['inputsSha256']='other';self.rejects()
 def test_component_failure_refused(self):self.p['bootstrapUnitPreflight']['seed']['error']=1;self.rejects()
 def test_fake_lease_receipt_refused(self):self.p['nativeUnitMemberClosure']['sdkLeaseFabricated']=True;self.rejects()
if __name__=='__main__':unittest.main()
