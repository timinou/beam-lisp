#!/usr/bin/env python3
"""Verify immutable attempt inputs and mode order, then reserve a fresh process slot. No VM."""
from pathlib import Path
import hashlib,json,os,sys
HERE=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def cache_snapshot(path):
 return [{'path':str(p.relative_to(path)),'sha256':sha(p)} for p in sorted(path.rglob('*')) if p.is_file()]
def verify_rows(root,rows):
 for row in rows:
  p=root/row['path'];s=p.stat()
  assert (s.st_dev,s.st_ino,sha(p))==(row['device'],row['inode'],row['sha256']), 'frozen physical input changed: '+row['path']
def main():
 mode=sys.argv[1];assert mode in ('cold','warm','fault')
 x=json.loads((HERE/'component-inputs.json').read_text());main=Path(x['main'])
 assert sha(x['floorInputs'])==x['floorInputsSha256'],'accepted floor inputs changed'
 assert sha(x['floorResult'])==x['floorResultSha256'],'accepted floor parent receipt changed'
 assert sha(x['floorLog'])==x['floorLogSha256'],'accepted floor log changed'
 assert len(x['seed'])==104,'incomplete accepted seed inventory'
 for name,digest in x['files'].items():assert sha(HERE/name)==digest,'component input changed: '+name
 verify_rows(main,x['sources']);verify_rows(main,x['nativeAssets']);verify_rows(main/'priv/bootstrap/seed',x['seed'])
 expected={r['path'] for r in x['sources'] if r['path'].startswith('priv/') and r['path'].endswith(tuple(x['sourceExtensions']))}
 actual={str(p.relative_to(main)) for p in (main/'priv').rglob('*') if p.is_file() and p.name.endswith(tuple(x['sourceExtensions']))}
 assert expected==actual,'physical SDK Source inventory changed'
 assert sha(main/'priv/bootstrap/seed/manifest.term')==x['manifestSha256']
 cache=cache_snapshot(HERE/'aot-cache')
 if mode=='cold':assert not cache,'cold cache must actually be empty'
 else:
  previous='cold' if mode=='warm' else 'warm'
  r=json.loads((HERE/(previous+'-result.json')).read_text())
  assert r['accepted'] is True,'prior component did not pass'
  assert r['cache']==cache,'persistent cache differs from successful prior component'
 ebin=HERE/'images'/mode/'lib/beam_lisp-0.1.0/ebin'
 assert not list(ebin.iterdir()),'each role requires its own empty native image'
 with (HERE/(mode+'-started.json')).open('x') as f:json.dump({'mode':mode,'inputsSha256':sha(HERE/'component-inputs.json'),'cache':cache,'pid':os.getpid()},f)
 print(json.dumps({'mode':mode,'preflight':'PASS','VMsLaunched':0,'cacheFiles':len(cache)}))
if __name__=='__main__':main()
