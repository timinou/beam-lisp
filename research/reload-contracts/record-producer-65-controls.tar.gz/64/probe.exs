# Root-only native provisioning-mode producer test. No CLI/ward/listeners/app.
Application.load(:beam_lisp)
{:ok,dependencies} = :application.get_key(:beam_lisp,:applications)
Enum.each(dependencies, fn dep -> {:ok,_}=Application.ensure_all_started(dep) end)
IO.inspect(BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN")),label: "verified_floor")
BeamLisp.AOT.boot()
root=System.fetch_env!("BL_PROBE_ROOT")
main=System.fetch_env!("BL_ROOT")
IO.puts("PROVISIONING_MODE_NO_INITIAL_SDK_LEASE")
if :ets.member(:beam_lisp_vars,:bl_sdk_runtime_lease),do: raise("probe unexpectedly acquired SDK lifetime")
# Build both native candidates with the old coherent producer BEFORE loading
# either. Their ABI calls are existing Env lock/lease APIs and one new facade
# forwarding function; no new Loader/AOT ABI is required by this narrow batch.
candidates=[{BeamLisp.Record,"priv/host/record.bl"},{BeamLisp.Compiler,"priv/host/compiler.bl"}]
compiled=Enum.map(candidates,fn {module,relative} ->
 source=Path.join(root,"source/"<>relative)
 unless File.read!(source)==File.read!(Path.join(main,relative)),do: raise("source changed since snapshot: "<>relative)
 before=BeamLisp.Env.capture()
 try do
  BeamLisp.AOT.compile_host_file(source,module: module,output_dir: Path.join(root,"native"),load?: false)
 after
  BeamLisp.Env.bind(before)
 end
end)
# Native ABI stand-in fixture uses code.get_object_code to save/restore the
# actual running producer. Its object path must resolve to this compiled cut.
true=:code.add_patha(String.to_charlist(Path.join(root,"native")))
Enum.each(compiled,fn {module,path} -> {:module,^module}=:code.load_binary(module,String.to_charlist(path),File.read!(path)) end)
IO.puts("RECORD_AND_COMPILER_FACADE_COHERENT")
# Compile/replay the actual new boot compiler with the new Record producer.
# Ordinary source evaluation is explicit provisioning evidence, not proof of
# production SDK staging or the ordinary application startup route.
compiler=Path.join(root,"source/priv/boot/compiler.bl")
unless File.read!(compiler)==File.read!(Path.join(main,"priv/boot/compiler.bl")),do: raise("boot compiler snapshot changed")
artifacts=BeamLisp.AOT.compile_file(compiler,output_dir: Path.join(root,"compiler"),mark_loaded?: true)
true=:code.add_patha(String.to_charlist(Path.join(root,"compiler")))
BeamLisp.AOTCache.run_init_modules(Enum.map(artifacts,&elem(&1,0)),Path.join(root,"compiler"))
unless function_exported?(BeamLisp.Ns.Compiler,:prelink_type,2),do: raise("actual new boot compiler was not replayed")
Enum.each(artifacts,fn {module,path} ->
 {:ok,{^module,md5}}=:beam_lib.md5(String.to_charlist(path))
 unless apply(module,:module_info,[:md5])==md5,do: raise("loaded compiler differs from newly emitted artifact")
 IO.inspect({module,Base.encode16(md5,case: :lower)},label: "ACTUAL_CURRENT_COMPILER_ARTIFACT")
end)
fixtures=[%{"namespace" => "host.record.test","functions" => ["record-pinned-matches-the-live-module","record-pinned-export-surface","record-module-name-tracks-the-beam","record-redefinition-updates-the-struct-abi","record-pinned-beam-stands-in-at-the-production-atom"],"expected-runtime-assertions" => 167,"direct" => "host_record_test.direct.bl"},%{"namespace" => "record-declaration-test","functions" => ["descriptor-construction-is-inert-and-only-exact-bodies-are-recognized","canonical-compiler-scaffold-is-one-literal-atomic-producer","exact-class-leases-prevent-code-and-semantic-schema-replacement","origin-collisions-and-missing-replay-artifacts-refuse-without-publication","staged-type-metadata-does-not-execute-a-class-initializer","explicit-later-type-binding-wins-over-staged-declaration-metadata","a-leased-uninitialized-deftype-requires-the-loaded-canonical-schema","concurrent-distinct-class-definitions-preserve-every-origin-registry-row","deftype-fields-preserve-ordinary-nonstruct-semantics"],"expected-runtime-assertions" => 98,"direct" => "record_declaration_test.direct.bl"}]
all=Enum.map(fixtures,fn fixture ->
 ns=Map.fetch!(fixture,"namespace");file=Path.join(root,Map.fetch!(fixture,"direct"))
 BeamLisp.Compiler.eval_string(File.read!(file),BeamLisp.Compiler.new_env(ns),file)
 crashes=Enum.flat_map(Map.fetch!(fixture,"functions"),fn name ->
  try do
   result=BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(ns,name),[])
   IO.inspect({ns,name,result},label: "RECORD_DIRECT_CASE");[]
  rescue
   error -> IO.inspect({ns,name,error,__STACKTRACE__},label: "RECORD_DIRECT_CRASH");[name]
  catch
   kind,reason -> IO.inspect({ns,name,kind,reason},label: "RECORD_DIRECT_THROW");[name]
  end
 end)
 report=BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(ns,"direct-report"),[])
 IO.inspect({ns,report},label: "RECORD_DIRECT_ASSERTIONS")
 expected=Map.fetch!(fixture,"expected-runtime-assertions")
 passed=crashes==[] and report[:assertions]==expected and report[:pass]==expected and BeamLisp.Vector.to_list(report[:failures])==[]
 %{namespace: ns,expected: expected,assertions: report[:assertions],pass: report[:pass],crashes: crashes,passed: passed}
end)
IO.inspect(all,label: "RECORD_PRODUCER64_EVIDENCE")
System.halt(if Enum.all?(all,& &1.passed),do: 0,else: 1)
