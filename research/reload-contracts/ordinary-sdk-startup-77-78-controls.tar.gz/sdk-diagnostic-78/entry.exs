Code.ensure_loaded!(BeamLisp.AOT)
tracer = spawn(fn ->
  loop = fn loop ->
    receive do
      {:trace, pid, :call, {BeamLisp.AOT, :compile_source, [source, _opts]}} ->
        IO.inspect({pid, BeamLisp.Loader.declared_ns(source)}, label: "SDK_COMPILE_NAMESPACE")
        loop.(loop)
      {:trace, pid, :exception_from, mfa, detail} ->
        IO.inspect({pid, mfa, detail}, label: "SDK_COMPILE_EXCEPTION", limit: 20)
        loop.(loop)
      _ -> loop.(loop)
    end
  end
  loop.(loop)
end)
:erlang.trace_pattern({BeamLisp.AOT, :compile_source, 2}, [{:_, [], [{:exception_trace}]}], [:local])
:erlang.trace(:all, true, [:call, :set_on_spawn, {:tracer, tracer}])
try do
  BeamLisp.Launcher.main()
rescue
  error ->
    IO.inspect(BeamLisp.ExInfo.ex_data(error), label: "STARTUP_REFUSAL_DATA", limit: 30)
    IO.inspect(__STACKTRACE__, label: "STARTUP_REFUSAL_STACK", limit: 30)
    System.halt(1)
end
