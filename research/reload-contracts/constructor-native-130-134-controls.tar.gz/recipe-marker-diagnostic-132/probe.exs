Application.load(:beam_lisp)
{:ok, deps} = :application.get_key(:beam_lisp, :applications)
Enum.each(deps, fn dep -> {:ok, _} = Application.ensure_all_started(dep) end)
:ok = BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
BeamLisp.AOT.boot()
root = System.fetch_env!("BL_PROBE_ROOT")
# Reuse the exact Compiler artifacts produced and hashed by native106.
# This is a diagnostic overlay, never a coherent-floor acceptance.
for module <- [BeamLisp.Ns.Compiler, BeamLisp.Ns.Body.Compiler, BeamLisp.Ns.Init.Compiler] do
 artifact = "/home/user/tmp/product-online-20261014/round2/compiler-metadata-native-127/compiler-beams/" <> Atom.to_string(module) <> ".beam"
 {:module, ^module} = :code.load_binary(module, String.to_charlist(artifact), File.read!(artifact))
 IO.inspect({module, Base.encode16(:crypto.hash(:sha256, File.read!(artifact)), case: :lower)}, label: "REUSED_NATIVE_COMPILER")
end
for module <- [BeamLisp.SourceGraph, BeamLisp.NamespaceInterface] do
 artifact = "/home/user/tmp/product-online-20261014/round2/constructor-context-117/host/" <> Atom.to_string(module) <> ".beam"
 {:module, ^module} = :code.load_binary(module, String.to_charlist(artifact), File.read!(artifact))
end
for {module, directory} <- [{BeamLisp.BuildPlan, "constructor-context-119/host"}, {BeamLisp.AOT, "constructor-reader-native-123/host"}, {:"Elixir.BeamLisp.Ns.Reader-node", "constructor-reader-native-123/reader-beams"}, {:"Elixir.BeamLisp.Ns.Body.Reader-node", "constructor-reader-native-123/reader-beams"}, {BeamLisp.Ns.Reader, "constructor-reader-native-123/reader-beams"}, {BeamLisp.Ns.Body.Reader, "constructor-reader-native-123/reader-beams"}, {BeamLisp.Ns.Init.Reader, "constructor-reader-native-123/reader-beams"}] do
 artifact = "/home/user/tmp/product-online-20261014/round2/" <> directory <> "/" <> Atom.to_string(module) <> ".beam"
 {:module, ^module} = :code.load_binary(module, String.to_charlist(artifact), File.read!(artifact))
 IO.inspect({module, Base.encode16(:crypto.hash(:sha256, File.read!(artifact)), case: :lower)}, label: "EXACT_NATIVE_ARTIFACT")
end
path = Path.dirname(root) <> "/constructor-native-130/host/Elixir.BeamLisp.AOT.beam"
{:module, BeamLisp.AOT} = :code.load_binary(BeamLisp.AOT, String.to_charlist(path), File.read!(path))
namespace = "aot-constructor-recipe-test"
file = root <> "/recipe.direct.bl"
BeamLisp.Compiler.eval_string(File.read!(file), BeamLisp.Compiler.new_env(namespace), file)
for name <- ["compat-fold-never-invokes-a-mutable-runtime-predicate", "proved-capsule-vector-and-set-predicates-match-the-real-counterparts"] do
 IO.inspect(name, label: "BEFORE_ORIGINAL_CASE")
 BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(namespace, name), [])
 IO.inspect({name, BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(namespace, "direct-report"), [])}, label: "CASE_ASSERTIONS", limit: :infinity)
end
