#!/usr/bin/env bash
set -euo pipefail
root=/home/user/tmp/product-online-20261014/round2/final-floor-ready
export BL_PROBE_ROOT="$root" BL_DIAGNOSTIC="$root/probe.exs" BL_BOOTSTRAP_OUTPUT="$root" BL_BOOTSTRAP_INSTALL=1 TMPDIR="$root/tmp" BEAM_LISP_AOT_CACHE_DIR="$root/aot-cache"
unset BEAM_LISP_EBIN BEAM_LISP_PATH BL_ROOT BL_EBIN BL_BIN BL_BUILD_ID
mkdir -p "$root/tmp" "$root/aot-cache"
cd /home/user/code/undefine/beam-lisp
"$root/source-bootstrap-wrapper"
