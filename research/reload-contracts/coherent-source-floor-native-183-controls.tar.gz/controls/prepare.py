#!/usr/bin/env python3
"""ROOT ONLY, after final source landing. No VM; no seed/manifests synthesized."""
import hashlib,json,shutil,subprocess,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
MAIN=Path('/home/user/code/undefine/beam-lisp')
R2=HERE.parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert len(sys.argv)==2 and len(sys.argv[1])==64, 'Usage: prepare.py REVIEWED_FINAL_AOT_SHA256'
assert sha(MAIN/'priv/host/aot.bl')==sys.argv[1], 'Reviewed final AOT source is not landed'
old=json.loads((R2/'bootstrap-online-170/physical-inputs.json').read_text())
bridge=R2/'actor-input-env-bridge-179d'
bi=json.loads((bridge/'inputs.json').read_text())
# These accepted candidate bytes must have landed before any builder starts.
for rel in ['priv/host/env.bl','priv/boot/compiler.bl']:
 row=bi['inputs'][rel]
 assert sha(MAIN/rel)==row['candidateSha256'], f'Accepted179 bridge not landed: {rel}'
assert sha(MAIN/'scripts/regenerate-seed.bl')=='99040f36913f6e3953f9b849bf8042d1baabf171364a3540f97b751901fe302c'
k=json.loads((R2/'bootstrap-online-170/kernel-prelude-inputs.json').read_text())
k['accepted179_inputs_sha256']=sha(bridge/'inputs.json')
k['accepted181_inputs_sha256']=sha(R2/'constructor-atom-native-181/inputs.json')
k['sources']=[x for x in k['sources'] if x['path']!='priv/boot/compiler.bl']
k['sources'] += [{'path':rel,'sha256':bi['inputs'][rel]['candidateSha256']} for rel in ['priv/host/env.bl','priv/boot/compiler.bl']]
k['artifacts']=[x for x in k['artifacts'] if x['unit']!='compiler']
for a in bi['replayArtifacts']:
 p=bridge/a['file']; assert sha(p)==a['sha256']
 k['artifacts'].append({'module':p.name[:-5], 'path':str(p), 'sha256':a['sha256'], 'unit':'env' if '/host/' in str(p) else 'compiler'})
k['unit_order']=['anf','lower','diag','reader','compiler'];k['module_count']=len(k['artifacts']);k['scope']='Accepted174/175 kernel plus179d bridge recovery compiler only; official full final regeneration still required'
for row in k['sources']: assert sha(MAIN/row['path'])==row['sha256'],row['path']
for row in k['artifacts']: assert sha(row['path'])==row['sha256'],row['path']
(HERE/'kernel-inputs.json').write_text(json.dumps(k,indent=2)+'\n')
# Copy complete177 boot-cache files unchanged. Normal build/run decides freshness;
# changed Compiler/AOT keys MUST rebuild. No key/stamp/log/manifest relabeling.
(HERE/'ebin').mkdir(exist_ok=True)
reused=[]
for p in sorted((R2/'bootstrap-recovery-177/ebin').iterdir()):
 if p.is_file():
  q=HERE/'ebin'/p.name;shutil.copyfile(p,q)
  reused.append({'path':str(q),'sha256':sha(q),'source':str(p)})
(HERE/'reused-177-cache.json').write_text(json.dumps(reused,indent=2)+'\n')
# Independent literal compiler-key reproduction. This exact algorithm is checked
# against accepted177 before applying the final source changes. Byte order is
# codegen ++ reverse([module,bytes] prepend accumulation), matching AOTCache.
hashparts=lambda ps:hashlib.sha256(b'\0'.join(ps)).hexdigest()
leaves=['aot','atom_guard','compiler_data','source_graph','ns_interface','build_plan','record','emit','optimize','link','tiers']
names=['AOT','AtomGuard','CompilerData','SourceGraph','NamespaceInterface','BuildPlan','Record','Emit','Optimize','Link','Tiers']
parts=[b'codegen']
for leaf,name in zip(leaves,names):parts.extend([(MAIN/'priv/host'/f'{leaf}.bl').read_bytes(),('Elixir.BeamLisp.'+name).encode()])
codegen=hashparts(parts)
tier=sorted(list((MAIN/'priv/boot').rglob('*.bl'))+list((MAIN/'priv/self').rglob('*.bl')))
key=hashparts([b'elixir:1.20.4',b'otp:29',b'aot_backend:core',('codegen-source:'+codegen).encode()]+[p.read_bytes() for p in tier])
sourcepaths=sorted(set(x['path'] for x in old['sources'])|set(str(p.relative_to(MAIN)) for p in tier))
# Entire build-driver closure is frozen as well as all host/boot sources.
sourcepaths=sorted(set(sourcepaths)|{'scripts/regenerate-seed.bl','scripts/install-seed.bl','env.bl'}|set(str(p.relative_to(MAIN)) for p in (MAIN/'priv/build').rglob('*.bl')))
files={p.name:sha(p) for p in HERE.iterdir() if p.is_file() and p.name not in ['inputs.json','PLAN.org']}
x={'scope':'ROOT ONLY final coherent recovery build, not ordinary launcher acceptance','source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=MAIN,text=True).strip(),'runtime':{'elixir':'1.20.4','otp':'29','backend':'core'},'expected_compiler_key':key,'codegen_digest':codegen,'sources':[{'path':p,'sha256':sha(MAIN/p)} for p in sourcepaths],'native_assets':old['native_assets'],'files':files,'project_assertions':15,'boot_cache_policy':'Exact177 bytes copied; build/run current-key+source+closure checks decide reuse; stale entries compile normally.'}
for row in x['native_assets']:
 p=Path(row['path']);p=p if p.is_absolute() else MAIN/p
 assert sha(p)==row['sha256'],str(p)
(HERE/'inputs.json').write_text(json.dumps(x,indent=2)+'\n')
print(json.dumps({'prepared':str(HERE),'sources':len(x['sources']),'native_assets':len(x['native_assets']),'recovery_modules':len(k['artifacts']),'compiler_key':key,'cache_files':len(reused)}))
