# Trusted recovery compiler only. Official regeneration still produces and
# checks the complete final source floor before manifest-last publication.
prelude_root = "/home/user/tmp/product-online-20261014/round2/final-floor-ready"
main = "/home/user/code/undefine/beam-lisp"
inputs = :json.decode(File.read!(prelude_root <> "/kernel-inputs.json"))
false = :ets.member(:beam_lisp_vars, :bl_sdk_runtime_lease)
sha = fn bytes -> Base.encode16(:crypto.hash(:sha256, bytes), case: :lower) end
# All current source identities and every exact accepted artifact are checked
# before loading any replacement. Prepared bytes are the bytes actually loaded.
Enum.each(inputs["sources"], fn row ->
 true = sha.(File.read!(main <> "/" <> row["path"])) == row["sha256"]
end)
prepared = Enum.map(Enum.sort_by(inputs["artifacts"], fn row -> if row["unit"] == "env", do: 0, else: 1 end), fn row ->
 bytes = File.read!(row["path"])
 true = sha.(bytes) == row["sha256"]
 module = String.to_existing_atom(row["module"])
 {:ok, {^module, md5}} = :beam_lib.md5(bytes)
 {row, module, bytes, md5}
end)
true = length(prepared) == inputs["module_count"]
previous = BeamLisp.Env.capture()
try do
Enum.each(prepared, fn {row, module, bytes, md5} ->
 {:module, ^module} = :code.load_binary(module, String.to_charlist(row["path"]), bytes)
 ^md5 = apply(module, :module_info, [:md5])
 IO.inspect(%{module: module, sha256: row["sha256"], executable_md5: Base.encode16(md5, case: :lower)}, label: "RECOVERY_KERNEL_ACCEPTED_174_179_ARTIFACT")
end)
Enum.each(inputs["unit_order"], fn unit ->
 rows = Enum.filter(prepared, fn {row, _, _, _} -> row["unit"] == unit end)
 modules = Enum.map(rows, fn {_, module, _, _} -> module end)
 directory = Path.dirname(elem(hd(rows), 0)["path"])
 true = :code.add_patha(String.to_charlist(directory))
 BeamLisp.AOTCache.run_init_modules(modules, directory)
end)
false = :ets.member(:beam_lisp_vars, :bl_sdk_runtime_lease)
IO.inspect(%{modules: length(prepared), sources: length(inputs["sources"]), sdk_runtime_lease: false, scope: :trusted_recovery_compiler_only}, label: "RECOVERY_KERNEL_PRELUDE_COMPLETE")

after
 BeamLisp.Env.bind(previous)
end
