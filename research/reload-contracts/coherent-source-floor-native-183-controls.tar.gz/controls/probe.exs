# ROOT ONLY recovery substrate. Fresh ordinary acceptance is a different VM.
root = System.fetch_env!("BL_PROBE_ROOT")
main = "/home/user/code/undefine/beam-lisp"
^main = File.cwd!()
sha = fn path -> Base.encode16(:crypto.hash(:sha256, File.read!(path)), case: :lower) end
inputs = :json.decode(File.read!(root <> "/inputs.json"))
for row <- inputs["sources"] ++ inputs["native_assets"] do
 true = sha.(main <> "/" <> row["path"]) == row["sha256"]
end
for {name, digest} <- inputs["files"] do
 true = sha.(root <> "/" <> name) == digest
end
Application.load(:beam_lisp)
{:ok, deps} = :application.get_key(:beam_lisp, :applications)
Enum.each(deps, fn dep -> {:ok, _} = Application.ensure_all_started(dep) end)
:ok = BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
BeamLisp.AOT.boot()
false = :ets.member(:beam_lisp_vars, :bl_sdk_runtime_lease)
Code.eval_file(root <> "/kernel-prelude.exs")
System.put_env("BL_ROOT", main)
true = Code.prepend_path(main <> "/.bl/lib/beam_lisp-0.1.0/ebin")
BeamLisp.Env.add_search_path(main <> "/priv/build")
BeamLisp.AOTCache.reset_keys()
true = System.version() == inputs["runtime"]["elixir"]
true = List.to_string(:erlang.system_info(:otp_release)) == inputs["runtime"]["otp"]
true = BeamLisp.AOTCache.compiler_key() == inputs["expected_compiler_key"]
true = BeamLisp.AOTCache.current_compiler_key() == inputs["expected_compiler_key"]
IO.inspect(%{literal_expected: inputs["expected_compiler_key"], actual: BeamLisp.AOTCache.compiler_key()}, label: "FINAL_SOURCE_COMPILER_KEY_VERIFIED")
for row <- :json.decode(File.read!(root <> "/reused-177-cache.json")) do
 true = sha.(row["path"]) == row["sha256"]
end
# Cache candidates remain untouched. Official build/run checks all current
# source/closure/key stamps; changed codegen must rebuild, not relabel.
file = root <> "/project.direct.bl"
namespace = "regenerate-seed-project-test"
BeamLisp.Compiler.eval_string(File.read!(file), BeamLisp.Compiler.new_env(namespace), file)
Enum.each(["physical-project-preflight-ignores-missing-or-foreign-cli-cache", "invalid-physical-project-refuses-before-any-host-or-build-output"], fn name ->
 BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(namespace,name), [])
end)
report = BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(namespace,"direct-report"), [])
IO.inspect(report, label: "FINAL_PROJECT_PREFLIGHT_15_ASSERTIONS")
true = report[:pass] == 15 and report[:assertions] == 15
false = :ets.member(:beam_lisp_vars, :bl_sdk_runtime_lease)
script = main <> "/scripts/regenerate-seed.bl"
BeamLisp.Compiler.eval_string(File.read!(script), BeamLisp.Compiler.new_env("tooling.regenerate-seed"), script)
for row <- inputs["sources"] ++ inputs["native_assets"] do
 true = sha.(main <> "/" <> row["path"]) == row["sha256"]
end
IO.puts("FINAL_COHERENT_FLOOR_BUILD_CHECK_INSTALL_FINISHED")
System.halt(0)
