#!/bin/sh
trap 'exit 0' TERM
sleep 30 &
wait
