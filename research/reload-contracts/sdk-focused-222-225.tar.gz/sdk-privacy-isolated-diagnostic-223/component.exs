# Root-only diagnostic at the actual source launcher's final native -e seam.
# No custom SDK grants, Source overlays, manual pre-staging or receipt producers.
home=System.fetch_env!("BL_CACHE_COMPONENT_ROOT")
main=System.fetch_env!("BL_ROOT")
mode=System.fetch_env!("BL_CACHE_COMPONENT_MODE")
cache_home=System.fetch_env!("BEAM_LISP_AOT_CACHE_DIR")
inputs=:json.decode(File.read!(home<>"/component-inputs.json"))
sha=fn p->Base.encode16(:crypto.hash(:sha256,File.read!(p)),case: :lower) end
cache_snapshot=fn ->
 Path.wildcard(cache_home<>"/**/*",match_dot: true)
 |> Enum.filter(&File.regular?/1) |> Enum.sort()
 |> Enum.map(fn p->%{"path"=>Path.relative_to(p,cache_home),"sha256"=>sha.(p)} end)
end
safe_reason=fn reason->
 case reason do
  {code,ns} when code in [:sdk_declaration_stage_load_refused,:sdk_declaration_stage_initializer_refused] and is_binary(ns) ->
   %{code: code,namespace: if(ns in inputs["snapshotNamespaces"],do: ns,else: :other_sdk_namespace)}
  code when is_atom(code)->%{code: code}
  _->%{code: :unclassified}
 end
end
Process.put(:component_native_checks,0)
check=fn label,value->
 if value==true do
  Process.put(:component_native_checks,Process.get(:component_native_checks)+1)
  IO.puts("PASS "<>label)
 else
  throw({:component_check_failed,label})
 end
end
observe_final=fn ->
 for {key,mfa}<-[{:constructor_calls,{BeamLisp.AOT,:constructor_compile_sdk_unit!,2}}, {:restore_calls,{BeamLisp.AOT,:restore_sdk_staged_unit!,3}}] do
  case :erlang.trace_info(mfa,:call_count) do
   {:call_count,n} when is_integer(n)->Process.put(key,n)
   _->:ok
  end
 end
 if is_pid(Process.get(:macro_observer)) do
  for pid<-Process.get(:macro_traced_pids,[]),do: :erlang.trace(pid,false,[:call])
  :erlang.trace_pattern({BeamLisp.AOT,:staged_macro_lookup,2},false,[:local])
  ref=:erlang.trace_delivered(:all)
  receive do {:trace_delivered,:all,^ref}->:ok after 2000->:ok end
  send(Process.get(:macro_observer),{:stop,self()})
  receive do :macro_observer_stopped->:ok after 2000->:ok end
 end
 if is_pid(Process.get(:diagnostic_sampler)) do
  send(Process.get(:diagnostic_sampler),{:stop,Process.get(:diagnostic_sampler_phase_token),self()})
  receive do :diagnostic_sampler_stopped->:ok after 2000->:ok end
 end
end
public_exinfo=fn error->
 if is_map(error) and Map.get(error,:__struct__)==BeamLisp.ExInfo do
  message=Map.get(error,:message)
  raw=Map.get(error,:data)
  safe=if is_map(raw),do: Enum.reduce([:kind,:code,:namespace,:name,:macro],%{},fn key,out->
   value=Map.get(raw,key)
   cond do
    is_atom(value) and value != nil->Map.put(out,key,value)
    is_binary(value) and byte_size(value)<=256->Map.put(out,key,value)
    true->out
   end
  end),else: %{}
  %{code: :public_fixture_exinfo,message: if(is_binary(message),do: binary_part(message,0,min(byte_size(message),1024)),else: "unavailable"),data: safe,scope: "Only actual public privacy fixture; not private product Source"}
 else
  case error do %ErlangError{original: value}->safe_reason.(value);_->%{code: :unclassified} end
 end
end
try do
 verify=fn ->
  {_,0}=System.cmd("python3",[home<>"/preflight.py","--verify"])
  for {base,rows}<- [{main,inputs["sources"]},{main,inputs["nativeAssets"]},{main<>"/priv/bootstrap/seed",inputs["seed"]}] do
   check.("frozen-physical-inputs",Enum.all?(rows,fn r->
    p=base<>"/"<>r["path"];s=File.stat!(p)
    sha.(p)==r["sha256"] and s.inode==r["inode"] and s.major_device==r["device"]
   end))
  end
  check.("frozen-component",Enum.all?(inputs["files"],fn {p,d}->sha.(home<>"/"<>p)==d end))
  check.("actual-installed-manifest",sha.(main<>"/priv/bootstrap/seed/manifest.term")==inputs["manifestSha256"])
  check.("accepted-floor-parent",sha.(inputs["floorResult"])==inputs["floorResultSha256"])
  check.("accepted-floor-log",sha.(inputs["floorLog"])==inputs["floorLogSha256"])
 end
 verify.()
 Application.load(:beam_lisp)
 {:ok,deps}=:application.get_key(:beam_lisp,:applications)
 Enum.each(deps,fn dep->{:ok,_}=Application.ensure_all_started(dep) end)
 :ok=BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
 BeamLisp.AOT.boot()
 check.("compiler-key",BeamLisp.AOTCache.current_compiler_key()==inputs["compilerKey"])
 check.("build-key",BeamLisp.AOTCache.build_key()==inputs["buildKey"])
 {:ok,[seed]}=:file.consult(String.to_charlist(main<>"/priv/bootstrap/seed/manifest.term"))
 seed_modules=Map.new(seed["modules"])
 native=fn ->
  for module<-[BeamLisp.AOT,BeamLisp.AOTCache,BeamLisp.Env,BeamLisp.Emit,BeamLisp.CompilerData,BeamLisp.Ns.Compiler] do
   {:module,^module}=Code.ensure_loaded(module)
   {^module,bytes,_}=:code.get_object_code(module)
   check.("actual-seed-object:"<>Atom.to_string(module),Base.encode16(:crypto.hash(:sha256,bytes),case: :lower)==Map.fetch!(seed_modules,Atom.to_string(module)<>".beam"))
   {:ok,{^module,md5}}=:beam_lib.md5(bytes)
   check.("actual-loaded-md5:"<>Atom.to_string(module),md5==apply(module,:module_info,[:md5]))
  end
 end
 native.()
 check.("fresh-process-no-sdk-lease",not :ets.member(:beam_lisp_vars,:bl_sdk_runtime_lease))
 compile_mfa={BeamLisp.AOT,:constructor_compile_sdk_unit!,2}
 restore_mfa={BeamLisp.AOT,:restore_sdk_staged_unit!,3}
 check.("real-constructor-counter",:erlang.trace_pattern(compile_mfa,true,[:local,:call_count])==1)
 check.("real-cache-restore-counter",:erlang.trace_pattern(restore_mfa,true,[:local,:call_count])==1)
 Process.put(:diagnostic_sampler_context,%{home: home,mode: mode,owner: self(),compileMfa: compile_mfa,restoreMfa: restore_mfa,settings: inputs["sampler"]})
 Code.eval_file(home<>"/sampler.exs")
 Code.eval_file(home<>"/macro-observer.exs")
 eval_fixture=fn role->
  fixture=Map.fetch!(inputs["fixtures"],role)
  check.("exact-original:"<>role,sha.(home<>"/"<>fixture["original"])==fixture["sha256"])
  file=home<>"/"<>fixture["direct"]
  BeamLisp.Compiler.eval_string(File.read!(file),BeamLisp.Compiler.new_env(fixture["namespace"]),file)
  Map.put(fixture,"role",role)
 end
 report=fn fixture->BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(fixture["namespace"],"direct-report"),[]) end
 persist=fn ->
  p=%{caseReports: Process.get(:case_reports,[]),fixtureReports: Process.get(:fixture_reports,%{}),constructorCompileCalls: Process.get(:constructor_calls),cacheRestoreCalls: Process.get(:restore_calls),automaticDiagnosticStageElapsedUs: Process.get(:automatic_stage_elapsed_us)}
  File.write!(home<>"/"<>mode<>"-progress.json.tmp",:json.encode(p))
  File.rename!(home<>"/"<>mode<>"-progress.json.tmp",home<>"/"<>mode<>"-progress.json")
  p
 end
 invoke=fn fixture,function->
  role=fixture["role"];before=report.(fixture);start=System.monotonic_time(:microsecond)
  send(Process.get(:diagnostic_sampler),{:phase,Process.get(:diagnostic_sampler_phase_token),role,function})
  Process.put(:case_returned,false)
  try do
   BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(fixture["namespace"],function),[])
   Process.put(:case_returned,true)
  after
   current=report.(fixture)
   delta=Map.new([:assertions,:passed,:failed],fn k->{k,current[k]-before[k]} end)
   row=%{role: role,caseName: function,returned: Process.get(:case_returned),assertions: delta,elapsedUs: System.monotonic_time(:microsecond)-start}
   Process.put(:case_reports,Process.get(:case_reports,[])++[row])
   Process.put(:fixture_reports,Map.put(Process.get(:fixture_reports,%{}),role,current))
   persist.()
   IO.inspect(row,label: "SDK_DIAGNOSTIC_CASE_COUNTERS")
  end
 end
 reports=(fn ->
  privacy=eval_fixture.("privacy")
  Enum.each(privacy["functions"],&invoke.(privacy,&1))
  %{"privacy"=>report.(privacy)}
 end).()
 Enum.each(reports,fn {role,r}->
  n=inputs["expectedAssertions"][role]
  check.("exact-native-assertion-count:"<>role,r[:assertions]==n and r[:passed]==n and r[:failed]==0)
 end)
 core_assertions=Enum.reduce(reports,0,fn {_,r},n->n+r[:assertions] end)
 check.("exact-core-assertions",core_assertions==inputs["expectedCoreAssertions"][mode])
 verify.();native.()
 observe_final.()
 result=%{mode: mode,accepted: true,acceptanceRole: "isolated-privacy-component-diagnostic",benchmark: false,coreAssertions: core_assertions,assertions: reports,nativeChecks: Process.get(:component_native_checks),constructorCompileCalls: Process.get(:constructor_calls),cacheRestoreCalls: Process.get(:restore_calls),automaticDiagnosticStageElapsedUs: Process.get(:automatic_stage_elapsed_us),caseReports: Process.get(:case_reports,[]),cacheLabel: "Empty isolated privacy component cache; no automatic cold/warm benchmark",units: Process.get(:unit_snapshot),cache: cache_snapshot.(),scope: inputs["scope"]}
 File.write!(home<>"/"<>mode<>"-result.json",:json.encode(result))
 IO.inspect(Map.drop(result,[:units,:cache]),label: "SDK_PRIVACY_AUTOMATIC_NATIVE_RESULT")
 IO.puts("DIAGNOSTIC_PRIVACY_79_FINISHED")
 System.halt(0)
rescue
 error->
  observe_final.()
  diagnostic=public_exinfo.(error)
  stack=Enum.take(__STACKTRACE__,8)|>Enum.map(fn {m,f,a,_}->%{module: m,function: f,arity: if(is_integer(a),do: a,else: length(a))} end)
  result=%{mode: mode,accepted: false,errorClass: error.__struct__,diagnostic: diagnostic,stack: stack,nativeChecks: Process.get(:component_native_checks),caseReports: Process.get(:case_reports,[]),fixtureReports: Process.get(:fixture_reports,%{}),constructorCompileCalls: Process.get(:constructor_calls),cacheRestoreCalls: Process.get(:restore_calls),automaticDiagnosticStageElapsedUs: Process.get(:automatic_stage_elapsed_us)}
  File.write!(home<>"/"<>mode<>"-result.json",:json.encode(result));IO.inspect(result,label: "SDK_PRIVACY_AUTOMATIC_NATIVE_REFUSAL");System.halt(70)
catch
 kind,reason->
  observe_final.()
  diagnostic=case reason do {:component_check_failed,label}->%{code: :component_check_failed,label: label};_->safe_reason.(reason) end
  result=%{mode: mode,accepted: false,kind: kind,diagnostic: diagnostic,nativeChecks: Process.get(:component_native_checks),caseReports: Process.get(:case_reports,[]),fixtureReports: Process.get(:fixture_reports,%{}),constructorCompileCalls: Process.get(:constructor_calls),cacheRestoreCalls: Process.get(:restore_calls),automaticDiagnosticStageElapsedUs: Process.get(:automatic_stage_elapsed_us)}
  File.write!(home<>"/"<>mode<>"-result.json",:json.encode(result));IO.inspect(result,label: "SDK_PRIVACY_AUTOMATIC_NATIVE_REFUSAL");System.halt(70)
end
