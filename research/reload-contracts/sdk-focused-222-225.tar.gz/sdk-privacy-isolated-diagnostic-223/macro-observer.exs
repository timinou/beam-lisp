# Isolated PUBLIC privacy fixture only. Trace metadata omits ordinary call arguments;
# the custom event carries only actual public core/proc.server macro names.
# No returned values, Source forms, environment/context maps or caps are output.
owner=self()
home=System.fetch_env!("BL_CACHE_COMPONENT_ROOT")
observer=spawn(fn ->
 monitor=Process.monitor(owner)
 persist=fn rows,count->
  result=%{scope: "Actual public privacy fixture macro lookups only",observedLookups: count,lastLookups: rows,maximumSaved: 64}
  File.write!(home<>"/privacy-macro-lookups.json.tmp",:json.encode(result))
  File.rename!(home<>"/privacy-macro-lookups.json.tmp",home<>"/privacy-macro-lookups.json")
 end
 persist.([],0)
 loop=fn loop,rows,count->
  receive do
   {:trace,_pid,:call,{BeamLisp.AOT,:staged_macro_lookup,2},{:macro_lookup,namespace,name}}
       when namespace in ["core","proc.server"] and is_binary(name) and byte_size(name)<=128->
    next=Enum.take(rows++[%{namespace: namespace,name: name}],-64)
    if rem(count+1,16)==0,do: persist.(next,count+1)
    loop.(loop,next,count+1)
   {:stop,^owner}->persist.(rows,count);send(owner,:macro_observer_stopped)
   {:DOWN,^monitor,:process,^owner,_}->:ok
   _->loop.(loop,rows,count)
  end
 end
 loop.(loop,[],0)
end)
mfa={BeamLisp.AOT,:staged_macro_lookup,2}
match=[{[:"$1",:"$2"],[{:is_binary,:"$1"},{:is_binary,:"$2"}],[{:message,{{:macro_lookup,:"$1",:"$2"}}}]}]
1=:erlang.trace_pattern(mfa,match,[:local])
pids=Enum.uniq([owner,Process.whereis(BeamLisp.Env)])|>Enum.filter(&is_pid/1)
for pid<-pids do
 {:tracer,[] }=:erlang.trace_info(pid,:tracer)
 1=:erlang.trace(pid,true,[:call,:arity,{:tracer,observer}])
end
Process.put(:macro_observer,observer)
Process.put(:macro_traced_pids,pids)
