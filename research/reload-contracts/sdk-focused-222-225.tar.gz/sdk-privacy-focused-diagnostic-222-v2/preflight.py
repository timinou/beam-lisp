#!/usr/bin/env python3
"""Read-only physical/provenance verification; reserve only the explicit launch slot."""
from pathlib import Path
import hashlib,json,os,subprocess,sys
HERE=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def inventory(root):
 rows=[]
 assert root.is_dir() and not root.is_symlink()
 for p in sorted(root.rglob('*')):
  assert not p.is_symlink(),'cache symlink refused'
  if p.is_dir():continue
  assert p.is_file() and p.stat().st_size>0,'cache non-regular or empty file refused'
  rows.append({'path':str(p.relative_to(root)),'sha256':sha(p),'bytes':p.stat().st_size})
 assert rows and len(rows)<=4096 and sum(r['bytes'] for r in rows)<=256*1024*1024
 return rows
def verify_rows(root,rows):
 for r in rows:
  p=root/r['path'];s=p.stat()
  if p.is_symlink():
   link=p.lstat();assert r.get('sourceAlias')=={'target':os.readlink(p),'device':link.st_dev,'inode':link.st_ino,'mtimeNs':link.st_mtime_ns} and r['path']=='research/js-actors/runtime.bl'
  else:assert 'sourceAlias' not in r
  assert (s.st_dev,s.st_ino,sha(p))==(r['device'],r['inode'],r['sha256']),'physical input drift: '+r['path']
def verify():
 x=json.loads((HERE/'component-inputs.json').read_text());main=Path(x['main'])
 for label in ['floorInputs','floorResult','floorLog']:assert sha(x[label])==x[label+'Sha256']
 assert len(x['seed'])==104
 if x.get('sdkSourceSuccessor'):
  from source_successor import project
  assert project(main,Path(x['floorInputs']),enabled=True)==x['sdkSourceSuccessor']
 for name,digest in x['files'].items():assert sha(HERE/name)==digest,'control drift: '+name
 verify_rows(main,x['sources']);verify_rows(main,x['nativeAssets']);verify_rows(main/'priv/bootstrap/seed',x['seed'])
 paths=subprocess.check_output(['git','ls-files','-z'],cwd=main).decode().split('\0')
 assert {p:sha(main/p) for p in paths if p and (main/p).is_file()}==x['trackedMain'],'tracked Main content/inventory drift'
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=main).decode().strip()==x['sourceCommit']
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=main),'Main must remain clean'
 actual={str(p.relative_to(main)) for p in (main/'priv').rglob('*') if p.is_file() and p.name.endswith(tuple(x['sourceExtensions']))}
 expected={r['path'] for r in x['sources'] if r['path'].startswith('priv/') and r['path'].endswith(tuple(x['sourceExtensions']))}
 assert actual==expected,'physical Source addition/removal'
 assert sha(main/'priv/bootstrap/seed/manifest.term')==x['manifestSha256']
 p=x['priorFailedObservation'];assert p['accepted'] is False
 for label in ['inputs','result','parent','log']:assert sha(p[label])==p[label+'Sha256'],'failed provenance drift'
 return x
if __name__=='__main__':
 x=verify()
 if sys.argv[1:]!=['--verify']:
  assert sys.argv[1:]==['focused']
  assert not list((HERE/'aot-cache').rglob('*')),'focused component cache must begin empty'
  assert not list((HERE/'images/focused/lib/beam_lisp-0.1.0/ebin').iterdir()),'fresh native image required'
  with (HERE/'focused-started.json').open('x') as f:json.dump({'mode':'focused','inputsSha256':sha(HERE/'component-inputs.json'),'cache':[],'pid':os.getpid()},f)
 print(json.dumps({'preflight':'PASS','VMsLaunched':0,'mode':sys.argv[1:],'cacheAccepted':False}))
