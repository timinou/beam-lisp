# Read-only native binding metadata; never execute prepare! or any SDK issuer.
home=System.fetch_env!("BL_CACHE_COMPONENT_ROOT")
main=System.fetch_env!("BL_ROOT")
inputs=:json.decode(File.read!(home<>"/component-inputs.json"))
persist=fn value ->
 File.write!(home<>"/binding-result.json.tmp",:json.encode(value))
 File.rename!(home<>"/binding-result.json.tmp",home<>"/binding-result.json")
end
counters=fn ->
 Map.new([{:constructorCompileCalls,{BeamLisp.AOT,:constructor_compile_sdk_unit!,2}},{:cacheRestoreCalls,{BeamLisp.AOT,:restore_sdk_staged_unit!,3}}],fn {key,mfa}->
  n=case :erlang.trace_info(mfa,:call_count) do {:call_count,v} when is_integer(v)->v;_->nil end
  {key,n}
 end)
end
try do
 {_,0}=System.cmd("python3",[home<>"/preflight.py","--verify"])
 Application.load(:beam_lisp)
 {:ok,deps}=:application.get_key(:beam_lisp,:applications)
 Enum.each(deps,fn d->{:ok,_}=Application.ensure_all_started(d) end)
 :ok=BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
 BeamLisp.AOT.boot()
 true=BeamLisp.AOTCache.current_compiler_key()==inputs["compilerKey"]
 true=BeamLisp.AOTCache.build_key()==inputs["buildKey"]
 false=:ets.member(:beam_lisp_vars,:bl_sdk_runtime_lease)
 {:ok,[manifest]}=:file.consult(String.to_charlist(main<>"/priv/bootstrap/seed/manifest.term"))
 modules=Map.new(manifest["modules"])
 for module<-[BeamLisp.Loader,BeamLisp.Env,BeamLisp.AOT,BeamLisp.AOTCache] do
  {:module,^module}=Code.ensure_loaded(module)
  {^module,bytes,_}=:code.get_object_code(module)
  true=Base.encode16(:crypto.hash(:sha256,bytes),case: :lower)==Map.fetch!(modules,Atom.to_string(module)<>".beam")
  {:ok,{^module,md5}}=:beam_lib.md5(bytes)
  true=md5==apply(module,:module_info,[:md5])
 end
 1=:erlang.trace_pattern({BeamLisp.AOT,:constructor_compile_sdk_unit!,2},true,[:local,:call_count])
 1=:erlang.trace_pattern({BeamLisp.AOT,:restore_sdk_staged_unit!,3},true,[:local,:call_count])
 IO.puts("BINDING_DIAGNOSTIC_BEGIN_GENUINE_LOADER_ONLY")
 t=System.monotonic_time(:microsecond)
 BeamLisp.Loader.ensure_loaded("reload.generation")
 elapsed=System.monotonic_time(:microsecond)-t
 false=:ets.member(:beam_lisp_vars,:bl_sdk_runtime_lease)
 callable=BeamLisp.Env.fetch_exact!("reload.generation","prepare!")
 true=is_function(callable)
 info=Map.new(for key<-[:module,:type,:name,:arity],do: {key,elem(:erlang.fun_info(callable,key),1)})
 entries=Map.fetch!(BeamLisp.Env.ns_defs("reload.generation"),"prepare!")
 true=is_list(entries) and length(entries)<=32
 projected=Enum.map(entries,fn entry->
  true=is_tuple(entry) and tuple_size(entry)>=5
  kind=elem(entry,0);arity=elem(entry,1);name=elem(entry,2);provider=elem(entry,4)
  true=kind in [:fixed,:variadic] and is_integer(arity) and is_atom(name) and is_atom(provider)
  %{kind: kind,module: provider,function: name,arity: arity,matchesCallableModule: provider==info.module,matchesCallableName: name==info.name,matchesCallableArity: arity==info.arity}
 end)
 link=case BeamLisp.Env.link_owner("reload.generation","prepare!") do
  {:ok,provider,{module,fixed,variadic}} when is_binary(provider) and is_atom(module) and is_map(fixed)->
   true=provider=="reload.generation" and map_size(fixed)<=32
   mfas=Enum.map(fixed,fn {arity,name}->
    true=is_integer(arity) and is_atom(name)
    %{module: module,function: name,arity: arity,matchesCallableModule: module==info.module,matchesCallableName: name==info.name,matchesCallableArity: arity==info.arity}
   end)
   variadic_mfa=case variadic do nil->nil;{arity,name} when is_integer(arity) and is_atom(name)->%{module: module,function: name,minimumArity: arity} end
   %{status: :ok,provider: provider,fixed: mfas,variadic: variadic_mfa}
  :error->%{status: :error}
 end
 {_,0}=System.cmd("python3",[home<>"/preflight.py","--verify"])
 result=Map.merge(%{diagnosticCompleted: true,accepted: false,scope: "Finite callable metadata only; no SDK admission/custody or startup benchmark",namespace: "reload.generation",binding: "prepare!",callable: info,definitions: projected,linkOwner: link,loaderElapsedUs: elapsed,sdkLeaseAbsent: true},counters.())
 persist.(result)
 IO.inspect(result,label: "BINDING_DIAGNOSTIC_FINITE_METADATA")
 IO.puts("BINDING_DIAGNOSTIC_FINISHED")
 System.halt(0)
rescue
 error->
  code=case error do %ErlangError{original: value} when is_atom(value)->value;_->:unclassified end
  stack=Enum.take(__STACKTRACE__,12)|>Enum.map(fn {m,f,args,_}->%{module: m,function: f,arity: if(is_integer(args),do: args,else: length(args))} end)
  persist.(Map.merge(%{diagnosticCompleted: false,accepted: false,errorClass: error.__struct__,code: code,stack: stack},counters.()))
  IO.puts("BINDING_DIAGNOSTIC_FAILED")
  System.halt(70)
catch
 kind,_reason->
  persist.(Map.merge(%{diagnosticCompleted: false,accepted: false,errorKind: kind,code: :unclassified},counters.()))
  System.halt(70)
end
