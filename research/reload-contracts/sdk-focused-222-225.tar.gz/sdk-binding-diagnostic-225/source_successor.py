"""Read-only SDK Source successor projection; receipts never grant native custody."""
from pathlib import Path
import hashlib,json,os,stat,subprocess
HERE=Path(__file__).resolve().parent
SOURCE_EXTENSIONS=('.bl','.bl.md','.bl.org','.clj','.cljc')
CRITICAL_ROOTS=('priv','native','tooling','scripts','lib','config','bin')
SKIP_DIRS={'target','_build','deps','.git','node_modules','__pycache__'}
REVIEWED_RUNTIME_LEAF='priv/lib/datom/conn.bl'
DOCUMENTATION_EXTENSIONS=('.org','.md','.json','.png','.jpg','.jpeg','.svg','.tar.gz','.tgz','.csv','.txt','.log','.sha256','.pdf','.webp','.gif','.zip')
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def git(main,*args):return subprocess.check_output(['git',*args],cwd=main).strip()
def physical(path):
 path=Path(path);s=path.lstat();assert stat.S_ISREG(s.st_mode) and not path.is_symlink(),'Physical regular Source/native input required'
 return {'sha256':sha(path),'device':s.st_dev,'inode':s.st_ino,'bytes':s.st_size,'mtimeNs':s.st_mtime_ns,'mode':stat.S_IMODE(s.st_mode)}
def allowed(path):return (path.startswith(('priv/std/','test/','examples/')) and path.endswith(SOURCE_EXTENSIONS)) or path==REVIEWED_RUNTIME_LEAF
def documentation(path):return path.startswith(('!tasks/','docs/','research/')) and not path.endswith(SOURCE_EXTENSIONS) and path.endswith(DOCUMENTATION_EXTENSIONS)
def seed_path(path):return path.startswith('priv/bootstrap/seed/')
def tree(main,commit):
 rows={}
 for row in git(main,'ls-tree','-rz','--full-tree',commit).split(b'\0'):
  if not row:continue
  meta,path=row.split(b'\t',1);mode,kind,oid=meta.decode().split();assert kind=='blob','Gitlink input requires explicit review'
  rows[path.decode()]={'mode':mode,'oid':oid}
 return rows
def critical_inventory(main):
 main=Path(main);paths=set()
 for root in CRITICAL_ROOTS:
  for current,dirs,files in os.walk(main/root,followlinks=False):
   dirs[:]=[d for d in dirs if d not in SKIP_DIRS and not (Path(current)==main/'priv' and d=='std') and not (Path(current)==main/'priv/bootstrap' and d=='seed')]
   for name in dirs:assert not (Path(current)/name).is_symlink(),'Critical directory symlink requires review'
   paths.update(Path(current)/name for name in files)
 # Top-level tracked configuration/control inputs also retain physical identity.
 for path in tree(main,'HEAD'):
  if '/' not in path:paths.add(main/path)
 return [{'path':str(p.relative_to(main)),**physical(p)} for p in sorted(paths)]
def current_sources(main,floor):
 main=Path(main);tracked=tree(main,'HEAD');paths={main/r['path'] for r in floor['sources'] if (main/r['path']).exists()}
 paths|={p for p in (main/'priv').rglob('*') if p.is_file() and p.name.endswith(SOURCE_EXTENSIONS)}
 paths|={main/p for p in tracked if p.endswith(SOURCE_EXTENSIONS) or p.endswith('.rs') or Path(p).name in ['Cargo.toml','Cargo.lock','build.rs']}
 rows=[]
 for p in sorted(paths):
  rel=str(p.relative_to(main));assert rel in tracked,'Untracked physical Source requires explicit review'
  if p.is_symlink():
   # Existing floor alias only. Neither a new alias nor a changed target is permitted.
   assert rel=='research/js-actors/runtime.bl' and tree(main,floor['source_commit']).get(rel)==tracked.get(rel) and tracked[rel]['mode']=='120000','Changed/new Source symlink refused'
   original=next(r for r in floor['sources'] if r['path']==rel)
   assert sha(p)==original['sha256'] and p.resolve().is_relative_to(main),'Floor Source alias target drift'
   link_text=os.readlink(p)
   expected_link=subprocess.check_output(['git','cat-file','blob',tracked[rel]['oid']],cwd=main).decode()
   assert link_text==expected_link,'Floor Source alias link text drift'
   target_rel=str(p.resolve().relative_to(main))
   assert target_rel=='priv/lib/js/actor/runtime.bl','Only original critical target accepted'
   baseline=json.loads((HERE/'critical-baseline.json').read_text())
   target_row=next(r for r in baseline['criticalPhysical'] if r['path']==target_rel)
   assert {'path':target_rel,**physical(p.resolve())}==target_row,'Floor Source alias critical target physical drift' 
   value=physical(p.resolve());value.pop('mode')
   link=p.lstat();value['sourceAlias']={'target':os.readlink(p),'gitMode':tracked[rel]['mode'],'gitBlob':tracked[rel]['oid'],'resolvedTarget':target_rel,'device':link.st_dev,'inode':link.st_ino,'mtimeNs':link.st_mtime_ns,'mode':stat.S_IMODE(link.st_mode)}
  else:
   value=physical(p);value.pop('mode')
  rows.append({'path':rel,**value})
 return rows
def project(main,floor_inputs,*,enabled=False):
 """Caller separately requires actual floor parent0. Returns explicit observation.
 Default: all floor Source bytes exact. enabled: reviewed Source-only successor
 plus non-Source documentation/evidence allowance. Conn leaf is explicit only.
 Both modes retain full critical baseline,12 native assets and104 accepted seed.
 """
 main=Path(main).resolve();floor_inputs=Path(floor_inputs).resolve();floor=json.loads(floor_inputs.read_text())
 baseline=json.loads((HERE/'critical-baseline.json').read_text())
 assert sha(floor_inputs)==baseline['floorInputsSha256'] and str(main)==baseline['main'],'Projection baseline does not name actual floor inputs/Main'
 assert not git(main,'status','--porcelain'),'Complete Main must be committed and clean'
 for name,digest in floor['files'].items():assert sha(floor_inputs.parent/name)==digest,'Immutable actual floor control drift'
 old=tree(main,floor['source_commit']);new=tree(main,'HEAD');changes=[];documents=[]
 for path in sorted(old.keys()|new.keys()):
  if old.get(path)==new.get(path):continue
  if seed_path(path):continue # Exact accepted installed seed is checked below.
  assert enabled and (allowed(path) or documentation(path)),'Unreviewed successor path refused: '+path
  for value in [old.get(path),new.get(path)]:assert value is None or value['mode'] in ['100644','100755'],'Successor symlink/gitlink refused'
  # git() strips output for textual control calls; raw blob bytes MUST not strip.
  def raw_digest(row):return hashlib.sha256(subprocess.check_output(['git','cat-file','blob',row['oid']],cwd=main)).hexdigest() if row else None
  target=changes if allowed(path) else documents
  target.append({'path':path,'old':old.get(path),'new':new.get(path),'oldSha256':raw_digest(old.get(path)),'newSha256':raw_digest(new.get(path)),
                  'change':'added' if path not in old else 'removed' if path not in new else 'modified'})
 for row in floor['sources']:
  if enabled and allowed(row['path']):continue
  assert sha(main/row['path'])==row['sha256'],'Actual floor non-SDK Source drift: '+row['path']
 critical=critical_inventory(main)
 protected=lambda rows:[r for r in rows if not (enabled and r['path']==REVIEWED_RUNTIME_LEAF)]
 assert protected(critical)==protected(baseline['criticalPhysical']),'Complete critical root path/physical identity drift'
 leaf=physical(main/REVIEWED_RUNTIME_LEAF)
 assert len(floor['native_assets'])==12
 for row in floor['native_assets']:assert sha(main/row['path'])==row['sha256'],'Actual floor native asset drift'
 assert sorted(str(p.relative_to(main)) for p in (main/'priv/native').glob('*.so'))==sorted(r['path'] for r in floor['native_assets'] if r['path'].endswith('.so')),'Native asset inventory addition/removal'
 seed=floor_inputs.parent/'seed';installed=main/'priv/bootstrap/seed'
 accepted=sorted(p for p in seed.rglob('*') if p.is_file());actual=sorted(p for p in installed.rglob('*') if p.is_file())
 assert len(accepted)==len(actual)==104,'Exactly104 actual accepted/installed seed files required'
 assert [str(p.relative_to(seed)) for p in accepted]==[str(p.relative_to(installed)) for p in actual]
 for p in accepted:
  q=installed/p.relative_to(seed);assert not p.is_symlink() and not q.is_symlink() and sha(p)==sha(q),'Installed seed differs from accepted actual floor'
 current=current_sources(main,floor)
 return {'schema':'beam-lisp.explicit-sdk-source-successor/v1','enabled':enabled,'floorInputs':str(floor_inputs),'floorInputsSha256':sha(floor_inputs),
         'floorSourceCommit':floor['source_commit'],'currentSourceCommit':git(main,'rev-parse','HEAD').decode(),
         'compilerKey':floor['expected_compiler_key'],'criticalBaseline':str(HERE/'critical-baseline.json'),'criticalBaselineSha256':sha(HERE/'critical-baseline.json'),
         'helperSha256':sha(HERE/'source_successor.py'),'sourceOnlyChanges':changes,'documentationEvidenceChanges':documents,
         'reviewedRuntimeLeaf':REVIEWED_RUNTIME_LEAF,'reviewedRuntimeLeafCurrent':leaf,'criticalPhysicalCount':len(protected(baseline['criticalPhysical'])),
         'nativeAssetsVerified':12,'acceptedInstalledSeedVerified':104,'currentPhysicalSources':current,
         'scope':'Floor receipt remains immutable and proves only its actual compiler/native inputs; changed Std Source requires subsequent native SDK closure acceptance; no SDK/Root/keeper authority granted'}
