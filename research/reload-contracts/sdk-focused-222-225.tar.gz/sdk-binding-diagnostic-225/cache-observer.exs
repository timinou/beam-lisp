# Native diagnostic instrumentation: actual sdk_stage_cached_unit/7 call/return.
# Ordinary args omitted by :arity. The returned map is type-tested immediately
# then discarded; no contents, Source, paths, PIDs or capabilities are emitted.
owner=self()
home=System.fetch_env!("BL_CACHE_COMPONENT_ROOT")
inputs=:json.decode(File.read!(home<>"/component-inputs.json"))
whitelist=MapSet.new(inputs["cacheProfile"]["publicNamespaces"])
blank=%{started: 0,finished: 0,hits: 0,misses: 0,other: 0,totalElapsedUs: 0}
observer=spawn(fn ->
 monitor=Process.monitor(owner)
 persist=fn overall,names,active->
  open=Enum.reduce(active,0,fn {_pid,frames},n->n+length(frames) end)
  result=%{scope: inputs["cacheProfile"]["scope"],actualMFA: inputs["cacheProfile"]["mfa"],
           overall: overall,publicNamespaces: names,outstanding: open,
           returnClassification: "map=validator hit;nil=validator miss; neither means SDK publication/custody acceptance"}
  File.write!(home<>"/automatic-cache-profile.json.tmp",:json.encode(result))
  File.rename!(home<>"/automatic-cache-profile.json.tmp",home<>"/automatic-cache-profile.json")
 end
 persist.(blank,%{},%{})
 Process.send_after(self(),:profile_tick,15000)
 loop=fn loop,overall,names,active->
  receive do
   {:trace_ts,pid,:call,{BeamLisp.AOT,:sdk_stage_cached_unit,7},{:cache_namespace,namespace},time}
       when is_binary(namespace) and is_integer(time)->
    label=if MapSet.member?(whitelist,namespace),do: namespace,else: "other-sdk-namespace"
    row=Map.update!(Map.get(names,label,blank),:started,&(&1+1))
    frames=Map.get(active,pid,[])
    if map_size(active)>256 or length(frames)>=128,do: exit(:cache_profile_observation_budget)
    loop.(loop,Map.update!(overall,:started,&(&1+1)),Map.put(names,label,row),Map.put(active,pid,[{label,time}|frames]))
   {:trace_ts,pid,:return_from,{BeamLisp.AOT,:sdk_stage_cached_unit,7},value,time} when is_integer(time)->
    case Map.get(active,pid,[]) do
     [{label,start}|rest]->
      # Never inspect or serialize the actual returned map's fields.
      classification=cond do is_map(value)->:hits;is_nil(value)->:misses;true->:other end
      elapsed=:erlang.convert_time_unit(max(time-start,0),:native,:microsecond)
      update=fn row->row|>Map.update!(:finished,&(&1+1))|>Map.update!(classification,&(&1+1))|>Map.update!(:totalElapsedUs,&(&1+elapsed)) end
      next=if rest==[],do: Map.delete(active,pid),else: Map.put(active,pid,rest)
      loop.(loop,update.(overall),Map.update!(names,label,update),next)
     []->loop.(loop,overall,names,active)
    end
   :profile_tick->persist.(overall,names,active);Process.send_after(self(),:profile_tick,15000);loop.(loop,overall,names,active)
   {:stop,^owner}->persist.(overall,names,active);send(owner,:cache_observer_stopped)
   {:DOWN,^monitor,:process,^owner,_}->:ok
   _->loop.(loop,overall,names,active)
  end
 end
 loop.(loop,blank,%{},%{})
end)
mfa={BeamLisp.AOT,:sdk_stage_cached_unit,7}
match=[{[:"$1",:_,:_,:_,:_,:_,:_],[{:is_binary,:"$1"}],
        [{:return_trace},{:message,{{:cache_namespace,:"$1"}}}]}]
1=:erlang.trace_pattern(mfa,match,[:local])
pids=Enum.uniq([owner,Process.whereis(BeamLisp.Env)])|>Enum.filter(&is_pid/1)
for pid<-pids do
 {:tracer,[] }=:erlang.trace_info(pid,:tracer)
 1=:erlang.trace(pid,true,[:call,:arity,:monotonic_timestamp,:set_on_spawn,{:tracer,observer}])
end
Process.put(:cache_observer,observer)
Process.put(:cache_traced_pids,pids)
