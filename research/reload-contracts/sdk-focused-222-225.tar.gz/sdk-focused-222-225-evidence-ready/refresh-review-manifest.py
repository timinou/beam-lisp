#!/usr/bin/env python3
"""Read current HOME candidate once; write a new review manifest, never Source or prior manifest."""
from pathlib import Path
import argparse,hashlib,json,re,subprocess
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
p=argparse.ArgumentParser();p.add_argument('--review-dir',required=True,type=Path);p.add_argument('--output-manifest',required=True,type=Path);p.add_argument('--main',type=Path,default=Path('/home/user/code/undefine/beam-lisp'));a=p.parse_args()
assert not a.output_manifest.exists()
old=json.loads((a.review_dir/'manifest.json').read_text());candidate=a.review_dir/'candidate';fixture=candidate/'test/bl/compiler_metadata_datum_test.bl';text=fixture.read_text()
cases=re.findall(r'^\(deftest\s+([^\s()]+)',text,re.M);assert len(cases)==7
assert len(re.findall(r'^\s*\(is\s',text,re.M))==42
files=[]
for f in sorted(candidate.rglob('*')):
 if f.is_file():
  rel=str(f.relative_to(candidate));files.append({'path':rel,'baselineSha256':sha(a.main/rel) if (a.main/rel).is_file() else None,'candidateSha256':sha(f)})
result={**old,'status':'REVIEW ONLY; Native UNRUN; refreshed actual HOME candidate identity, coherent regeneration required','previousManifestSha256':sha(a.review_dir/'manifest.json'),'newMetadataAssertionsExpected':23,'existingMetadataAssertionsExpected':19,'metadataAssertionsExpected':42,'metadataCasesExpected':7,'metadataCaseNames':cases,'files':files,'previousPatchSha256':sha(a.review_dir/'candidate.patch'),'patchCaveat':'Existing patch is preserved as a prior review input. Refresh actual diff from this exact candidate before landing; this manifest does not assert that prior patch represents updated bodies.','baselineCommitObserved':subprocess.check_output(['git','rev-parse','HEAD'],cwd=a.main,text=True).strip()}
a.output_manifest.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'manifest':str(a.output_manifest),'sha256':sha(a.output_manifest),'metadataCases':7,'metadataAssertions':42,'newMetadataAssertions':23,'native':'UNRUN'}))
