from pathlib import Path
import json,hashlib,ast,shutil
out=Path(__file__).resolve().parent;r2=out.parent;main=Path('/home/user/code/undefine/beam-lisp');prev=r2/'constructor-atom-native-181';src=r2/'actor-input-conjunction-181';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for leaf in ['input_guard_test.bl','input-domain.candidate.bl']:
 shutil.copyfile(src/leaf,out/leaf)
entry=main/'priv/std/reload/server-entry.bl';assert sha(entry)=='22fcbc9ed674b9d333321ae0415751ab6fc3e6af4d0f0ed96487d2aca38d0682';shutil.copyfile(entry,out/'server-entry.candidate.bl')
for leaf in ['kernel-prelude.exs','kernel-inputs.json','source-wrapper']:
 shutil.copyfile(prev/leaf,out/leaf)
(out/'source-wrapper').chmod(0o755)
# Keep the exact accepted181 prelude/input paths, retaining their frozen hashes.
old=r2/'product-rehearsal/build-record-direct.py';tree=ast.parse(old.read_text());scope={}
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.ClassDef) or isinstance(n,ast.FunctionDef) and n.name=='forms'],type_ignores=[]),str(old),'exec'),scope)
forms=scope['forms'];text=(out/'input_guard_test.bl').read_text();names=[];edits=[]
helper=(r2/'actor-input-env-bridge-179d/compiler_input_hook_test.direct.bl').read_text();helper=helper[helper.index('; Runner-only'):helper.index('(defn- compiler-call')]
def raw(n):return text[n.start:n.end]
def walk(n):
 h=raw(n.children[0]) if n.kind=='(' and n.children else None
 if h in ('quote','syntax-quote'):return
 if h=='deftest':names.append(raw(n.children[1]));edits.append((n.start,n.children[1].end,'(defn '+raw(n.children[1])+' []'))
 if h=='is':
  assert len(n.children)==2;e=raw(n.children[1]);edits.append((n.start,n.end,'(direct-check! '+json.dumps(e)+' (fn [] '+e+'))'));return
 for c in n.children:walk(c)
for n in forms(text):walk(n)
for a,b,s in sorted(edits,reverse=True):text=text[:a]+s+text[b:]
ns=next(n for n in forms(text) if n.kind=='(' and text[n.children[0].start:n.children[0].end]=='ns');text=text[:ns.end]+helper+text[ns.end:];(out/'guard.direct.bl').write_text(text)
artifact=prev/'host/Elixir.BeamLisp.AOT.beam';assert artifact.is_file()
x={'scope':'Source-only conjunction proof component using accepted181 AOT and179d recovery compiler; no ordinary launcher/SDK ownership claim','expectedAssertions':21,'functions':names,'aotArtifact':{'path':str(artifact),'sha256':sha(artifact)},'aotSourceSha256':'f293fdb96b765da2ce37aedc4bbb4b733fafc8f3392176d1692c49136d8c440b','productionCandidateSha256':sha(out/'input-domain.candidate.bl'),'fixtureSha256':sha(out/'input_guard_test.bl'),'files':{p.name:sha(p) for p in out.iterdir() if p.is_file() and p.name!='inputs.json'}}
(out/'inputs.json').write_text(json.dumps(x,indent=2)+'\n');print(json.dumps({'functions':len(names),'assertions':21,'fixtureSha256':x['fixtureSha256']}))
