root = System.fetch_env!("BL_PROBE_ROOT")
sha = fn p -> Base.encode16(:crypto.hash(:sha256,File.read!(p)),case: :lower) end
inputs = :json.decode(File.read!(root <> "/inputs.json"))
for {p,h} <- inputs["files"], do: true = sha.(root <> "/" <> p) == h
true = sha.(inputs["aotArtifact"]["path"]) == inputs["aotArtifact"]["sha256"]
Application.load(:beam_lisp)
{:ok,deps} = :application.get_key(:beam_lisp,:applications)
Enum.each(deps,fn d -> {:ok,_} = Application.ensure_all_started(d) end)
:ok = BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
BeamLisp.AOT.boot()
false = :ets.member(:beam_lisp_vars,:bl_sdk_runtime_lease)
Code.eval_file(root <> "/kernel-prelude.exs")
aot = inputs["aotArtifact"]["path"]
bytes = File.read!(aot)
{:module,BeamLisp.AOT} = :code.load_binary(BeamLisp.AOT,String.to_charlist(aot),bytes)
{:ok,{BeamLisp.AOT,md5}} = :beam_lib.md5(bytes)
^md5 = apply(BeamLisp.AOT,:module_info,[:md5])
IO.inspect(%{sha256: sha.(aot),md5: Base.encode16(md5,case: :lower)},label: "EXACT_ACCEPTED_181_AOT_REPLAY")
ns = "proc.input-guard-test"
file = root <> "/guard.direct.bl"
BeamLisp.Compiler.eval_string(File.read!(file),BeamLisp.Compiler.new_env(ns),file)
# Real provider initialization precedes temporary pure candidate overrides.
# No mark-ready shortcut or SDK unit receipt is created by the harness.
for namespace <- ["proc.input-domain","reload.server-entry","data.first-order"] do
 BeamLisp.Loader.ensure_loaded(namespace)
 true = BeamLisp.Env.loaded_ns?(namespace)
 true = BeamLisp.Env.ns_ready?(namespace)
end
for {namespace,leaf} <- [{"reload.server-entry","server-entry.candidate.bl"},{"proc.input-domain","input-domain.candidate.bl"}] do
 p = root <> "/" <> leaf
 BeamLisp.Compiler.eval_string(File.read!(p),BeamLisp.Compiler.new_env(namespace),p)
end
crashes = Enum.flat_map(inputs["functions"],fn name ->
 try do BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(ns,name),[]); []
 rescue e -> IO.inspect({name,e,BeamLisp.ExInfo.ex_data(e),__STACKTRACE__},label: "CONJUNCTION_COMPONENT_CASE_CRASH",limit: 35); [name]
 end
end)
report = BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(ns,"direct-report"),[])
IO.inspect(report,label: "CONJUNCTION_COMPONENT_21_ASSERTIONS",limit: :infinity)
false = :ets.member(:beam_lisp_vars,:bl_sdk_runtime_lease)
System.halt(if crashes==[] and report[:pass]==21 and report[:assertions]==21,do: 0,else: 1)
