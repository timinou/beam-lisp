# Root-only diagnostic at the actual source launcher's final native -e seam.
# No custom SDK grants, Source overlays, manual pre-staging or receipt producers.
home=System.fetch_env!("BL_CACHE_COMPONENT_ROOT")
main=System.fetch_env!("BL_ROOT")
mode=System.fetch_env!("BL_CACHE_COMPONENT_MODE")
inputs=:json.decode(File.read!(home<>"/component-inputs.json"))
sha=fn p->Base.encode16(:crypto.hash(:sha256,File.read!(p)),case: :lower) end
cache_snapshot=fn ->
 Path.wildcard(home<>"/aot-cache/**/*",match_dot: true)
 |> Enum.filter(&File.regular?/1) |> Enum.sort()
 |> Enum.map(fn p->%{"path"=>Path.relative_to(p,home<>"/aot-cache"),"sha256"=>sha.(p)} end)
end
safe_reason=fn reason->
 case reason do
  {code,ns} when code in [:sdk_declaration_stage_load_refused,:sdk_declaration_stage_initializer_refused] and is_binary(ns) ->
   %{code: code,namespace: if(ns in inputs["snapshotNamespaces"],do: ns,else: :other_sdk_namespace)}
  code when is_atom(code)->%{code: code}
  _->%{code: :unclassified}
 end
end
Process.put(:component_native_checks,0)
check=fn label,value->
 if value==true do
  Process.put(:component_native_checks,Process.get(:component_native_checks)+1)
  IO.puts("PASS "<>label)
 else
  throw({:component_check_failed,label})
 end
end
try do
 verify=fn ->
  for {base,rows}<- [{main,inputs["sources"]},{main,inputs["nativeAssets"]},{main<>"/priv/bootstrap/seed",inputs["seed"]}] do
   check.("frozen-physical-inputs",Enum.all?(rows,fn r->
    p=base<>"/"<>r["path"];s=File.stat!(p)
    sha.(p)==r["sha256"] and s.inode==r["inode"] and s.major_device==r["device"]
   end))
  end
  check.("frozen-component",Enum.all?(inputs["files"],fn {p,d}->sha.(home<>"/"<>p)==d end))
  check.("actual-installed-manifest",sha.(main<>"/priv/bootstrap/seed/manifest.term")==inputs["manifestSha256"])
  check.("accepted-floor-parent",sha.(inputs["floorResult"])==inputs["floorResultSha256"])
  check.("accepted-floor-log",sha.(inputs["floorLog"])==inputs["floorLogSha256"])
 end
 verify.()
 Application.load(:beam_lisp)
 {:ok,deps}=:application.get_key(:beam_lisp,:applications)
 Enum.each(deps,fn dep->{:ok,_}=Application.ensure_all_started(dep) end)
 :ok=BeamLisp.Bootstrap.install!(System.fetch_env!("BL_EBIN"))
 BeamLisp.AOT.boot()
 check.("compiler-key",BeamLisp.AOTCache.current_compiler_key()==inputs["compilerKey"])
 check.("build-key",BeamLisp.AOTCache.build_key()==inputs["buildKey"])
 {:ok,[seed]}=:file.consult(String.to_charlist(main<>"/priv/bootstrap/seed/manifest.term"))
 seed_modules=Map.new(seed["modules"])
 native=fn ->
  for module<-[BeamLisp.AOT,BeamLisp.AOTCache,BeamLisp.Env,BeamLisp.Emit,BeamLisp.CompilerData,BeamLisp.Ns.Compiler] do
   {:module,^module}=Code.ensure_loaded(module)
   {^module,bytes,_}=:code.get_object_code(module)
   check.("actual-seed-object:"<>Atom.to_string(module),Base.encode16(:crypto.hash(:sha256,bytes),case: :lower)==Map.fetch!(seed_modules,Atom.to_string(module)<>".beam"))
   {:ok,{^module,md5}}=:beam_lib.md5(bytes)
   check.("actual-loaded-md5:"<>Atom.to_string(module),md5==apply(module,:module_info,[:md5]))
  end
 end
 native.()
 check.("fresh-process-no-sdk-lease",not :ets.member(:beam_lisp_vars,:bl_sdk_runtime_lease))
 eval_fixture=fn role->
  fixture=Map.fetch!(inputs["fixtures"],role)
  check.("exact-original:"<>role,sha.(home<>"/"<>fixture["original"])==fixture["sha256"])
  file=home<>"/"<>fixture["direct"]
  BeamLisp.Compiler.eval_string(File.read!(file),BeamLisp.Compiler.new_env(fixture["namespace"]),file)
  fixture
 end
 invoke=fn fixture,function->
  start=System.monotonic_time(:microsecond)
  BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(fixture["namespace"],function),[])
  IO.inspect(%{caseName: function,elapsedUs: System.monotonic_time(:microsecond)-start},label: "SDK_PRIVACY_NATIVE_CASE")
 end
 report=fn fixture->BeamLisp.Ns.Rt.invoke(BeamLisp.Env.fetch_exact!(fixture["namespace"],"direct-report"),[]) end
 reports=if mode=="fault" do
  fixture=eval_fixture.("fault")
  Enum.each(fixture["functions"],&invoke.(fixture,&1))
  %{"fault"=>report.(fixture)}
 else
  # Run actual positioned Reader/macro API controls in the fresh kernel before
  # any constructor/restore tracing or automatic SDK issuer fixture work.
  initial_cache=cache_snapshot.()
  macro=eval_fixture.("macroAPI")
  Enum.each(macro["functions"],&invoke.(macro,&1))
  macro_report=report.(macro)
  check.("positioned-macro-api-thirteen-assertions",macro_report[:assertions]==13 and macro_report[:passed]==13 and macro_report[:failed]==0)
  check.("macro-api-keeps-fresh-sdk-origin",not :ets.member(:beam_lisp_vars,:bl_sdk_runtime_lease))
  check.("macro-api-does-not-prestage-sdk",cache_snapshot.()==initial_cache)
  if mode=="cold",do: check.("cold-cache-still-empty-after-macro-api",cache_snapshot.()==[])
  compile_mfa={BeamLisp.AOT,:constructor_compile_sdk_unit!,2}
  restore_mfa={BeamLisp.AOT,:restore_sdk_staged_unit!,3}
  check.("real-constructor-counter",:erlang.trace_pattern(compile_mfa,true,[:local,:call_count])==1)
  check.("real-cache-restore-counter",:erlang.trace_pattern(restore_mfa,true,[:local,:call_count])==1)
  auto=eval_fixture.("automatic")
  check.("automatic-compile-keeps-fresh-sdk-origin",not :ets.member(:beam_lisp_vars,:bl_sdk_runtime_lease))
  [first,second]=auto["functions"]
  started=System.monotonic_time(:microsecond)
  invoke.(auto,first)
  # Definition-only fixture setup happens after the genuine first automatic
  # graph issuer. The queue hook verifies actual generated owner metadata.
  privacy=eval_fixture.("privacy")
  before_hook=report.(privacy)
  invoke.(privacy,"assert-genuine-staged-queue-runtime!")
  after_hook=report.(privacy)
  check.("queue-hook-seven-real-assertions",after_hook[:assertions]-before_hook[:assertions]==7 and after_hook[:passed]-before_hook[:passed]==7 and after_hook[:failed]==0)
  {:call_count,compiled}=:erlang.trace_info(compile_mfa,:call_count)
  {:call_count,restored}=:erlang.trace_info(restore_mfa,:call_count)
  :erlang.trace_pattern(compile_mfa,false,[:local,:call_count])
  :erlang.trace_pattern(restore_mfa,false,[:local,:call_count])
  check.("actual-cold-or-warm-constructor-work",if(mode=="cold",do: compiled>0,else: compiled==0))
  if mode=="warm",do: check.("actual-cache-restore-work",restored>0)
  Process.put(:constructor_calls,compiled);Process.put(:restore_calls,restored)
  Process.put(:automatic_stage_elapsed_us,System.monotonic_time(:microsecond)-started)
  snapshot=Enum.map(inputs["snapshotNamespaces"],fn ns->
   shim=BeamLisp.Emit.module_for(ns)
   check.("actual-complete-unit:"<>ns,BeamLisp.AOT.sdk_unit_compiled?(ns))
   row=apply(BeamLisp.AOT,:source_sdk_receipt,[shim])
   key=BeamLisp.AOTCache.key_for_ns(ns);closure=BeamLisp.AOT.ns_closure_hash(ns)
   entry=apply(BeamLisp.AOTCache,:entry_dir,[key,closure])
   modules=[shim|row[:"unit-references"]]
   check.("actual-valid-persistent-entry:"<>ns,Enum.sort(apply(BeamLisp.AOTCache,:valid_keyed_entry,[entry,key,closure])||[])==Enum.sort(modules))
   objects=Enum.map(modules,fn module->
    bytes=File.read!(entry<>"/"<>Atom.to_string(module)<>".beam")
    receipt=apply(BeamLisp.AOT,:source_sdk_receipt,[module])
    {:ok,{^module,md5}}=:beam_lib.md5(bytes)
    check.("actual-cache-and-loaded-object:"<>Atom.to_string(module),receipt[:sha256]==:crypto.hash(:sha256,bytes) and md5==apply(module,:module_info,[:md5]))
    %{"module"=>Atom.to_string(module),"sha256"=>Base.encode16(receipt[:sha256],case: :lower),"md5"=>Base.encode16(md5,case: :lower)}
   end)|>Enum.sort_by(& &1["module"])
   %{"namespace"=>ns,"key"=>key,"closure"=>closure,"sourceDigest"=>Base.encode16(row[:"source-digest"],case: :lower),"native"=>objects}
  end)
  if mode=="warm" do
   cold=:json.decode(File.read!(home<>"/cold-result.json"))
   check.("same-genuine-cold-native-objects",snapshot==cold["units"])
   Process.put(:sdk_privacy_negative_context,%{home: home,main: main,inputs: inputs,check: check})
   Code.eval_file(home<>"/cache-negative.exs")
  end
  Process.put(:unit_snapshot,snapshot)
  invoke.(auto,second)
  Enum.each(privacy["functions"],&invoke.(privacy,&1))
  privacy_report=report.(privacy)
  %{"macroAPI"=>macro_report,"automatic"=>report.(auto),"queueHook"=>%{assertions: 7,passed: 7,failed: 0},"privacy"=>%{assertions: privacy_report[:assertions]-7,passed: privacy_report[:passed]-7,failed: privacy_report[:failed]}}
 end
 Enum.each(reports,fn {role,r}->
  n=inputs["expectedAssertions"][role]
  check.("exact-native-assertion-count:"<>role,r[:assertions]==n and r[:passed]==n and r[:failed]==0)
 end)
 core_assertions=Enum.reduce(reports,0,fn {_,r},n->n+r[:assertions] end)
 check.("exact-core-assertions",core_assertions==if(mode=="fault",do: 12,else: 113))
 verify.();native.()
 result=%{mode: mode,accepted: true,coreAssertions: core_assertions,assertions: reports,nativeChecks: Process.get(:component_native_checks),constructorCompileCalls: Process.get(:constructor_calls),cacheRestoreCalls: Process.get(:restore_calls),automaticStageElapsedUs: Process.get(:automatic_stage_elapsed_us),units: Process.get(:unit_snapshot),cache: cache_snapshot.(),scope: inputs["scope"]}
 File.write!(home<>"/"<>mode<>"-result.json",:json.encode(result))
 IO.inspect(Map.drop(result,[:units,:cache]),label: "SDK_PRIVACY_AUTOMATIC_NATIVE_RESULT")
 System.halt(0)
rescue
 error->
  diagnostic=case error do %ErlangError{original: value}->safe_reason.(value);_->%{code: :unclassified} end
  stack=Enum.take(__STACKTRACE__,8)|>Enum.map(fn {m,f,a,_}->%{module: m,function: f,arity: if(is_integer(a),do: a,else: length(a))} end)
  result=%{mode: mode,accepted: false,errorClass: error.__struct__,diagnostic: diagnostic,stack: stack,nativeChecks: Process.get(:component_native_checks)}
  File.write!(home<>"/"<>mode<>"-result.json",:json.encode(result));IO.inspect(result,label: "SDK_PRIVACY_AUTOMATIC_NATIVE_REFUSAL");System.halt(70)
catch
 kind,reason->
  diagnostic=case reason do {:component_check_failed,label}->%{code: :component_check_failed,label: label};_->safe_reason.(reason) end
  result=%{mode: mode,accepted: false,kind: kind,diagnostic: diagnostic,nativeChecks: Process.get(:component_native_checks)}
  File.write!(home<>"/"<>mode<>"-result.json",:json.encode(result));IO.inspect(result,label: "SDK_PRIVACY_AUTOMATIC_NATIVE_REFUSAL");System.halt(70)
end
