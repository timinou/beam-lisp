from pathlib import Path
import struct,json,hashlib,zlib
LIMIT=16777216
class ETF:
 def __init__(self,b):
  assert len(b)<LIMIT
  self.b=b;self.p=0;self.n=1000000
 def take(self,n):
  assert 0<=n<=LIMIT and self.p+n<=len(self.b)
  out=self.b[self.p:self.p+n];self.p+=n;return out
 def u(self,n):return int.from_bytes(self.take(n),'big')
 def term(self,d=0):
  self.n-=1;assert self.n>=0 and d<256
  t=self.u(1)
  if t==97:return self.u(1)
  if t==98:return struct.unpack('>i',self.take(4))[0]
  if t in (100,118,115,119):return self.take(self.u(2 if t in(100,118) else 1)).decode('utf8')
  if t in (104,105):return tuple(self.term(d+1) for _ in range(self.u(1 if t==104 else 4)))
  if t==106:return []
  if t==107:return {'stringbytes':self.take(self.u(2)).hex()}
  if t==108:
   n=self.u(4);assert n<100000
   vals=[self.term(d+1) for _ in range(n)];tail=self.term(d+1);assert tail==[],tail;return vals
  if t==109:return self.take(self.u(4))
  if t==116:
   n=self.u(4);assert n<100000
   vals={}
   for _ in range(n):k=self.term(d+1);v=self.term(d+1);vals[k]=v
   return vals
  if t==70:return struct.unpack('>d',self.take(8))[0]
  if t in(110,111):
   n=self.u(1 if t==110 else 4);sign=self.u(1);v=int.from_bytes(self.take(n),'little');return -v if sign else v
  raise ValueError((t,self.p))
 def decode(self):
  assert self.u(1)==131
  if self.b[1]==80:
   self.p=2;n=self.u(4);assert n<LIMIT
   out=zlib.decompress(self.b[self.p:]);assert len(out)==n
   self.b=out;self.p=0
  v=self.term();assert self.p==len(self.b);return v

def attrs(p):
 b=p.read_bytes();assert b[:4]==b'FOR1' and b[8:12]==b'BEAM';i=12
 while i<len(b):
  tag=b[i:i+4];n=int.from_bytes(b[i+4:i+8],'big');payload=b[i+8:i+8+n]
  if tag==b'Attr':return dict(ETF(payload).decode())
  i+=8+(n+3)//4*4
 raise ValueError('no Attr')
def printable(x):
 if isinstance(x,bytes):
  try:return x.decode('utf8')
  except UnicodeDecodeError:return {'hex':x.hex()}
 if isinstance(x,dict):return {str(printable(k)):printable(v) for k,v in x.items()}
 if isinstance(x,(list,tuple)):return [printable(v) for v in x]
 return x
if __name__=='__main__':
 root=Path('/home/user/tmp/product-online-20261014/round2/sdk-privacy-automatic-native-215/aot-cache/135edad8192ee3d93b429db8f0db9d43f4c48200b6fdd5d9e2176df4442c5687/cd14ee741dd4d861318fe825bb4a729449471f7788198bf5a85b8a9ede031087')
 rows=[]
 for p in sorted(root.glob('*.beam')):
  a=attrs(p);sel={k:v for k,v in a.items() if k.startswith('bl_') and k not in ['bl_aot_forwarder_routes','bl_generated_class']}
  rows.append({'file':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'attributes':printable(sel)})
 result={'scope':'read-only actual215 cache attributes; no Native/VM','objects':rows}
 Path(__file__).with_name('actual-queue-attrs.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
