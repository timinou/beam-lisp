# Warm-only refusals over copies of the genuine completed current cache.
# Mutated objects are never loaded or installed as SDK declaration authority.
%{home: home,inputs: inputs,check: check}=Process.get(:sdk_privacy_negative_context)
ns="proc.queue-runtime";shim=BeamLisp.Emit.module_for(ns)
source=BeamLisp.Loader.source_path(ns);content=File.read!(source)
key=BeamLisp.AOTCache.key_for_ns(ns);closure=BeamLisp.AOT.ns_closure_hash(ns)
original=apply(BeamLisp.AOTCache,:entry_dir,[key,closure])
manifest=:erlang.binary_to_term(File.read!(original<>"/manifest.term"),[:safe])
members=manifest.modules;body=Enum.find(members,& &1!=shim)
previous=System.fetch_env!("BEAM_LISP_AOT_CACHE_DIR")
edit_attribute=fn bytes,value->
 {:ok,module,chunks}=:beam_lib.all_chunks(bytes)
 changed=Enum.map(chunks,fn {name,chunk}->
  if name == ~c"Attr" do
   attrs=:erlang.binary_to_term(chunk,[:safe])
   attrs=if value==:missing,do: Keyword.delete(attrs,:bl_sdk_declarations),else: Keyword.put(attrs,:bl_sdk_declarations,[value])
   {name,:erlang.term_to_binary(attrs)}
  else {name,chunk} end
 end)
 {:ok,rebuilt}=:beam_lib.build_module(changed)
 {:ok,{^module,_}}=:beam_lib.md5(rebuilt)
 rebuilt
end
faults=[:missing_manifest,:corrupt_object,:missing_member,:incomplete_unit,:wrong_compiler,:wrong_closure,:missing_descriptor,:nil_descriptor,:malformed_descriptor,:unknown_descriptor_kind,:wrong_descriptor_namespace]
Enum.each(faults,fn fault->
 root=home<>"/negative-cache/"<>Atom.to_string(fault);entry=root<>"/"<>key<>"/"<>closure
 File.mkdir_p!(Path.dirname(entry));{:ok,_}=File.cp_r(original,entry)
 case fault do
  :missing_manifest->File.rm!(entry<>"/manifest.term")
  :corrupt_object->File.write!(entry<>"/"<>Atom.to_string(body)<>".beam",<<0>>)
  :missing_member->File.rm!(entry<>"/"<>Atom.to_string(body)<>".beam")
  :incomplete_unit->File.write!(entry<>"/manifest.term",:erlang.term_to_binary(%{manifest|modules: List.delete(members,body),digests: Map.delete(manifest.digests,body)}))
  f when f in [:missing_descriptor,:nil_descriptor,:malformed_descriptor,:unknown_descriptor_kind,:wrong_descriptor_namespace]->
   value=case f do
    :missing_descriptor->:missing
    :nil_descriptor->nil
    :malformed_descriptor->false
    :unknown_descriptor_kind->{1,ns,%{"owner"=>:unknown}}
    :wrong_descriptor_namespace->{1,"different.namespace",%{"owner"=>:public}}
   end
   path=entry<>"/"<>Atom.to_string(shim)<>".beam";bytes=edit_attribute.(File.read!(path),value)
   File.write!(path,bytes)
   # Keep the copied executable-byte provenance internally consistent so the
   # negative isolates declaration admission rather than only digest mismatch.
   File.write!(entry<>"/manifest.term",:erlang.term_to_binary(%{manifest|digests: Map.put(manifest.digests,shim,:crypto.hash(:sha256,bytes))}))
  _->:ok
 end
 System.put_env("BEAM_LISP_AOT_CACHE_DIR",root)
 try do
  out=home<>"/negative-objects/"<>Atom.to_string(fault);File.mkdir_p!(out)
  effective_key=if fault==:wrong_compiler,do: String.duplicate("0",64),else: key
  effective_closure=if fault==:wrong_closure,do: String.duplicate("0",64),else: closure
  value=apply(BeamLisp.AOT,:sdk_stage_cached_unit,[ns,source,content,shim,effective_key,effective_closure,out])
  check.("copied-cache-refusal:"<>Atom.to_string(fault),value==nil)
  check.("genuine-current-unit-preserved:"<>Atom.to_string(fault),BeamLisp.AOT.sdk_unit_compiled?(ns))
  check.("genuine-owner-metadata-preserved:"<>Atom.to_string(fault),BeamLisp.AOT.sdk_declaration_kind(ns,"owner")==:public and BeamLisp.AOT.sdk_declaration_kind(ns,"refuse")==:private)
  check.("no-queue-initialization:"<>Atom.to_string(fault),not BeamLisp.Env.loaded_ns?(ns))
 after System.put_env("BEAM_LISP_AOT_CACHE_DIR",previous) end
end)
# Parser controls remain bounded and never intern module identities.
closed_refusal=fn fun->try do fun.();false rescue _->true end end
malformed=[
 {:compressed,:erlang.term_to_binary(manifest,[:compressed])},
 {:missing_field,:erlang.term_to_binary(Map.delete(manifest,:digests))},
 {:duplicate_modules,:erlang.term_to_binary(%{manifest|modules: [shim,shim]})},
 {:improper_modules,:erlang.term_to_binary(%{manifest|modules: [shim|:bad_tail]})},
 {:reference_module,:erlang.term_to_binary(%{manifest|modules: [make_ref()]})},
 {:bad_digest,:erlang.term_to_binary(%{version: 2,modules: [shim],digests: %{shim=><<1>>}})},
 {:too_many_modules,:erlang.term_to_binary(%{manifest|modules: List.duplicate(shim,8193)})},
 {:trailing,:erlang.term_to_binary(manifest)<><<0>>},
 {:truncated,binary_part(:erlang.term_to_binary(manifest),0,15)},
 {:oversize,:binary.copy(<<0>>,1048577)}]
Enum.each(malformed,fn {label,bytes}->
 before=:erlang.system_info(:atom_count)
 refused=closed_refusal.(fn->apply(BeamLisp.AOT,:sdk_stage_manifest!,[bytes]) end)
 after_count=:erlang.system_info(:atom_count)
 check.("manifest-refusal:"<>Atom.to_string(label),refused)
 check.("manifest-no-atom-creation:"<>Atom.to_string(label),before==after_count)
end)
encode_atom=fn name-><<119,byte_size(name)>> <> name end
fresh_name="Elixir.BeamLisp.CacheProbe.Privacy213NeverInterned"
fresh_manifest=<<131,116,0,0,0,3>><>encode_atom.("version")<><<97,2>><>encode_atom.("modules")<><<108,0,0,0,1>><>encode_atom.(fresh_name)<><<106>><>encode_atom.("digests")<><<116,0,0,0,1>><>encode_atom.(fresh_name)<><<109,0,0,0,32,0::256>>
before=:erlang.system_info(:atom_count)
fresh=apply(BeamLisp.AOT,:sdk_stage_manifest!,[fresh_manifest])
after_count=:erlang.system_info(:atom_count)
check.("manifest-identities-stay-binary",fresh.modules==[fresh_name] and Map.keys(fresh.digests)==[fresh_name])
check.("fresh-module-never-interned",before==after_count and closed_refusal.(fn->:erlang.binary_to_existing_atom(fresh_name,:utf8) end))
check.("new-key-cache-boundary",key==inputs["compilerKey"])
